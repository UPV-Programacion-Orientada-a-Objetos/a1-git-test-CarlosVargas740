<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

# Sistema de Gestión de Biblioteca - Instrucciones para Copilot

Este es un proyecto de sistema de gestión de biblioteca desarrollado en Java con las siguientes características:

## Tecnologías Utilizadas:
- **Lenguaje**: Java
- **Interfaz Gráfica**: Java Swing
- **Base de Datos**: MySQL (XAMPP)
- **Autenticación Facial**: OpenCV para Java
- **Código de Barras**: ZXing (Zebra Crossing)

## Arquitectura del Proyecto:
- **MVC (Model-View-Controller)** para separación de responsabilidades
- **DAO Pattern** para acceso a datos
- **Singleton Pattern** para conexión de base de datos
- **Observer Pattern** para notificaciones

## Funcionalidades Principales:
1. Gestión de libros (CRUD)
2. Gestión de usuarios con roles
3. Sistema de préstamos y devoluciones
4. Autenticación facial
5. Búsquedas avanzadas y filtros
6. Reportes y estadísticas
7. Sistema de ventas con código de barras
8. Gestión de sanciones y alertas

## Consideraciones de Desarrollo:
- Usar buenas prácticas de programación Java
- Implementar manejo de excepciones robusto
- Validación de datos en todas las capas
- Interfaz intuitiva y responsiva
- Código bien documentado y comentado
