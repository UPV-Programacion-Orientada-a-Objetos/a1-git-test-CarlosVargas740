# Sistema de Gestión de Biblioteca

Sistema completo de gestión de biblioteca desarrollado en Java con interfaz gráfica Swing, base de datos MySQL (XAMPP), autenticación facial y sistema de ventas con código de barras.

## 🚀 Características Principales

### 📚 Gestión de Libros
- Registro, modificación y eliminación de libros
- Búsqueda avanzada por título, autor, categoría, ISBN
- Control de disponibilidad y stock
- Gestión de categorías y editoriales
- Sistema de ubicación física de libros

### 👥 Gestión de Usuarios
- Registro de usuarios (estudiantes, docentes)
- **Autenticación facial con OpenCV**
- Sistema de roles (Administrador, Bibliotecario, Lector)
- Gestión de permisos por rol
- Cambio de contraseñas

### 📖 Sistema de Préstamos
- Registro de préstamos con fechas
- Control de devoluciones
- Identificación de préstamos vencidos
- Sistema de renovaciones
- Alertas automáticas
- Gestión de sanciones y multas

### 💰 Sistema de Ventas
- **Venta de libros con código de barras**
- Lector de códigos de barras integrado
- Control de inventario
- Historial de ventas
- Facturación básica

### 📊 Reportes y Estadísticas
- Libros más prestados
- Usuarios más activos
- Estadísticas generales
- Reportes en PDF y Excel
- Gráficos estadísticos

### 🔐 Seguridad
- Autenticación por contraseña y facial
- Control de acceso por roles
- Registro de actividades (auditoría)
- Bloqueo de usuarios

## 🛠️ Tecnologías Utilizadas

- **Lenguaje**: Java 11+
- **Interfaz Gráfica**: Java Swing
- **Base de Datos**: MySQL (XAMPP)
- **Conexión BD**: JDBC
- **Autenticación Facial**: OpenCV para Java
- **Códigos de Barras**: ZXing (Zebra Crossing)
- **Reportes**: Apache POI (Excel), iText (PDF)
- **Build Tool**: Maven
- **IDE Recomendado**: VS Code, IntelliJ IDEA, Eclipse

## 📋 Requisitos del Sistema

### Software Requerido
1. **Java Development Kit (JDK) 11 o superior**
2. **XAMPP** (para MySQL y phpMyAdmin)
3. **Maven** (para gestión de dependencias)
4. **Cámara web** (opcional, para autenticación facial)

### Hardware Recomendado
- RAM: 4GB mínimo, 8GB recomendado
- Almacenamiento: 500MB libres
- Procesador: Dual-core o superior
- Cámara web (opcional)

## 🚀 Instalación y Configuración

### 1. Configurar XAMPP y MySQL

1. **Descargar e instalar XAMPP** desde [https://www.apachefriends.org](https://www.apachefriends.org)

2. **Iniciar servicios en XAMPP**:
   - Abrir XAMPP Control Panel
   - Iniciar **Apache** y **MySQL**

3. **Crear la base de datos**:
   - Abrir phpMyAdmin: [http://localhost/phpmyadmin](http://localhost/phpmyadmin)
   - Crear nueva base de datos llamada `biblioteca_db`
   - Importar el archivo `database_setup.sql` que se encuentra en la raíz del proyecto

### 2. Configurar el Proyecto Java

1. **Clonar o descargar el proyecto**
```bash
git clone <url-del-proyecto>
cd sistema-biblioteca
```

2. **Verificar Java y Maven**
```bash
java -version
mvn -version
```

3. **Instalar dependencias**
```bash
mvn clean install
```

4. **Compilar el proyecto**
```bash
mvn compile
```

### 3. Configuración de Base de Datos

El archivo `DatabaseConnection.java` está configurado con los valores por defecto de XAMPP:
- **Host**: localhost
- **Puerto**: 3306
- **Base de datos**: biblioteca_db
- **Usuario**: root
- **Contraseña**: (vacía)

Si necesitas cambiar estos valores, edita el archivo:
`src/main/java/com/biblioteca/database/DatabaseConnection.java`

## ▶️ Ejecutar la Aplicación

### Desde línea de comandos:
```bash
mvn exec:java -Dexec.mainClass="com.biblioteca.views.LoginWindow"
```

### Desde IDE:
1. Importar el proyecto como proyecto Maven
2. Ejecutar la clase `LoginWindow.java`

### Crear JAR ejecutable:
```bash
mvn package
java -jar target/sistema-biblioteca-jar-with-dependencies.jar
```

## 👤 Usuarios por Defecto

El sistema incluye usuarios predefinidos para pruebas:

| Rol | Usuario | Contraseña | Permisos |
|-----|---------|------------|----------|
| **Administrador** | `admin` | `admin123` | Acceso completo |
| **Bibliotecario** | `mgarcia` | `123456` | Gestión de libros y préstamos |
| **Lector** | `jperez` | `123456` | Solo préstamos |

## 📁 Estructura del Proyecto

```
sistema-biblioteca/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/biblioteca/
│   │   │       ├── database/          # Conexión y DAOs
│   │   │       ├── models/            # Clases modelo
│   │   │       ├── views/             # Interfaces gráficas
│   │   │       ├── controllers/       # Lógica de negocio
│   │   │       ├── services/          # Servicios (auth facial, etc.)
│   │   │       └── utils/             # Utilidades
│   │   └── resources/                 # Recursos (imágenes, configs)
│   └── test/                          # Tests unitarios
├── database_setup.sql                 # Script de base de datos
├── pom.xml                           # Configuración Maven
└── README.md                         # Este archivo
```

## 🔧 Configuración Adicional

### Autenticación Facial
Para habilitar completamente la autenticación facial:
1. Instalar OpenCV en el sistema
2. Configurar la cámara web
3. Entrenar el modelo con fotos de usuarios

### Códigos de Barras
Para el sistema de ventas:
1. Conectar un lector de códigos de barras USB
2. Configurar como entrada de teclado
3. Los códigos se pueden ingresar manualmente también

## 📊 Funcionalidades Detalladas

### Gestión de Libros
- ✅ Agregar nuevos libros con toda la información
- ✅ Modificar información existente
- ✅ Eliminar libros (soft delete)
- ✅ Búsqueda por múltiples criterios
- ✅ Control de stock y disponibilidad
- ✅ Gestión de autores y categorías

### Sistema de Préstamos
- ✅ Crear préstamos con validaciones
- ✅ Calcular fechas de devolución
- ✅ Renovar préstamos
- ✅ Procesar devoluciones
- ✅ Calcular multas por retraso
- ✅ Alertas de vencimiento

### Reportes
- ✅ Libros más prestados
- ✅ Usuarios más activos
- ✅ Préstamos vencidos
- ✅ Estadísticas generales
- ✅ Exportar a PDF y Excel

## 🐛 Solución de Problemas

### Error de Conexión a Base de Datos
```
Verificar que XAMPP esté ejecutándose
Confirmar que MySQL esté activo
Revisar credenciales en DatabaseConnection.java
```

### Error de Dependencias Maven
```bash
mvn clean install -U
```

### Error de OpenCV
```
La autenticación facial funciona en modo simulación
Para OpenCV real, instalar dependencias nativas
```

## 🚀 Desarrollo Futuro

### Características Planeadas
- [ ] Interfaz web con Spring Boot
- [ ] API REST
- [ ] Notificaciones por email/SMS
- [ ] Aplicación móvil
- [ ] Integración con bibliotecas digitales
- [ ] Sistema de reservas online
- [ ] Dashboard analítico avanzado

### Mejoras Técnicas
- [ ] Migración a JavaFX
- [ ] Implementación completa de OpenCV
- [ ] Base de datos distribuida
- [ ] Microservicios
- [ ] Contenedores Docker
- [ ] CI/CD pipeline

## 👨‍💻 Contribuir

1. Fork del proyecto
2. Crear rama feature (`git checkout -b feature/nueva-caracteristica`)
3. Commit cambios (`git commit -am 'Agregar nueva característica'`)
4. Push a la rama (`git push origin feature/nueva-caracteristica`)
5. Crear Pull Request

## 📝 Licencia

Este proyecto está bajo la Licencia MIT. Ver el archivo `LICENSE` para más detalles.

## 📞 Soporte

Para soporte técnico o preguntas:
- Crear un issue en el repositorio
- Contactar al equipo de desarrollo

## 🙏 Agradecimientos

- OpenCV community por las herramientas de visión computacional
- ZXing project por las herramientas de códigos de barras
- Apache POI y iText por las herramientas de reportes
- Comunidad Java por las excelentes librerías

---

**Desarrollado con ❤️ para la gestión eficiente de bibliotecas**
