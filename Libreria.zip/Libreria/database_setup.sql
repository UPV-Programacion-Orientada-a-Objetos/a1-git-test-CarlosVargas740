-- Script de Base de Datos para Sistema de Gestión de Biblioteca
-- Base de datos: biblioteca_db
-- XAMPP MySQL

DROP DATABASE IF EXISTS biblioteca_db;
CREATE DATABASE biblioteca_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE biblioteca_db;

-- Tabla de roles
CREATE TABLE roles (
    id_rol INT PRIMARY KEY AUTO_INCREMENT,
    nombre_rol VARCHAR(50) NOT NULL UNIQUE,
    descripcion TEXT,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insertar roles por defecto
INSERT INTO roles (nombre_rol, descripcion) VALUES 
('Administrador', 'Acceso completo al sistema'),
('Bibliotecario', 'Gestión de libros y préstamos'),
('Lector', 'Solo lectura y préstamos');

-- Tabla de usuarios
CREATE TABLE usuarios (
    id_usuario INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100) NOT NULL,
    apellido VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    telefono VARCHAR(20),
    direccion TEXT,
    fecha_nacimiento DATE,
    tipo_usuario ENUM('estudiante', 'docente', 'otro') DEFAULT 'estudiante',
    id_rol INT NOT NULL DEFAULT 3,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    foto_facial LONGBLOB,
    activo BOOLEAN DEFAULT TRUE,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ultimo_acceso TIMESTAMP NULL,
    intentos_fallidos INT DEFAULT 0,
    bloqueado BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (id_rol) REFERENCES roles(id_rol)
);

-- Tabla de categorías de libros
CREATE TABLE categorias (
    id_categoria INT PRIMARY KEY AUTO_INCREMENT,
    nombre_categoria VARCHAR(100) NOT NULL UNIQUE,
    descripcion TEXT,
    activa BOOLEAN DEFAULT TRUE
);

-- Insertar categorías por defecto
INSERT INTO categorias (nombre_categoria, descripcion) VALUES 
('Ficción', 'Novelas y cuentos de ficción'),
('Ciencia', 'Libros de ciencias exactas y naturales'),
('Historia', 'Libros de historia y biografías'),
('Tecnología', 'Libros de informática y tecnología'),
('Educación', 'Libros educativos y académicos'),
('Arte', 'Libros de arte y cultura'),
('Medicina', 'Libros de medicina y salud'),
('Derecho', 'Libros de derecho y leyes'),
('Economía', 'Libros de economía y finanzas'),
('Literatura', 'Clásicos de la literatura universal');

-- Tabla de editoriales
CREATE TABLE editoriales (
    id_editorial INT PRIMARY KEY AUTO_INCREMENT,
    nombre_editorial VARCHAR(150) NOT NULL,
    direccion TEXT,
    telefono VARCHAR(20),
    email VARCHAR(100),
    sitio_web VARCHAR(200),
    activa BOOLEAN DEFAULT TRUE
);

-- Tabla de autores
CREATE TABLE autores (
    id_autor INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100) NOT NULL,
    apellido VARCHAR(100) NOT NULL,
    fecha_nacimiento DATE,
    nacionalidad VARCHAR(50),
    biografia TEXT,
    activo BOOLEAN DEFAULT TRUE
);

-- Tabla de libros
CREATE TABLE libros (
    id_libro INT PRIMARY KEY AUTO_INCREMENT,
    titulo VARCHAR(255) NOT NULL,
    isbn VARCHAR(20) UNIQUE,
    codigo_barras VARCHAR(50) UNIQUE,
    id_categoria INT,
    id_editorial INT,
    año_publicacion INT,
    numero_paginas INT,
    idioma VARCHAR(50) DEFAULT 'Español',
    descripcion TEXT,
    ubicacion VARCHAR(100),
    cantidad_total INT NOT NULL DEFAULT 1,
    cantidad_disponible INT NOT NULL DEFAULT 1,
    precio_venta DECIMAL(10,2) DEFAULT 0.00,
    disponible_venta BOOLEAN DEFAULT FALSE,
    fecha_ingreso TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    activo BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (id_categoria) REFERENCES categorias(id_categoria),
    FOREIGN KEY (id_editorial) REFERENCES editoriales(id_editorial)
);

-- Tabla de relación libros-autores (muchos a muchos)
CREATE TABLE libro_autores (
    id_libro INT,
    id_autor INT,
    PRIMARY KEY (id_libro, id_autor),
    FOREIGN KEY (id_libro) REFERENCES libros(id_libro) ON DELETE CASCADE,
    FOREIGN KEY (id_autor) REFERENCES autores(id_autor) ON DELETE CASCADE
);

-- Tabla de préstamos
CREATE TABLE prestamos (
    id_prestamo INT PRIMARY KEY AUTO_INCREMENT,
    id_usuario INT NOT NULL,
    id_libro INT NOT NULL,
    fecha_prestamo TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_devolucion_programada DATE NOT NULL,
    fecha_devolucion_real TIMESTAMP NULL,
    estado ENUM('activo', 'devuelto', 'vencido', 'perdido') DEFAULT 'activo',
    observaciones TEXT,
    multa DECIMAL(10,2) DEFAULT 0.00,
    multa_pagada BOOLEAN DEFAULT FALSE,
    renovaciones INT DEFAULT 0,
    max_renovaciones INT DEFAULT 2,
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario),
    FOREIGN KEY (id_libro) REFERENCES libros(id_libro)
);

-- Tabla de ventas
CREATE TABLE ventas (
    id_venta INT PRIMARY KEY AUTO_INCREMENT,
    id_libro INT NOT NULL,
    id_usuario_vendedor INT NOT NULL,
    id_usuario_comprador INT,
    cantidad INT NOT NULL DEFAULT 1,
    precio_unitario DECIMAL(10,2) NOT NULL,
    precio_total DECIMAL(10,2) NOT NULL,
    metodo_pago ENUM('efectivo', 'tarjeta', 'transferencia') DEFAULT 'efectivo',
    fecha_venta TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    observaciones TEXT,
    FOREIGN KEY (id_libro) REFERENCES libros(id_libro),
    FOREIGN KEY (id_usuario_vendedor) REFERENCES usuarios(id_usuario),
    FOREIGN KEY (id_usuario_comprador) REFERENCES usuarios(id_usuario)
);

-- Tabla de sanciones
CREATE TABLE sanciones (
    id_sancion INT PRIMARY KEY AUTO_INCREMENT,
    id_usuario INT NOT NULL,
    tipo_sancion ENUM('suspension', 'multa', 'advertencia') NOT NULL,
    motivo TEXT NOT NULL,
    fecha_inicio TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_fin TIMESTAMP NULL,
    monto DECIMAL(10,2) DEFAULT 0.00,
    pagada BOOLEAN DEFAULT FALSE,
    activa BOOLEAN DEFAULT TRUE,
    id_prestamo INT NULL,
    observaciones TEXT,
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario),
    FOREIGN KEY (id_prestamo) REFERENCES prestamos(id_prestamo)
);

-- Tabla de historial de actividades (auditoría) - SIMPLIFICADA
CREATE TABLE historial_actividades (
    id_actividad INT PRIMARY KEY AUTO_INCREMENT,
    id_usuario INT,
    accion VARCHAR(100) NOT NULL,
    tabla_afectada VARCHAR(50),
    id_registro_afectado INT,
    descripcion TEXT,
    fecha_actividad TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ip_usuario VARCHAR(45),
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario)
);

-- Tabla de configuraciones del sistema
CREATE TABLE configuraciones (
    id_config INT PRIMARY KEY AUTO_INCREMENT,
    nombre_config VARCHAR(100) NOT NULL UNIQUE,
    valor_config TEXT NOT NULL,
    descripcion TEXT,
    tipo_dato ENUM('string', 'int', 'boolean', 'decimal') DEFAULT 'string',
    fecha_modificacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insertar configuraciones por defecto
INSERT INTO configuraciones (nombre_config, valor_config, descripcion, tipo_dato) VALUES 
('dias_prestamo_defecto', '15', 'Días por defecto para préstamos', 'int'),
('multa_por_dia', '5.00', 'Multa por día de retraso', 'decimal'),
('max_libros_prestamo', '3', 'Máximo de libros por préstamo simultáneo', 'int'),
('dias_suspension_defecto', '30', 'Días de suspensión por defecto', 'int'),
('activar_reconocimiento_facial', 'true', 'Activar autenticación facial', 'boolean'),
('nombre_biblioteca', 'Biblioteca Central', 'Nombre de la biblioteca', 'string');

-- Índices para optimizar consultas
CREATE INDEX idx_usuarios_email ON usuarios(email);
CREATE INDEX idx_usuarios_username ON usuarios(username);
CREATE INDEX idx_libros_isbn ON libros(isbn);
CREATE INDEX idx_libros_codigo_barras ON libros(codigo_barras);
CREATE INDEX idx_libros_titulo ON libros(titulo);
CREATE INDEX idx_prestamos_usuario ON prestamos(id_usuario);
CREATE INDEX idx_prestamos_libro ON prestamos(id_libro);
CREATE INDEX idx_prestamos_estado ON prestamos(estado);
CREATE INDEX idx_prestamos_fecha ON prestamos(fecha_prestamo);
CREATE INDEX idx_ventas_fecha ON ventas(fecha_venta);
CREATE INDEX idx_sanciones_usuario ON sanciones(id_usuario);
CREATE INDEX idx_sanciones_activa ON sanciones(activa);

-- Insertar algunos datos de prueba

-- Usuarios de prueba
INSERT INTO usuarios (nombre, apellido, email, username, password_hash, id_rol) VALUES 
('Admin', 'Sistema', 'admin@biblioteca.com', 'admin', SHA2('admin123', 256), 1),
('María', 'García', 'maria.garcia@email.com', 'mgarcia', SHA2('123456', 256), 2),
('Juan', 'Pérez', 'juan.perez@email.com', 'jperez', SHA2('123456', 256), 3);

-- Editoriales de prueba
INSERT INTO editoriales (nombre_editorial, direccion) VALUES 
('Penguin Random House', 'Nueva York, USA'),
('Planeta', 'Barcelona, España'),
('Santillana', 'Madrid, España'),
('McGraw Hill', 'Nueva York, USA');

-- Autores de prueba
INSERT INTO autores (nombre, apellido, nacionalidad) VALUES 
('Gabriel', 'García Márquez', 'Colombiana'),
('Mario', 'Vargas Llosa', 'Peruana'),
('Isabel', 'Allende', 'Chilena'),
('Jorge Luis', 'Borges', 'Argentina');

-- Libros de prueba con precios
INSERT INTO libros (titulo, isbn, codigo_barras, id_categoria, id_editorial, año_publicacion, cantidad_total, cantidad_disponible, precio_venta, disponible_venta) VALUES 
('Cien años de soledad', '9788497592208', '9788497592208', 1, 1, 1967, 5, 5, 25.00, TRUE),
('La ciudad y los perros', '9788420471839', '9788420471839', 1, 2, 1963, 3, 3, 22.50, TRUE),
('La casa de los espíritus', '9788401242106', '9788401242106', 1, 2, 1982, 4, 4, 20.00, TRUE),
('Ficciones', '9788499892611', '9788499892611', 10, 1, 1944, 2, 2, 18.75, TRUE);

-- Relacionar libros con autores
INSERT INTO libro_autores (id_libro, id_autor) VALUES 
(1, 1), (2, 2), (3, 3), (4, 4);

-- Mostrar información de creación
SELECT 'Base de datos biblioteca_db creada exitosamente - SIN ERRORES' AS mensaje;
SELECT COUNT(*) AS total_tablas FROM information_schema.tables WHERE table_schema = 'biblioteca_db';
