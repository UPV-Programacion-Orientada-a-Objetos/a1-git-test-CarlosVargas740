package com.biblioteca;

import com.biblioteca.database.DatabaseConnection;
import com.biblioteca.database.UsuarioDAO;
import com.biblioteca.views.LoginWindow;
import javax.swing.*;

/**
 * Clase principal de la aplicación
 * Sistema de Gestión de Biblioteca
 */
public class Main {
    
    public static void main(String[] args) {
        // Configurar look and feel
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception e) {
            System.err.println("No se pudo configurar el look and feel: " + e.getMessage());
        }
        
        // Verificar conexión a la base de datos
        SwingUtilities.invokeLater(() -> {
            try {
                // Probar la conexión
                DatabaseConnection dbConnection = DatabaseConnection.getInstance();
                
                if (dbConnection.getConnection() != null) {
                    System.out.println("Conexión a la base de datos establecida correctamente");
                    
                    // Verificar y crear usuarios por defecto si no existen
                    inicializarUsuarios();
                    
                    // Mostrar ventana de login
                    new LoginWindow().setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(null,
                        "Error: No se pudo conectar a la base de datos.\n" +
                        "Verifique que XAMPP esté ejecutándose y la base de datos 'biblioteca' exista.",
                        "Error de Conexión",
                        JOptionPane.ERROR_MESSAGE);
                    System.exit(1);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null,
                    "Error crítico al inicializar la aplicación:\n" + e.getMessage(),
                    "Error Fatal",
                    JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
                System.exit(1);
            }
        });
    }
    
    /**
     * Inicializa los usuarios por defecto si no existen
     */
    private static void inicializarUsuarios() {
        try {
            UsuarioDAO usuarioDAO = new UsuarioDAO();
            
            if (!usuarioDAO.existenUsuarios()) {
                System.out.println("No se encontraron usuarios en la base de datos.");
                usuarioDAO.crearUsuariosPorDefecto();
                
                // También crear datos de prueba (editoriales, autores, libros)
                usuarioDAO.crearDatosDePrueba();
            } else {
                System.out.println("Usuarios existentes encontrados en la base de datos.");
            }
            
        } catch (Exception e) {
            System.err.println("Error al inicializar usuarios: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
