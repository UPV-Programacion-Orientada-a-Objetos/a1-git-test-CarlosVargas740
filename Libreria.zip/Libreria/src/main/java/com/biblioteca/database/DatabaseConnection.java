package com.biblioteca.database;

import java.sql.*;
import java.util.Properties;

/**
 * Clase singleton para manejar la conexión a la base de datos MySQL
 * Utiliza el patrón Singleton para garantizar una única instancia de conexión
 */
public class DatabaseConnection {
    private static DatabaseConnection instance;
    private Connection connection;
    
    // Configuración de la base de datos
    private static final String DB_HOST = "localhost";
    private static final String DB_PORT = "3306";
    private static final String DB_NAME = "biblioteca_db";
    private static final String DB_USERNAME = "root";
    private static final String DB_PASSWORD = ""; // XAMPP por defecto no tiene contraseña
    
    private static final String DB_URL = "jdbc:mysql://" + DB_HOST + ":" + DB_PORT + "/" + DB_NAME 
            + "?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true&useUnicode=true&characterEncoding=UTF-8";

    /**
     * Constructor privado para implementar el patrón Singleton
     */
    private DatabaseConnection() {
        try {
            // Cargar el driver de MySQL
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // Establecer la conexión
            Properties props = new Properties();
            props.setProperty("user", DB_USERNAME);
            props.setProperty("password", DB_PASSWORD);
            props.setProperty("useSSL", "false");
            props.setProperty("serverTimezone", "UTC");
            props.setProperty("allowPublicKeyRetrieval", "true");
            props.setProperty("useUnicode", "true");
            props.setProperty("characterEncoding", "UTF-8");
            
            this.connection = DriverManager.getConnection(DB_URL, props);
            
            System.out.println("Conexión a la base de datos establecida exitosamente");
            
        } catch (ClassNotFoundException e) {
            System.err.println("Error: Driver MySQL no encontrado");
            e.printStackTrace();
        } catch (SQLException e) {
            System.err.println("Error al conectar a la base de datos: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Obtiene la instancia única de DatabaseConnection
     * @return instancia de DatabaseConnection
     */
    public static DatabaseConnection getInstance() {
        if (instance == null) {
            synchronized (DatabaseConnection.class) {
                if (instance == null) {
                    instance = new DatabaseConnection();
                }
            }
        }
        return instance;
    }

    /**
     * Obtiene la conexión a la base de datos
     * @return Connection objeto de conexión
     * @throws SQLException si hay error en la conexión
     */
    public Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            // Reconectar si la conexión se perdió
            try {
                this.connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
            } catch (SQLException e) {
                System.err.println("Error al reconectar a la base de datos: " + e.getMessage());
                throw e;
            }
        }
        return connection;
    }

    /**
     * Verifica si la conexión está activa
     * @return true si la conexión está activa, false en caso contrario
     */
    public boolean isConnected() {
        try {
            return connection != null && !connection.isClosed() && connection.isValid(5);
        } catch (SQLException e) {
            return false;
        }
    }

    /**
     * Cierra la conexión a la base de datos
     */
    public void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                System.out.println("Conexión a la base de datos cerrada");
            }
        } catch (SQLException e) {
            System.err.println("Error al cerrar la conexión: " + e.getMessage());
        }
    }

    /**
     * Ejecuta una consulta de prueba para verificar la conexión
     * @return true si la conexión es exitosa, false en caso contrario
     */
    public boolean testConnection() {
        try {
            Connection conn = getConnection();
            PreparedStatement stmt = conn.prepareStatement("SELECT 1");
            ResultSet rs = stmt.executeQuery();
            
            boolean result = rs.next();
            
            rs.close();
            stmt.close();
            
            return result;
        } catch (SQLException e) {
            System.err.println("Error en test de conexión: " + e.getMessage());
            return false;
        }
    }

    /**
     * Obtiene información sobre la base de datos
     * @return String con información de la base de datos
     */
    public String getDatabaseInfo() {
        try {
            Connection conn = getConnection();
            DatabaseMetaData metaData = conn.getMetaData();
            
            StringBuilder info = new StringBuilder();
            info.append("Base de datos: ").append(metaData.getDatabaseProductName()).append("\n");
            info.append("Versión: ").append(metaData.getDatabaseProductVersion()).append("\n");
            info.append("Driver: ").append(metaData.getDriverName()).append("\n");
            info.append("Versión del driver: ").append(metaData.getDriverVersion()).append("\n");
            info.append("URL: ").append(metaData.getURL()).append("\n");
            info.append("Usuario: ").append(metaData.getUserName()).append("\n");
            
            return info.toString();
        } catch (SQLException e) {
            return "Error al obtener información de la base de datos: " + e.getMessage();
        }
    }

    /**
     * Ejecuta el script SQL de inicialización de la base de datos
     * @param sqlScript contenido del script SQL
     * @return true si la ejecución fue exitosa, false en caso contrario
     */
    public boolean executeSQLScript(String sqlScript) {
        try {
            Connection conn = getConnection();
            
            // Dividir el script en sentencias individuales
            String[] statements = sqlScript.split(";");
            
            for (String statement : statements) {
                statement = statement.trim();
                if (!statement.isEmpty() && !statement.startsWith("--")) {
                    try {
                        PreparedStatement pstmt = conn.prepareStatement(statement);
                        pstmt.execute();
                        pstmt.close();
                    } catch (SQLException e) {
                        // Continuar con las siguientes sentencias aunque una falle
                        System.err.println("Error ejecutando: " + statement);
                        System.err.println("Error: " + e.getMessage());
                    }
                }
            }
            
            return true;
        } catch (SQLException e) {
            System.err.println("Error ejecutando script SQL: " + e.getMessage());
            return false;
        }
    }
}
