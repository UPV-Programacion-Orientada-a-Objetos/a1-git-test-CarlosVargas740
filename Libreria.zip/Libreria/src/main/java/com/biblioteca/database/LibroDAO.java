package com.biblioteca.database;

import com.biblioteca.models.Libro;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase DAO para operaciones CRUD de libros
 */
public class LibroDAO {
    private DatabaseConnection dbConnection;

    public LibroDAO() {
        this.dbConnection = DatabaseConnection.getInstance();
    }

    /**
     * Crea un nuevo libro en la base de datos
     */
    public boolean crearLibro(Libro libro) {
        String sql = "INSERT INTO libros (titulo, isbn, codigo_barras, id_categoria, id_editorial, " +
                    "ano_publicacion, numero_paginas, idioma, descripcion, ubicacion, " +
                    "cantidad_total, cantidad_disponible, precio_venta, disponible_venta, activo) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setString(1, libro.getTitulo());
            pstmt.setString(2, libro.getIsbn());
            pstmt.setString(3, libro.getCodigoBarras());
            pstmt.setInt(4, libro.getIdCategoria());
            pstmt.setInt(5, libro.getIdEditorial());
            pstmt.setInt(6, libro.getAnoPublicacion());
            pstmt.setInt(7, libro.getNumeroPaginas());
            pstmt.setString(8, libro.getIdioma());
            pstmt.setString(9, libro.getDescripcion());
            pstmt.setString(10, libro.getUbicacion());
            pstmt.setInt(11, libro.getCantidadTotal());
            pstmt.setInt(12, libro.getCantidadDisponible());
            pstmt.setBigDecimal(13, libro.getPrecioVenta());
            pstmt.setBoolean(14, libro.isDisponibleVenta());
            pstmt.setBoolean(15, libro.isActivo());

            int affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {
                try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        libro.setIdLibro(generatedKeys.getInt(1));
                    }
                }
                return true;
            }

        } catch (SQLException e) {
            System.err.println("Error al crear libro: " + e.getMessage());
        }

        return false;
    }

    /**
     * Busca un libro por ID
     */
    public Libro buscarPorId(int idLibro) {
        String sql = "SELECT l.*, c.nombre_categoria, e.nombre_editorial " +
                    "FROM libros l " +
                    "LEFT JOIN categorias c ON l.id_categoria = c.id_categoria " +
                    "LEFT JOIN editoriales e ON l.id_editorial = e.id_editorial " +
                    "WHERE l.id_libro = ? AND l.activo = TRUE";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, idLibro);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Libro libro = mapResultSetToLibro(rs);
                    cargarAutores(libro);
                    return libro;
                }
            }

        } catch (SQLException e) {
            System.err.println("Error al buscar libro por ID: " + e.getMessage());
        }

        return null;
    }

    /**
     * Busca un libro por ISBN
     */
    public Libro buscarPorIsbn(String isbn) {
        String sql = "SELECT l.*, c.nombre_categoria, e.nombre_editorial " +
                    "FROM libros l " +
                    "LEFT JOIN categorias c ON l.id_categoria = c.id_categoria " +
                    "LEFT JOIN editoriales e ON l.id_editorial = e.id_editorial " +
                    "WHERE l.isbn = ? AND l.activo = TRUE";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, isbn);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Libro libro = mapResultSetToLibro(rs);
                    cargarAutores(libro);
                    return libro;
                }
            }

        } catch (SQLException e) {
            System.err.println("Error al buscar libro por ISBN: " + e.getMessage());
        }

        return null;
    }

    /**
     * Busca un libro por código de barras
     */
    public Libro buscarPorCodigoBarras(String codigoBarras) {
        String sql = "SELECT l.*, c.nombre_categoria, e.nombre_editorial " +
                    "FROM libros l " +
                    "LEFT JOIN categorias c ON l.id_categoria = c.id_categoria " +
                    "LEFT JOIN editoriales e ON l.id_editorial = e.id_editorial " +
                    "WHERE l.codigo_barras = ? AND l.activo = TRUE";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, codigoBarras);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Libro libro = mapResultSetToLibro(rs);
                    cargarAutores(libro);
                    return libro;
                }
            }

        } catch (SQLException e) {
            System.err.println("Error al buscar libro por código de barras: " + e.getMessage());
        }

        return null;
    }

    /**
     * Obtiene todos los libros
     */
    public List<Libro> obtenerTodos() {
        String sql = "SELECT l.*, c.nombre_categoria, e.nombre_editorial " +
                    "FROM libros l " +
                    "LEFT JOIN categorias c ON l.id_categoria = c.id_categoria " +
                    "LEFT JOIN editoriales e ON l.id_editorial = e.id_editorial " +
                    "WHERE l.activo = TRUE " +
                    "ORDER BY l.titulo";

        List<Libro> libros = new ArrayList<>();

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                Libro libro = mapResultSetToLibro(rs);
                cargarAutores(libro);
                libros.add(libro);
            }

        } catch (SQLException e) {
            System.err.println("Error al obtener libros: " + e.getMessage());
        }

        return libros;
    }

    /**
     * Busca libros por criterios múltiples
     */
    public List<Libro> buscarLibros(String criterio, Integer idCategoria, Integer idEditorial,
                                   String estado, Boolean disponibleVenta) {
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT l.*, c.nombre_categoria, e.nombre_editorial ");
        sql.append("FROM libros l ");
        sql.append("LEFT JOIN categorias c ON l.id_categoria = c.id_categoria ");
        sql.append("LEFT JOIN editoriales e ON l.id_editorial = e.id_editorial ");
        sql.append("LEFT JOIN libro_autores la ON l.id_libro = la.id_libro ");
        sql.append("LEFT JOIN autores a ON la.id_autor = a.id_autor ");
        sql.append("WHERE l.activo = TRUE ");

        List<Object> parametros = new ArrayList<>();

        if (criterio != null && !criterio.trim().isEmpty()) {
            sql.append("AND (l.titulo LIKE ? OR l.isbn LIKE ? OR l.codigo_barras LIKE ? ");
            sql.append("OR CONCAT(a.nombre, ' ', a.apellido) LIKE ?) ");
            String criterioLike = "%" + criterio + "%";
            parametros.add(criterioLike);
            parametros.add(criterioLike);
            parametros.add(criterioLike);
            parametros.add(criterioLike);
        }

        if (idCategoria != null && idCategoria > 0) {
            sql.append("AND l.id_categoria = ? ");
            parametros.add(idCategoria);
        }

        if (idEditorial != null && idEditorial > 0) {
            sql.append("AND l.id_editorial = ? ");
            parametros.add(idEditorial);
        }

        if ("disponible".equals(estado)) {
            sql.append("AND l.cantidad_disponible > 0 ");
        } else if ("prestado".equals(estado)) {
            sql.append("AND l.cantidad_disponible < l.cantidad_total ");
        }

        if (disponibleVenta != null) {
            sql.append("AND l.disponible_venta = ? ");
            parametros.add(disponibleVenta);
        }

        sql.append("GROUP BY l.id_libro ORDER BY l.titulo");

        List<Libro> libros = new ArrayList<>();

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql.toString())) {

            for (int i = 0; i < parametros.size(); i++) {
                pstmt.setObject(i + 1, parametros.get(i));
            }

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Libro libro = mapResultSetToLibro(rs);
                    cargarAutores(libro);
                    libros.add(libro);
                }
            }

        } catch (SQLException e) {
            System.err.println("Error al buscar libros: " + e.getMessage());
        }

        return libros;
    }

    /**
     * Actualiza un libro
     */
    public boolean actualizarLibro(Libro libro) {
        String sql = "UPDATE libros SET titulo = ?, isbn = ?, codigo_barras = ?, id_categoria = ?, " +
                    "id_editorial = ?, ano_publicacion = ?, numero_paginas = ?, idioma = ?, " +
                    "descripcion = ?, ubicacion = ?, cantidad_total = ?, cantidad_disponible = ?, " +
                    "precio_venta = ?, disponible_venta = ? WHERE id_libro = ?";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, libro.getTitulo());
            pstmt.setString(2, libro.getIsbn());
            pstmt.setString(3, libro.getCodigoBarras());
            pstmt.setInt(4, libro.getIdCategoria());
            pstmt.setInt(5, libro.getIdEditorial());
            pstmt.setInt(6, libro.getAnoPublicacion());
            pstmt.setInt(7, libro.getNumeroPaginas());
            pstmt.setString(8, libro.getIdioma());
            pstmt.setString(9, libro.getDescripcion());
            pstmt.setString(10, libro.getUbicacion());
            pstmt.setInt(11, libro.getCantidadTotal());
            pstmt.setInt(12, libro.getCantidadDisponible());
            pstmt.setBigDecimal(13, libro.getPrecioVenta());
            pstmt.setBoolean(14, libro.isDisponibleVenta());
            pstmt.setInt(15, libro.getIdLibro());

            return pstmt.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error al actualizar libro: " + e.getMessage());
        }

        return false;
    }

    /**
     * Elimina un libro (soft delete)
     */
    public boolean eliminarLibro(int idLibro) {
        String sql = "UPDATE libros SET activo = FALSE WHERE id_libro = ?";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, idLibro);
            return pstmt.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error al eliminar libro: " + e.getMessage());
        }

        return false;
    }

    /**
     * Actualiza la disponibilidad de un libro
     */
    public boolean actualizarDisponibilidad(int idLibro, int nuevaCantidadDisponible) {
        String sql = "UPDATE libros SET cantidad_disponible = ? WHERE id_libro = ?";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, nuevaCantidadDisponible);
            pstmt.setInt(2, idLibro);

            return pstmt.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error al actualizar disponibilidad: " + e.getMessage());
        }

        return false;
    }

    /**
     * Carga los autores de un libro
     */
    private void cargarAutores(Libro libro) {
        String sql = "SELECT CONCAT(a.nombre, ' ', a.apellido) as nombre_completo " +
                    "FROM libro_autores la " +
                    "JOIN autores a ON la.id_autor = a.id_autor " +
                    "WHERE la.id_libro = ? AND a.activo = TRUE";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, libro.getIdLibro());

            try (ResultSet rs = pstmt.executeQuery()) {
                List<String> autores = new ArrayList<>();
                while (rs.next()) {
                    autores.add(rs.getString("nombre_completo"));
                }
                libro.setAutores(autores);
            }

        } catch (SQLException e) {
            System.err.println("Error al cargar autores: " + e.getMessage());
        }
    }

    /**
     * Verifica si un ISBN ya existe
     */
    public boolean existeIsbn(String isbn) {
        String sql = "SELECT COUNT(*) FROM libros WHERE isbn = ? AND activo = TRUE";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, isbn);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }

        } catch (SQLException e) {
            System.err.println("Error al verificar ISBN: " + e.getMessage());
        }

        return false;
    }

    /**
     * Obtiene libros más prestados
     */
    public List<Libro> obtenerLibrosMasPrestados(int limite) {
        String sql = "SELECT l.*, c.nombre_categoria, e.nombre_editorial, COUNT(p.id_prestamo) as total_prestamos " +
                    "FROM libros l " +
                    "LEFT JOIN categorias c ON l.id_categoria = c.id_categoria " +
                    "LEFT JOIN editoriales e ON l.id_editorial = e.id_editorial " +
                    "LEFT JOIN prestamos p ON l.id_libro = p.id_libro " +
                    "WHERE l.activo = TRUE " +
                    "GROUP BY l.id_libro " +
                    "ORDER BY total_prestamos DESC " +
                    "LIMIT ?";

        List<Libro> libros = new ArrayList<>();

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, limite);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Libro libro = mapResultSetToLibro(rs);
                    cargarAutores(libro);
                    libros.add(libro);
                }
            }

        } catch (SQLException e) {
            System.err.println("Error al obtener libros más prestados: " + e.getMessage());
        }

        return libros;
    }

    /**
     * Mapea un ResultSet a un objeto Libro
     */
    private Libro mapResultSetToLibro(ResultSet rs) throws SQLException {
        Libro libro = new Libro();
        
        libro.setIdLibro(rs.getInt("id_libro"));
        libro.setTitulo(rs.getString("titulo"));
        libro.setIsbn(rs.getString("isbn"));
        libro.setCodigoBarras(rs.getString("codigo_barras"));
        libro.setIdCategoria(rs.getInt("id_categoria"));
        libro.setIdEditorial(rs.getInt("id_editorial"));
        libro.setAnoPublicacion(rs.getInt("ano_publicacion"));
        libro.setNumeroPaginas(rs.getInt("numero_paginas"));
        libro.setIdioma(rs.getString("idioma"));
        libro.setDescripcion(rs.getString("descripcion"));
        libro.setUbicacion(rs.getString("ubicacion"));
        libro.setCantidadTotal(rs.getInt("cantidad_total"));
        libro.setCantidadDisponible(rs.getInt("cantidad_disponible"));
        libro.setPrecioVenta(rs.getBigDecimal("precio_venta"));
        libro.setDisponibleVenta(rs.getBoolean("disponible_venta"));
        libro.setActivo(rs.getBoolean("activo"));
        
        Timestamp fechaIngreso = rs.getTimestamp("fecha_ingreso");
        if (fechaIngreso != null) {
            libro.setFechaIngreso(fechaIngreso.toLocalDateTime());
        }
        
        libro.setNombreCategoria(rs.getString("nombre_categoria"));
        libro.setNombreEditorial(rs.getString("nombre_editorial"));
        
        return libro;
    }
}
