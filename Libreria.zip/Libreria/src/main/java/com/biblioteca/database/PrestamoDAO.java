package com.biblioteca.database;

import com.biblioteca.models.Prestamo;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO simplificado para gestión de préstamos
 */
public class PrestamoDAO {
    
    private final DatabaseConnection dbConnection;
    
    public PrestamoDAO() {
        this.dbConnection = DatabaseConnection.getInstance();
    }
    
    /**
     * Crear un nuevo préstamo
     */
    public boolean crearPrestamo(Prestamo prestamo) {
        String sql = "INSERT INTO prestamos (id_usuario, id_libro, fecha_prestamo, fecha_devolucion_programada, estado, observaciones) VALUES (?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, prestamo.getIdUsuario());
            stmt.setInt(2, prestamo.getIdLibro());
            stmt.setTimestamp(3, Timestamp.valueOf(prestamo.getFechaPrestamo()));
            stmt.setDate(4, Date.valueOf(prestamo.getFechaDevolucionProgramada()));
            stmt.setString(5, prestamo.getEstado());
            stmt.setString(6, prestamo.getObservaciones());
            
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Obtener todos los préstamos
     */
    public List<Prestamo> obtenerPrestamos() {
        List<Prestamo> prestamos = new ArrayList<>();
        String sql = "SELECT * FROM prestamos ORDER BY fecha_prestamo DESC";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                Prestamo prestamo = new Prestamo();
                prestamo.setIdPrestamo(rs.getInt("id_prestamo"));
                prestamo.setIdUsuario(rs.getInt("id_usuario"));
                prestamo.setIdLibro(rs.getInt("id_libro"));
                prestamo.setFechaPrestamo(rs.getTimestamp("fecha_prestamo").toLocalDateTime());
                prestamo.setFechaDevolucionProgramada(rs.getDate("fecha_devolucion_programada").toLocalDate());
                prestamo.setEstado(rs.getString("estado"));
                prestamo.setObservaciones(rs.getString("observaciones"));
                prestamos.add(prestamo);
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return prestamos;
    }
    
    /**
     * Devolver un libro
     */
    public boolean devolverLibro(int prestamoId) {
        String sql = "UPDATE prestamos SET estado = 'devuelto', fecha_devolucion_real = NOW() WHERE id_prestamo = ?";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, prestamoId);
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
