package com.biblioteca.database;

import com.biblioteca.models.Usuario;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase DAO para operaciones CRUD de usuarios
 */
public class UsuarioDAO {
    private DatabaseConnection dbConnection;

    public UsuarioDAO() {
        this.dbConnection = DatabaseConnection.getInstance();
    }

    /**
     * Crea un hash SHA-256 de la contraseña
     */
    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(password.getBytes());
            StringBuilder hexString = new StringBuilder();
            
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Error al generar hash de contraseña", e);
        }
    }

    /**
     * Crea un nuevo usuario en la base de datos
     */
    public boolean crearUsuario(Usuario usuario) {
        String sql = "INSERT INTO usuarios (nombre, apellido, email, telefono, direccion, " +
                    "fecha_nacimiento, tipo_usuario, id_rol, username, password_hash, activo) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, SHA2(?, 256), ?)";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setString(1, usuario.getNombre());
            pstmt.setString(2, usuario.getApellido());
            pstmt.setString(3, usuario.getEmail());
            pstmt.setString(4, usuario.getTelefono());
            pstmt.setString(5, usuario.getDireccion());
            pstmt.setString(6, usuario.getFechaNacimiento());
            pstmt.setString(7, usuario.getTipoUsuario());
            pstmt.setInt(8, usuario.getIdRol());
            pstmt.setString(9, usuario.getUsername());
            pstmt.setString(10, usuario.getPasswordHash()); // Contraseña en texto plano, se hashea en SQL
            pstmt.setBoolean(11, usuario.isActivo());

            int affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {
                try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        usuario.setIdUsuario(generatedKeys.getInt(1));
                    }
                }
                return true;
            }

        } catch (SQLException e) {
            System.err.println("Error al crear usuario: " + e.getMessage());
            e.printStackTrace();
        }

        return false;
    }

    /**
     * Crea un nuevo usuario con contraseña en texto plano
     */
    public boolean crearUsuarioConPassword(String nombre, String apellido, String email, 
                                          String username, String password, int idRol) {
        Usuario usuario = new Usuario();
        usuario.setNombre(nombre);
        usuario.setApellido(apellido);
        usuario.setEmail(email);
        usuario.setUsername(username);
        usuario.setPasswordHash(password); // Texto plano, se hasheará en crearUsuario
        usuario.setIdRol(idRol);
        usuario.setActivo(true);
        usuario.setTipoUsuario("estudiante");
        
        return crearUsuario(usuario);
    }

    /**
     * Verifica si existen usuarios en la base de datos
     */
    public boolean existenUsuarios() {
        String sql = "SELECT COUNT(*) FROM usuarios WHERE activo = TRUE";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
            
        } catch (SQLException e) {
            System.err.println("Error al verificar usuarios: " + e.getMessage());
        }
        
        return false;
    }

    /**
     * Crea los usuarios por defecto del sistema
     */
    public void crearUsuariosPorDefecto() {
        System.out.println("Creando usuarios por defecto...");
        
        // Usuario Administrador
        boolean adminCreado = crearUsuarioConPassword(
            "Admin", "Sistema", "admin@biblioteca.com", 
            "admin", "admin123", 1
        );
        
        // Usuario Bibliotecario
        boolean biblioCreado = crearUsuarioConPassword(
            "María", "García", "maria.garcia@email.com", 
            "mgarcia", "123456", 2
        );
        
        // Usuario Lector
        boolean lectorCreado = crearUsuarioConPassword(
            "Juan", "Pérez", "juan.perez@email.com", 
            "jperez", "123456", 3
        );
        
        if (adminCreado && biblioCreado && lectorCreado) {
            System.out.println("Usuarios por defecto creados exitosamente:");
            System.out.println("- Administrador: admin / admin123");
            System.out.println("- Bibliotecario: mgarcia / 123456");
            System.out.println("- Lector: jperez / 123456");
        } else {
            System.err.println("Error al crear algunos usuarios por defecto");
        }
    }

    /**
     * Crea datos de prueba adicionales (editoriales, autores, libros)
     */
    public void crearDatosDePrueba() {
        try (Connection conn = dbConnection.getConnection()) {
            
            // Verificar si ya existen editoriales
            PreparedStatement checkEditorial = conn.prepareStatement("SELECT COUNT(*) FROM editoriales");
            ResultSet rs = checkEditorial.executeQuery();
            rs.next();
            
            if (rs.getInt(1) == 0) {
                System.out.println("Creando editoriales de prueba...");
                
                // Crear editoriales
                PreparedStatement pstmt = conn.prepareStatement(
                    "INSERT INTO editoriales (nombre_editorial, direccion) VALUES (?, ?)"
                );
                
                pstmt.setString(1, "Penguin Random House");
                pstmt.setString(2, "Nueva York, USA");
                pstmt.executeUpdate();
                
                pstmt.setString(1, "Planeta");
                pstmt.setString(2, "Barcelona, España");
                pstmt.executeUpdate();
                
                pstmt.setString(1, "Santillana");
                pstmt.setString(2, "Madrid, España");
                pstmt.executeUpdate();
                
                System.out.println("Editoriales creadas exitosamente.");
            }
            
            // Verificar si ya existen autores
            PreparedStatement checkAutor = conn.prepareStatement("SELECT COUNT(*) FROM autores");
            rs = checkAutor.executeQuery();
            rs.next();
            
            if (rs.getInt(1) == 0) {
                System.out.println("Creando autores de prueba...");
                
                // Crear autores
                PreparedStatement pstmt = conn.prepareStatement(
                    "INSERT INTO autores (nombre, apellido, nacionalidad) VALUES (?, ?, ?)"
                );
                
                pstmt.setString(1, "Gabriel");
                pstmt.setString(2, "García Márquez");
                pstmt.setString(3, "Colombiana");
                pstmt.executeUpdate();
                
                pstmt.setString(1, "Mario");
                pstmt.setString(2, "Vargas Llosa");
                pstmt.setString(3, "Peruana");
                pstmt.executeUpdate();
                
                pstmt.setString(1, "Isabel");
                pstmt.setString(2, "Allende");
                pstmt.setString(3, "Chilena");
                pstmt.executeUpdate();
                
                System.out.println("Autores creados exitosamente.");
            }
            
            // Verificar si ya existen libros
            PreparedStatement checkLibro = conn.prepareStatement("SELECT COUNT(*) FROM libros");
            rs = checkLibro.executeQuery();
            rs.next();
            
            if (rs.getInt(1) == 0) {
                System.out.println("Creando libros de prueba...");
                
                // Crear libros
                PreparedStatement pstmt = conn.prepareStatement(
                    "INSERT INTO libros (titulo, isbn, codigo_barras, id_categoria, id_editorial, ano_publicacion, cantidad_total, cantidad_disponible) VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
                );
                
                pstmt.setString(1, "Cien años de soledad");
                pstmt.setString(2, "9788497592208");
                pstmt.setString(3, "9788497592208");
                pstmt.setInt(4, 1); // Ficción
                pstmt.setInt(5, 1); // Penguin Random House
                pstmt.setInt(6, 1967);
                pstmt.setInt(7, 5);
                pstmt.setInt(8, 5);
                pstmt.executeUpdate();
                
                pstmt.setString(1, "La ciudad y los perros");
                pstmt.setString(2, "9788420471839");
                pstmt.setString(3, "9788420471839");
                pstmt.setInt(4, 1); // Ficción
                pstmt.setInt(5, 2); // Planeta
                pstmt.setInt(6, 1963);
                pstmt.setInt(7, 3);
                pstmt.setInt(8, 3);
                pstmt.executeUpdate();
                
                pstmt.setString(1, "La casa de los espíritus");
                pstmt.setString(2, "9788401242106");
                pstmt.setString(3, "9788401242106");
                pstmt.setInt(4, 1); // Ficción
                pstmt.setInt(5, 2); // Planeta
                pstmt.setInt(6, 1982);
                pstmt.setInt(7, 4);
                pstmt.setInt(8, 4);
                pstmt.executeUpdate();
                
                // Relacionar libros con autores
                PreparedStatement relacion = conn.prepareStatement(
                    "INSERT INTO libro_autores (id_libro, id_autor) VALUES (?, ?)"
                );
                
                relacion.setInt(1, 1); relacion.setInt(2, 1); // Cien años - García Márquez
                relacion.executeUpdate();
                relacion.setInt(1, 2); relacion.setInt(2, 2); // La ciudad - Vargas Llosa
                relacion.executeUpdate();
                relacion.setInt(1, 3); relacion.setInt(2, 3); // La casa - Allende
                relacion.executeUpdate();
                
                System.out.println("Libros creados exitosamente.");
            }
            
        } catch (SQLException e) {
            System.err.println("Error al crear datos de prueba: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Busca todos los usuarios activos
     */
    public List<Usuario> buscarTodos() {
        List<Usuario> usuarios = new ArrayList<>();
        String sql = "SELECT u.*, r.nombre_rol " +
                    "FROM usuarios u " +
                    "JOIN roles r ON u.id_rol = r.id_rol " +
                    "WHERE u.activo = TRUE " +
                    "ORDER BY u.nombre, u.apellido";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            
            while (rs.next()) {
                usuarios.add(mapResultSetToUsuario(rs));
            }
            
        } catch (SQLException e) {
            System.err.println("Error al buscar todos los usuarios: " + e.getMessage());
        }
        
        return usuarios;
    }

    /**
     * Busca usuarios por término (nombre, apellido, email, username)
     */
    public List<Usuario> buscarPorTermino(String termino) {
        List<Usuario> usuarios = new ArrayList<>();
        String sql = "SELECT u.*, r.nombre_rol " +
                    "FROM usuarios u " +
                    "JOIN roles r ON u.id_rol = r.id_rol " +
                    "WHERE u.activo = TRUE AND (" +
                    "u.nombre LIKE ? OR u.apellido LIKE ? OR " +
                    "u.email LIKE ? OR u.username LIKE ?) " +
                    "ORDER BY u.nombre, u.apellido";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            String searchTerm = "%" + termino + "%";
            pstmt.setString(1, searchTerm);
            pstmt.setString(2, searchTerm);
            pstmt.setString(3, searchTerm);
            pstmt.setString(4, searchTerm);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    usuarios.add(mapResultSetToUsuario(rs));
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Error al buscar usuarios por término: " + e.getMessage());
        }
        
        return usuarios;
    }

    /**
     * Autentica un usuario por username y contraseña
     */
    public Usuario autenticarUsuario(String username, String password) {
        String sql = "SELECT u.*, r.nombre_rol " +
                    "FROM usuarios u " +
                    "JOIN roles r ON u.id_rol = r.id_rol " +
                    "WHERE u.username = ? AND u.password_hash = SHA2(?, 256) AND u.activo = TRUE";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, username);
            pstmt.setString(2, password);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Usuario usuario = mapResultSetToUsuario(rs);
                    
                    // Actualizar último acceso
                    actualizarUltimoAcceso(usuario.getIdUsuario());
                    
                    return usuario;
                }
            }

        } catch (SQLException e) {
            System.err.println("Error al autenticar usuario: " + e.getMessage());
            e.printStackTrace();
        }

        return null;
    }

    /**
     * Busca un usuario por ID
     */
    public Usuario buscarPorId(int idUsuario) {
        String sql = "SELECT u.*, r.nombre_rol " +
                    "FROM usuarios u " +
                    "JOIN roles r ON u.id_rol = r.id_rol " +
                    "WHERE u.id_usuario = ?";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, idUsuario);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToUsuario(rs);
                }
            }

        } catch (SQLException e) {
            System.err.println("Error al buscar usuario por ID: " + e.getMessage());
        }

        return null;
    }

    /**
     * Busca un usuario por username
     */
    public Usuario buscarPorUsername(String username) {
        String sql = "SELECT u.*, r.nombre_rol " +
                    "FROM usuarios u " +
                    "JOIN roles r ON u.id_rol = r.id_rol " +
                    "WHERE u.username = ?";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, username);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToUsuario(rs);
                }
            }

        } catch (SQLException e) {
            System.err.println("Error al buscar usuario por username: " + e.getMessage());
        }

        return null;
    }

    /**
     * Obtiene todos los usuarios
     */
    public List<Usuario> obtenerTodos() {
        String sql = "SELECT u.*, r.nombre_rol " +
                    "FROM usuarios u " +
                    "JOIN roles r ON u.id_rol = r.id_rol " +
                    "ORDER BY u.nombre, u.apellido";

        List<Usuario> usuarios = new ArrayList<>();

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                usuarios.add(mapResultSetToUsuario(rs));
            }

        } catch (SQLException e) {
            System.err.println("Error al obtener usuarios: " + e.getMessage());
        }

        return usuarios;
    }

    /**
     * Busca usuarios por criterios
     */
    public List<Usuario> buscarUsuarios(String criterio) {
        String sql = "SELECT u.*, r.nombre_rol " +
                    "FROM usuarios u " +
                    "JOIN roles r ON u.id_rol = r.id_rol " +
                    "WHERE u.nombre LIKE ? OR u.apellido LIKE ? OR u.email LIKE ? OR u.username LIKE ? " +
                    "ORDER BY u.nombre, u.apellido";

        List<Usuario> usuarios = new ArrayList<>();
        String criterioLike = "%" + criterio + "%";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, criterioLike);
            pstmt.setString(2, criterioLike);
            pstmt.setString(3, criterioLike);
            pstmt.setString(4, criterioLike);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    usuarios.add(mapResultSetToUsuario(rs));
                }
            }

        } catch (SQLException e) {
            System.err.println("Error al buscar usuarios: " + e.getMessage());
        }

        return usuarios;
    }

    /**
     * Actualiza un usuario
     */
    public boolean actualizarUsuario(Usuario usuario) {
        String sql = "UPDATE usuarios SET nombre = ?, apellido = ?, email = ?, telefono = ?, " +
                    "direccion = ?, fecha_nacimiento = ?, tipo_usuario = ?, id_rol = ?, activo = ? " +
                    "WHERE id_usuario = ?";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, usuario.getNombre());
            pstmt.setString(2, usuario.getApellido());
            pstmt.setString(3, usuario.getEmail());
            pstmt.setString(4, usuario.getTelefono());
            pstmt.setString(5, usuario.getDireccion());
            pstmt.setString(6, usuario.getFechaNacimiento());
            pstmt.setString(7, usuario.getTipoUsuario());
            pstmt.setInt(8, usuario.getIdRol());
            pstmt.setBoolean(9, usuario.isActivo());
            pstmt.setInt(10, usuario.getIdUsuario());

            return pstmt.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error al actualizar usuario: " + e.getMessage());
        }

        return false;
    }

    /**
     * Cambia la contraseña de un usuario
     */
    public boolean cambiarPassword(int idUsuario, String nuevaPassword) {
        String sql = "UPDATE usuarios SET password_hash = SHA2(?, 256) WHERE id_usuario = ?";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, nuevaPassword);
            pstmt.setInt(2, idUsuario);

            return pstmt.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error al cambiar contraseña: " + e.getMessage());
        }

        return false;
    }

    /**
     * Elimina un usuario (soft delete)
     */
    public boolean eliminarUsuario(int idUsuario) {
        String sql = "UPDATE usuarios SET activo = FALSE WHERE id_usuario = ?";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, idUsuario);
            return pstmt.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error al eliminar usuario: " + e.getMessage());
        }

        return false;
    }

    /**
     * Actualiza el último acceso del usuario
     */
    private void actualizarUltimoAcceso(int idUsuario) {
        String sql = "UPDATE usuarios SET ultimo_acceso = CURRENT_TIMESTAMP WHERE id_usuario = ?";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, idUsuario);
            pstmt.executeUpdate();

        } catch (SQLException e) {
            System.err.println("Error al actualizar último acceso: " + e.getMessage());
        }
    }

    /**
     * Verifica si un username ya existe
     */
    public boolean existeUsername(String username) {
        String sql = "SELECT COUNT(*) FROM usuarios WHERE username = ?";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, username);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }

        } catch (SQLException e) {
            System.err.println("Error al verificar username: " + e.getMessage());
        }

        return false;
    }

    /**
     * Verifica si un email ya existe
     */
    public boolean existeEmail(String email) {
        String sql = "SELECT COUNT(*) FROM usuarios WHERE email = ?";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, email);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }

        } catch (SQLException e) {
            System.err.println("Error al verificar email: " + e.getMessage());
        }

        return false;
    }

    /**
     * Mapea un ResultSet a un objeto Usuario
     */
    private Usuario mapResultSetToUsuario(ResultSet rs) throws SQLException {
        Usuario usuario = new Usuario();
        
        usuario.setIdUsuario(rs.getInt("id_usuario"));
        usuario.setNombre(rs.getString("nombre"));
        usuario.setApellido(rs.getString("apellido"));
        usuario.setEmail(rs.getString("email"));
        usuario.setTelefono(rs.getString("telefono"));
        usuario.setDireccion(rs.getString("direccion"));
        usuario.setFechaNacimiento(rs.getString("fecha_nacimiento"));
        usuario.setTipoUsuario(rs.getString("tipo_usuario"));
        usuario.setIdRol(rs.getInt("id_rol"));
        usuario.setUsername(rs.getString("username"));
        usuario.setPasswordHash(rs.getString("password_hash"));
        usuario.setFotoFacial(rs.getBytes("foto_facial"));
        usuario.setActivo(rs.getBoolean("activo"));
        
        Timestamp fechaRegistro = rs.getTimestamp("fecha_registro");
        if (fechaRegistro != null) {
            usuario.setFechaRegistro(fechaRegistro.toLocalDateTime());
        }
        
        Timestamp ultimoAcceso = rs.getTimestamp("ultimo_acceso");
        if (ultimoAcceso != null) {
            usuario.setUltimoAcceso(ultimoAcceso.toLocalDateTime());
        }
        
        usuario.setIntentosFallidos(rs.getInt("intentos_fallidos"));
        usuario.setBloqueado(rs.getBoolean("bloqueado"));
        usuario.setNombreRol(rs.getString("nombre_rol"));
        
        return usuario;
    }
    
    /**
     * Cambia la contraseña de un usuario
     */
    public boolean cambiarContrasena(int idUsuario, String nuevaContrasenaHash) {
        String sql = "UPDATE usuarios SET password_hash = ?, intentos_fallidos = 0 WHERE id_usuario = ?";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, nuevaContrasenaHash);
            stmt.setInt(2, idUsuario);
            
            int filasAfectadas = stmt.executeUpdate();
            return filasAfectadas > 0;
            
        } catch (SQLException e) {
            System.err.println("Error al cambiar contraseña: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Actualiza la foto facial de un usuario
     */
    public boolean actualizarFotoFacial(int idUsuario, byte[] fotoFacial) {
        String sql = "UPDATE usuarios SET foto_facial = ? WHERE id_usuario = ?";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setBytes(1, fotoFacial);
            stmt.setInt(2, idUsuario);
            
            int filasAfectadas = stmt.executeUpdate();
            return filasAfectadas > 0;
            
        } catch (SQLException e) {
            System.err.println("Error al actualizar foto facial: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Verifica si un usuario está bloqueado por intentos fallidos
     */
    public boolean usuarioBloqueado(String username) {
        String sql = "SELECT bloqueado, intentos_fallidos FROM usuarios WHERE username = ? AND activo = true";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, username);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getBoolean("bloqueado") || rs.getInt("intentos_fallidos") >= 3;
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Error verificando bloqueo de usuario: " + e.getMessage());
        }
        
        return true; // Por seguridad, si hay error se considera bloqueado
    }
    
    /**
     * Incrementa los intentos fallidos de login
     */
    public void incrementarIntentosFallidos(String username) {
        String sql = "UPDATE usuarios SET intentos_fallidos = intentos_fallidos + 1, " +
                    "bloqueado = CASE WHEN intentos_fallidos >= 2 THEN true ELSE bloqueado END " +
                    "WHERE username = ?";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, username);
            stmt.executeUpdate();
            
        } catch (SQLException e) {
            System.err.println("Error incrementando intentos fallidos: " + e.getMessage());
        }
    }
    
    /**
     * Resetea los intentos fallidos después de login exitoso
     */
    public void resetearIntentosFallidos(String username) {
        String sql = "UPDATE usuarios SET intentos_fallidos = 0, bloqueado = false, ultimo_acceso = NOW() WHERE username = ?";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, username);
            stmt.executeUpdate();
            
        } catch (SQLException e) {
            System.err.println("Error reseteando intentos fallidos: " + e.getMessage());
        }
    }
}
