package com.biblioteca.models;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase modelo para representar libros en el sistema
 */
public class Libro {
    private int idLibro;
    private String titulo;
    private String isbn;
    private String codigoBarras;
    private int idCategoria;
    private int idEditorial;
    private int anoPublicacion;
    private int numeroPaginas;
    private String idioma;
    private String descripcion;
    private String ubicacion;
    private int cantidadTotal;
    private int cantidadDisponible;
    private BigDecimal precioVenta;
    private boolean disponibleVenta;
    private LocalDateTime fechaIngreso;
    private boolean activo;
    
    // Información adicional de relaciones
    private String nombreCategoria;
    private String nombreEditorial;
    private List<String> autores;

    // Constructores
    public Libro() {
        this.autores = new ArrayList<>();
        this.idioma = "Español";
        this.activo = true;
        this.fechaIngreso = LocalDateTime.now();
        this.precioVenta = BigDecimal.ZERO;
        this.disponibleVenta = false;
    }

    public Libro(String titulo, String isbn) {
        this();
        this.titulo = titulo;
        this.isbn = isbn;
    }

    // Getters y Setters
    public int getIdLibro() {
        return idLibro;
    }

    public void setIdLibro(int idLibro) {
        this.idLibro = idLibro;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getCodigoBarras() {
        return codigoBarras;
    }

    public void setCodigoBarras(String codigoBarras) {
        this.codigoBarras = codigoBarras;
    }

    public int getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(int idCategoria) {
        this.idCategoria = idCategoria;
    }

    public int getIdEditorial() {
        return idEditorial;
    }

    public void setIdEditorial(int idEditorial) {
        this.idEditorial = idEditorial;
    }

    public int getAnoPublicacion() {
        return anoPublicacion;
    }

    public void setAnoPublicacion(int anoPublicacion) {
        this.anoPublicacion = anoPublicacion;
    }

    public int getNumeroPaginas() {
        return numeroPaginas;
    }

    public void setNumeroPaginas(int numeroPaginas) {
        this.numeroPaginas = numeroPaginas;
    }

    public String getIdioma() {
        return idioma;
    }

    public void setIdioma(String idioma) {
        this.idioma = idioma;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public int getCantidadTotal() {
        return cantidadTotal;
    }

    public void setCantidadTotal(int cantidadTotal) {
        this.cantidadTotal = cantidadTotal;
    }

    public int getCantidadDisponible() {
        return cantidadDisponible;
    }

    public void setCantidadDisponible(int cantidadDisponible) {
        this.cantidadDisponible = cantidadDisponible;
    }

    public BigDecimal getPrecioVenta() {
        return precioVenta;
    }

    public void setPrecioVenta(BigDecimal precioVenta) {
        this.precioVenta = precioVenta;
    }

    public boolean isDisponibleVenta() {
        return disponibleVenta;
    }

    public void setDisponibleVenta(boolean disponibleVenta) {
        this.disponibleVenta = disponibleVenta;
    }

    public LocalDateTime getFechaIngreso() {
        return fechaIngreso;
    }

    public void setFechaIngreso(LocalDateTime fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    public String getNombreCategoria() {
        return nombreCategoria;
    }

    public void setNombreCategoria(String nombreCategoria) {
        this.nombreCategoria = nombreCategoria;
    }

    public String getNombreEditorial() {
        return nombreEditorial;
    }

    public void setNombreEditorial(String nombreEditorial) {
        this.nombreEditorial = nombreEditorial;
    }

    public List<String> getAutores() {
        return autores;
    }

    public void setAutores(List<String> autores) {
        this.autores = autores;
    }

    // Métodos utilitarios
    public String getAutoresString() {
        if (autores == null || autores.isEmpty()) {
            return "Sin autor";
        }
        return String.join(", ", autores);
    }

    public boolean estaDisponible() {
        return cantidadDisponible > 0;
    }

    public String getEstadoDisponibilidad() {
        if (cantidadDisponible > 0) {
            return "Disponible (" + cantidadDisponible + ")";
        } else {
            return "No disponible";
        }
    }

    public boolean tienePrestamosActivos() {
        return cantidadTotal - cantidadDisponible > 0;
    }

    public int getCantidadPrestada() {
        return cantidadTotal - cantidadDisponible;
    }

    public void agregarAutor(String autor) {
        if (autores == null) {
            autores = new ArrayList<>();
        }
        if (!autores.contains(autor)) {
            autores.add(autor);
        }
    }

    public void removerAutor(String autor) {
        if (autores != null) {
            autores.remove(autor);
        }
    }

    public boolean coincideBusqueda(String termino) {
        if (termino == null || termino.trim().isEmpty()) {
            return true;
        }
        
        String terminoLower = termino.toLowerCase();
        
        return (titulo != null && titulo.toLowerCase().contains(terminoLower)) ||
               (isbn != null && isbn.toLowerCase().contains(terminoLower)) ||
               (codigoBarras != null && codigoBarras.toLowerCase().contains(terminoLower)) ||
               (nombreCategoria != null && nombreCategoria.toLowerCase().contains(terminoLower)) ||
               (nombreEditorial != null && nombreEditorial.toLowerCase().contains(terminoLower)) ||
               (autores != null && autores.stream().anyMatch(autor -> 
                   autor.toLowerCase().contains(terminoLower)));
    }

    @Override
    public String toString() {
        return "Libro{" +
                "idLibro=" + idLibro +
                ", titulo='" + titulo + '\'' +
                ", isbn='" + isbn + '\'' +
                ", autores=" + getAutoresString() +
                ", categoria='" + nombreCategoria + '\'' +
                ", disponible=" + cantidadDisponible +
                ", total=" + cantidadTotal +
                '}';
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Libro libro = (Libro) obj;
        return idLibro == libro.idLibro;
    }

    @Override
    public int hashCode() {
        return Integer.hashCode(idLibro);
    }
}
