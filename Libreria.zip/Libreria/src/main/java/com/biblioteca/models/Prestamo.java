package com.biblioteca.models;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Clase modelo para representar préstamos de libros
 */
public class Prestamo {
    private int idPrestamo;
    private int idUsuario;
    private int idLibro;
    private LocalDateTime fechaPrestamo;
    private LocalDate fechaDevolucionProgramada;
    private LocalDateTime fechaDevolucionReal;
    private String estado; // activo, devuelto, vencido, perdido
    private String observaciones;
    private BigDecimal multa;
    private boolean multaPagada;
    private int renovaciones;
    private int maxRenovaciones;
    
    // Información adicional de relaciones
    private String nombreUsuario;
    private String emailUsuario;
    private String tituloLibro;
    private String isbnLibro;

    // Constructores
    public Prestamo() {
        this.estado = "activo";
        this.fechaPrestamo = LocalDateTime.now();
        this.multa = BigDecimal.ZERO;
        this.multaPagada = false;
        this.renovaciones = 0;
        this.maxRenovaciones = 2;
    }

    public Prestamo(int idUsuario, int idLibro, LocalDate fechaDevolucionProgramada) {
        this();
        this.idUsuario = idUsuario;
        this.idLibro = idLibro;
        this.fechaDevolucionProgramada = fechaDevolucionProgramada;
    }

    // Getters y Setters
    public int getIdPrestamo() {
        return idPrestamo;
    }

    public void setIdPrestamo(int idPrestamo) {
        this.idPrestamo = idPrestamo;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public int getIdLibro() {
        return idLibro;
    }

    public void setIdLibro(int idLibro) {
        this.idLibro = idLibro;
    }

    public LocalDateTime getFechaPrestamo() {
        return fechaPrestamo;
    }

    public void setFechaPrestamo(LocalDateTime fechaPrestamo) {
        this.fechaPrestamo = fechaPrestamo;
    }

    public LocalDate getFechaDevolucionProgramada() {
        return fechaDevolucionProgramada;
    }

    public void setFechaDevolucionProgramada(LocalDate fechaDevolucionProgramada) {
        this.fechaDevolucionProgramada = fechaDevolucionProgramada;
    }

    public LocalDateTime getFechaDevolucionReal() {
        return fechaDevolucionReal;
    }

    public void setFechaDevolucionReal(LocalDateTime fechaDevolucionReal) {
        this.fechaDevolucionReal = fechaDevolucionReal;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public BigDecimal getMulta() {
        return multa;
    }

    public void setMulta(BigDecimal multa) {
        this.multa = multa;
    }

    public boolean isMultaPagada() {
        return multaPagada;
    }

    public void setMultaPagada(boolean multaPagada) {
        this.multaPagada = multaPagada;
    }

    public int getRenovaciones() {
        return renovaciones;
    }

    public void setRenovaciones(int renovaciones) {
        this.renovaciones = renovaciones;
    }

    public int getMaxRenovaciones() {
        return maxRenovaciones;
    }

    public void setMaxRenovaciones(int maxRenovaciones) {
        this.maxRenovaciones = maxRenovaciones;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getEmailUsuario() {
        return emailUsuario;
    }

    public void setEmailUsuario(String emailUsuario) {
        this.emailUsuario = emailUsuario;
    }

    public String getTituloLibro() {
        return tituloLibro;
    }

    public void setTituloLibro(String tituloLibro) {
        this.tituloLibro = tituloLibro;
    }

    public String getIsbnLibro() {
        return isbnLibro;
    }

    public void setIsbnLibro(String isbnLibro) {
        this.isbnLibro = isbnLibro;
    }

    // Métodos utilitarios
    public boolean estaActivo() {
        return "activo".equals(estado);
    }

    public boolean estaVencido() {
        return estaActivo() && fechaDevolucionProgramada.isBefore(LocalDate.now());
    }

    public boolean estaPorVencer() {
        return estaActivo() && 
               fechaDevolucionProgramada.minusDays(3).isBefore(LocalDate.now()) &&
               !estaVencido();
    }

    public long getDiasRetraso() {
        if (!estaVencido()) {
            return 0;
        }
        return LocalDate.now().toEpochDay() - fechaDevolucionProgramada.toEpochDay();
    }

    public long getDiasParaVencer() {
        if (estaVencido()) {
            return 0;
        }
        return fechaDevolucionProgramada.toEpochDay() - LocalDate.now().toEpochDay();
    }

    public boolean puedeRenovar() {
        return estaActivo() && renovaciones < maxRenovaciones && !estaVencido();
    }

    public String getEstadoDetallado() {
        if (!estaActivo()) {
            return estado;
        }
        
        if (estaVencido()) {
            return "Vencido (" + getDiasRetraso() + " días)";
        } else if (estaPorVencer()) {
            return "Por vencer (" + getDiasParaVencer() + " días)";
        } else {
            return "En tiempo";
        }
    }

    public void renovar(int diasExtension) {
        if (puedeRenovar()) {
            fechaDevolucionProgramada = fechaDevolucionProgramada.plusDays(diasExtension);
            renovaciones++;
        }
    }

    public void devolver() {
        this.estado = "devuelto";
        this.fechaDevolucionReal = LocalDateTime.now();
    }

    public void marcarComoPerdido() {
        this.estado = "perdido";
        this.fechaDevolucionReal = LocalDateTime.now();
    }

    @Override
    public String toString() {
        return "Prestamo{" +
                "idPrestamo=" + idPrestamo +
                ", usuario='" + nombreUsuario + '\'' +
                ", libro='" + tituloLibro + '\'' +
                ", fechaPrestamo=" + fechaPrestamo +
                ", fechaDevolucion=" + fechaDevolucionProgramada +
                ", estado='" + estado + '\'' +
                ", diasRetraso=" + (estaVencido() ? getDiasRetraso() : 0) +
                '}';
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Prestamo prestamo = (Prestamo) obj;
        return idPrestamo == prestamo.idPrestamo;
    }

    @Override
    public int hashCode() {
        return Integer.hashCode(idPrestamo);
    }
}
