package com.biblioteca.models;

import java.time.LocalDateTime;

/**
 * Clase modelo para representar usuarios del sistema
 */
public class Usuario {
    private int idUsuario;
    private String nombre;
    private String apellido;
    private String email;
    private String telefono;
    private String direccion;
    private String fechaNacimiento;
    private String tipoUsuario; // estudiante, docente, otro
    private int idRol;
    private String username;
    private String passwordHash;
    private byte[] fotoFacial;
    private boolean activo;
    private LocalDateTime fechaRegistro;
    private LocalDateTime ultimoAcceso;
    private int intentosFallidos;
    private boolean bloqueado;
    
    // Información adicional del rol
    private String nombreRol;

    // Constructores
    public Usuario() {}

    public Usuario(String nombre, String apellido, String email, String username, String passwordHash) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.email = email;
        this.username = username;
        this.passwordHash = passwordHash;
        this.activo = true;
        this.intentosFallidos = 0;
        this.bloqueado = false;
        this.fechaRegistro = LocalDateTime.now();
    }

    // Getters y Setters
    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(String fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getTipoUsuario() {
        return tipoUsuario;
    }

    public void setTipoUsuario(String tipoUsuario) {
        this.tipoUsuario = tipoUsuario;
    }

    public int getIdRol() {
        return idRol;
    }

    public void setIdRol(int idRol) {
        this.idRol = idRol;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public byte[] getFotoFacial() {
        return fotoFacial;
    }

    public void setFotoFacial(byte[] fotoFacial) {
        this.fotoFacial = fotoFacial;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    public LocalDateTime getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(LocalDateTime fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public LocalDateTime getUltimoAcceso() {
        return ultimoAcceso;
    }

    public void setUltimoAcceso(LocalDateTime ultimoAcceso) {
        this.ultimoAcceso = ultimoAcceso;
    }

    public int getIntentosFallidos() {
        return intentosFallidos;
    }

    public void setIntentosFallidos(int intentosFallidos) {
        this.intentosFallidos = intentosFallidos;
    }

    public boolean isBloqueado() {
        return bloqueado;
    }

    public void setBloqueado(boolean bloqueado) {
        this.bloqueado = bloqueado;
    }

    public String getNombreRol() {
        return nombreRol;
    }

    public void setNombreRol(String nombreRol) {
        this.nombreRol = nombreRol;
    }

    // Métodos utilitarios
    public String getNombreCompleto() {
        return nombre + " " + apellido;
    }

    public boolean esAdministrador() {
        return idRol == 1 || "Administrador".equals(nombreRol);
    }

    public boolean esBibliotecario() {
        return idRol == 2 || "Bibliotecario".equals(nombreRol);
    }

    public boolean esLector() {
        return idRol == 3 || "Lector".equals(nombreRol);
    }

    public boolean puedeGestionarLibros() {
        return esAdministrador() || esBibliotecario();
    }

    public boolean puedeGestionarUsuarios() {
        return esAdministrador();
    }

    public boolean puedeVerReportes() {
        return esAdministrador() || esBibliotecario();
    }

    @Override
    public String toString() {
        return "Usuario{" +
                "idUsuario=" + idUsuario +
                ", nombre='" + nombre + '\'' +
                ", apellido='" + apellido + '\'' +
                ", email='" + email + '\'' +
                ", username='" + username + '\'' +
                ", tipoUsuario='" + tipoUsuario + '\'' +
                ", nombreRol='" + nombreRol + '\'' +
                ", activo=" + activo +
                '}';
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Usuario usuario = (Usuario) obj;
        return idUsuario == usuario.idUsuario;
    }

    @Override
    public int hashCode() {
        return Integer.hashCode(idUsuario);
    }
}
