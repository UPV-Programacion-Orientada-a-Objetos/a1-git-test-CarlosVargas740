package com.biblioteca.services;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import com.biblioteca.database.PrestamoDAO;
import com.biblioteca.database.UsuarioDAO;
import com.biblioteca.models.Prestamo;
import com.biblioteca.models.Usuario;

/**
 * Servicio para gestionar alertas y sanciones del sistema
 */
public class AlertasService {
    
    private final PrestamoDAO prestamoDAO;
    private final UsuarioDAO usuarioDAO;
    
    public AlertasService() {
        this.prestamoDAO = new PrestamoDAO();
        this.usuarioDAO = new UsuarioDAO();
    }
    
    /**
     * Verifica y genera alertas para préstamos vencidos
     */
    public List<String> verificarPrestamosVencidos() {
        List<String> alertas = new ArrayList<>();
        
        try {
            List<Prestamo> todosPrestamos = prestamoDAO.obtenerPrestamos();
            LocalDate hoy = LocalDate.now();
            
            for (Prestamo prestamo : todosPrestamos) {
                if ("activo".equals(prestamo.getEstado()) && 
                    prestamo.getFechaDevolucionProgramada().isBefore(hoy)) {
                    
                    Usuario usuario = usuarioDAO.buscarPorId(prestamo.getIdUsuario());
                    
                    if (usuario != null) {
                        long diasVencido = ChronoUnit.DAYS.between(
                            prestamo.getFechaDevolucionProgramada(), 
                            hoy
                        );
                        
                        String alerta = String.format(
                            "PRÉSTAMO VENCIDO - Usuario: %s, Préstamo ID: %d, Días vencido: %d",
                            usuario.getNombreCompleto(),
                            prestamo.getIdPrestamo(),
                            diasVencido
                        );
                        
                        alertas.add(alerta);
                        
                        // Aplicar sanciones automáticas según días de atraso
                        aplicarSancionAutomatica(usuario, (int) diasVencido);
                    }
                }
            }
            
        } catch (Exception e) {
            alertas.add("Error al verificar préstamos vencidos: " + e.getMessage());
        }
        
        return alertas;
    }
    
    /**
     * Verifica préstamos próximos a vencer (en los próximos 3 días)
     */
    public List<String> verificarPrestamosProximosVencer() {
        List<String> alertas = new ArrayList<>();
        
        try {
            List<Prestamo> todosPrestamos = prestamoDAO.obtenerPrestamos();
            LocalDate hoy = LocalDate.now();
            LocalDate fechaLimite = hoy.plusDays(3);
            
            for (Prestamo prestamo : todosPrestamos) {
                if ("activo".equals(prestamo.getEstado()) && 
                    !prestamo.getFechaDevolucionProgramada().isBefore(hoy) &&
                    (prestamo.getFechaDevolucionProgramada().isBefore(fechaLimite) ||
                     prestamo.getFechaDevolucionProgramada().isEqual(fechaLimite))) {
                    
                    Usuario usuario = usuarioDAO.buscarPorId(prestamo.getIdUsuario());
                    
                    if (usuario != null) {
                        long diasRestantes = ChronoUnit.DAYS.between(
                            hoy,
                            prestamo.getFechaDevolucionProgramada()
                        );
                        
                        String alerta = String.format(
                            "PRÓXIMO A VENCER - Usuario: %s, Préstamo ID: %d, Días restantes: %d",
                            usuario.getNombreCompleto(),
                            prestamo.getIdPrestamo(),
                            diasRestantes
                        );
                        
                        alertas.add(alerta);
                    }
                }
            }
            
        } catch (Exception e) {
            alertas.add("Error al verificar préstamos próximos a vencer: " + e.getMessage());
        }
        
        return alertas;
    }
    
    /**
     * Aplica sanciones automáticas basadas en días de atraso
     */
    private void aplicarSancionAutomatica(Usuario usuario, int diasAtraso) {
        try {
            String tipoSancion = determinarTipoSancion(diasAtraso);
            
            if (!tipoSancion.equals("ninguna")) {
                // Aquí se registraría la sanción en la base de datos
                // Por ahora solo lo mostramos en consola
                System.out.println(String.format(
                    "Sanción aplicada a %s: %s (Días de atraso: %d)",
                    usuario.getNombreCompleto(),
                    tipoSancion,
                    diasAtraso
                ));
            }
            
        } catch (Exception e) {
            System.err.println("Error al aplicar sanción: " + e.getMessage());
        }
    }
    
    /**
     * Determina el tipo de sanción según los días de atraso
     */
    private String determinarTipoSancion(int diasAtraso) {
        if (diasAtraso <= 0) {
            return "ninguna";
        } else if (diasAtraso <= 7) {
            return "advertencia";
        } else if (diasAtraso <= 14) {
            return "suspensión 3 días";
        } else if (diasAtraso <= 30) {
            return "suspensión 7 días";
        } else {
            return "suspensión 15 días";
        }
    }
    
    /**
     * Muestra alertas en ventana emergente
     */
    public void mostrarAlertasEmergentes() {
        SwingUtilities.invokeLater(() -> {
            List<String> alertasVencidos = verificarPrestamosVencidos();
            List<String> alertasProximos = verificarPrestamosProximosVencer();
            
            if (!alertasVencidos.isEmpty() || !alertasProximos.isEmpty()) {
                StringBuilder mensaje = new StringBuilder();
                
                if (!alertasVencidos.isEmpty()) {
                    mensaje.append("=== PRÉSTAMOS VENCIDOS ===\n");
                    for (String alerta : alertasVencidos) {
                        mensaje.append(alerta).append("\n");
                    }
                    mensaje.append("\n");
                }
                
                if (!alertasProximos.isEmpty()) {
                    mensaje.append("=== PRÓXIMOS A VENCER ===\n");
                    for (String alerta : alertasProximos) {
                        mensaje.append(alerta).append("\n");
                    }
                }
                
                JOptionPane.showMessageDialog(null,
                    mensaje.toString(),
                    "Alertas del Sistema",
                    JOptionPane.WARNING_MESSAGE);
            }
        });
    }
    
    /**
     * Verifica si un usuario tiene sanciones activas
     */
    public boolean usuarioTieneSanciones(int idUsuario) {
        // Implementación básica - verifica si tiene préstamos vencidos
        try {
            List<Prestamo> todosPrestamos = prestamoDAO.obtenerPrestamos();
            LocalDate hoy = LocalDate.now();
            
            for (Prestamo prestamo : todosPrestamos) {
                if (prestamo.getIdUsuario() == idUsuario && 
                    "activo".equals(prestamo.getEstado()) &&
                    prestamo.getFechaDevolucionProgramada().isBefore(hoy)) {
                    return true;
                }
            }
            
            return false;
        } catch (Exception e) {
            System.err.println("Error verificando sanciones: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Calcula multa por días de atraso
     */
    public double calcularMulta(int diasAtraso) {
        if (diasAtraso <= 0) {
            return 0.0;
        }
        
        // $2 por día de atraso, máximo $50
        double multaBase = diasAtraso * 2.0;
        return Math.min(multaBase, 50.0);
    }
    
    /**
     * Genera reporte de sanciones
     */
    public String generarReporteSanciones() {
        StringBuilder reporte = new StringBuilder();
        reporte.append("REPORTE DE SANCIONES Y ALERTAS\n");
        reporte.append("==============================\n\n");
        
        List<String> alertasVencidos = verificarPrestamosVencidos();
        List<String> alertasProximos = verificarPrestamosProximosVencer();
        
        reporte.append("Préstamos vencidos: ").append(alertasVencidos.size()).append("\n");
        reporte.append("Préstamos próximos a vencer: ").append(alertasProximos.size()).append("\n\n");
        
        if (!alertasVencidos.isEmpty()) {
            reporte.append("DETALLES - PRÉSTAMOS VENCIDOS:\n");
            reporte.append("------------------------------\n");
            for (String alerta : alertasVencidos) {
                reporte.append(alerta).append("\n");
            }
            reporte.append("\n");
        }
        
        if (!alertasProximos.isEmpty()) {
            reporte.append("DETALLES - PRÓXIMOS A VENCER:\n");
            reporte.append("----------------------------\n");
            for (String alerta : alertasProximos) {
                reporte.append(alerta).append("\n");
            }
        }
        
        return reporte.toString();
    }
}
