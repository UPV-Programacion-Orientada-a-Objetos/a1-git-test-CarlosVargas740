package com.biblioteca.utils;

import com.biblioteca.models.Libro;
import com.biblioteca.models.Prestamo;
import com.biblioteca.models.Usuario;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Utilidades para filtrado avanzado de datos
 */
public class FiltroUtils {
    
    /**
     * Filtra libros por disponibilidad
     */
    public static List<Libro> filtrarPorDisponibilidad(List<Libro> libros, boolean soloDisponibles) {
        if (!soloDisponibles) {
            return libros;
        }
        
        return libros.stream()
                    .filter(libro -> libro.getCantidadDisponible() > 0)
                    .collect(Collectors.toList());
    }
    
    /**
     * Filtra libros por rango de años
     */
    public static List<Libro> filtrarPorAno(List<Libro> libros, Integer anoDesde, Integer anoHasta) {
        if (anoDesde == null && anoHasta == null) {
            return libros;
        }
        
        return libros.stream()
                    .filter(libro -> {
                        int ano = libro.getAnoPublicacion();
                        boolean cumpleDesde = anoDesde == null || ano >= anoDesde;
                        boolean cumpleHasta = anoHasta == null || ano <= anoHasta;
                        return cumpleDesde && cumpleHasta;
                    })
                    .collect(Collectors.toList());
    }
    
    /**
     * Filtra libros por idioma
     */
    public static List<Libro> filtrarPorIdioma(List<Libro> libros, String idioma) {
        if (idioma == null || idioma.trim().isEmpty() || "Todos".equals(idioma)) {
            return libros;
        }
        
        return libros.stream()
                    .filter(libro -> idioma.equalsIgnoreCase(libro.getIdioma()))
                    .collect(Collectors.toList());
    }
    
    /**
     * Filtra libros por disponibilidad para venta
     */
    public static List<Libro> filtrarPorVenta(List<Libro> libros, Boolean paraVenta) {
        if (paraVenta == null) {
            return libros;
        }
        
        return libros.stream()
                    .filter(libro -> paraVenta.equals(libro.isDisponibleVenta()))
                    .collect(Collectors.toList());
    }
    
    /**
     * Filtra libros que contienen texto en título, autor o descripción
     */
    public static List<Libro> buscarTextoGeneral(List<Libro> libros, String texto) {
        if (texto == null || texto.trim().isEmpty()) {
            return libros;
        }
        
        String textoBusqueda = texto.toLowerCase();
        
        return libros.stream()
                    .filter(libro -> 
                        libro.getTitulo().toLowerCase().contains(textoBusqueda) ||
                        libro.getAutoresString().toLowerCase().contains(textoBusqueda) ||
                        (libro.getDescripcion() != null && libro.getDescripcion().toLowerCase().contains(textoBusqueda)) ||
                        (libro.getIsbn() != null && libro.getIsbn().toLowerCase().contains(textoBusqueda))
                    )
                    .collect(Collectors.toList());
    }
    
    /**
     * Filtra usuarios por tipo
     */
    public static List<Usuario> filtrarUsuariosPorTipo(List<Usuario> usuarios, String tipoUsuario) {
        if (tipoUsuario == null || tipoUsuario.trim().isEmpty() || "Todos".equals(tipoUsuario)) {
            return usuarios;
        }
        
        return usuarios.stream()
                    .filter(usuario -> tipoUsuario.equalsIgnoreCase(usuario.getTipoUsuario()))
                    .collect(Collectors.toList());
    }
    
    /**
     * Filtra usuarios activos/inactivos
     */
    public static List<Usuario> filtrarUsuariosPorEstado(List<Usuario> usuarios, Boolean soloActivos) {
        if (soloActivos == null) {
            return usuarios;
        }
        
        return usuarios.stream()
                    .filter(usuario -> soloActivos.equals(usuario.isActivo()))
                    .collect(Collectors.toList());
    }
    
    /**
     * Filtra préstamos por estado
     */
    public static List<Prestamo> filtrarPrestamosPorEstado(List<Prestamo> prestamos, String estado) {
        if (estado == null || estado.trim().isEmpty() || "Todos".equals(estado)) {
            return prestamos;
        }
        
        return prestamos.stream()
                    .filter(prestamo -> estado.equalsIgnoreCase(prestamo.getEstado()))
                    .collect(Collectors.toList());
    }
    
    /**
     * Filtra préstamos por rango de fechas
     */
    public static List<Prestamo> filtrarPrestamosPorFecha(List<Prestamo> prestamos, 
                                                         LocalDate fechaDesde, LocalDate fechaHasta) {
        if (fechaDesde == null && fechaHasta == null) {
            return prestamos;
        }
        
        return prestamos.stream()
                    .filter(prestamo -> {
                        LocalDate fechaPrestamo = prestamo.getFechaPrestamo().toLocalDate();
                        boolean cumpleDesde = fechaDesde == null || !fechaPrestamo.isBefore(fechaDesde);
                        boolean cumpleHasta = fechaHasta == null || !fechaPrestamo.isAfter(fechaHasta);
                        return cumpleDesde && cumpleHasta;
                    })
                    .collect(Collectors.toList());
    }
    
    /**
     * Filtra préstamos próximos a vencer
     */
    public static List<Prestamo> filtrarPrestamosProximosVencer(List<Prestamo> prestamos, int diasAnticipacion) {
        LocalDate fechaLimite = LocalDate.now().plusDays(diasAnticipacion);
        
        return prestamos.stream()
                    .filter(prestamo -> 
                        "activo".equalsIgnoreCase(prestamo.getEstado()) &&
                        !prestamo.getFechaDevolucionProgramada().isAfter(fechaLimite)
                    )
                    .collect(Collectors.toList());
    }
    
    /**
     * Busca usuarios por texto en nombre, email o teléfono
     */
    public static List<Usuario> buscarUsuarios(List<Usuario> usuarios, String texto) {
        if (texto == null || texto.trim().isEmpty()) {
            return usuarios;
        }
        
        String textoBusqueda = texto.toLowerCase();
        
        return usuarios.stream()
                    .filter(usuario -> 
                        usuario.getNombreCompleto().toLowerCase().contains(textoBusqueda) ||
                        usuario.getEmail().toLowerCase().contains(textoBusqueda) ||
                        usuario.getUsername().toLowerCase().contains(textoBusqueda) ||
                        (usuario.getTelefono() != null && usuario.getTelefono().contains(textoBusqueda))
                    )
                    .collect(Collectors.toList());
    }
    
    /**
     * Ordena libros por criterio específico
     */
    public static List<Libro> ordenarLibros(List<Libro> libros, String criterio) {
        switch (criterio) {
            case "titulo":
                return libros.stream()
                            .sorted((a, b) -> a.getTitulo().compareToIgnoreCase(b.getTitulo()))
                            .collect(Collectors.toList());
            case "autor":
                return libros.stream()
                            .sorted((a, b) -> a.getAutoresString().compareToIgnoreCase(b.getAutoresString()))
                            .collect(Collectors.toList());
            case "ano":
                return libros.stream()
                            .sorted((a, b) -> Integer.compare(b.getAnoPublicacion(), a.getAnoPublicacion()))
                            .collect(Collectors.toList());
            case "disponibilidad":
                return libros.stream()
                            .sorted((a, b) -> Integer.compare(b.getCantidadDisponible(), a.getCantidadDisponible()))
                            .collect(Collectors.toList());
            default:
                return libros;
        }
    }
    
    /**
     * Ordena usuarios por criterio específico
     */
    public static List<Usuario> ordenarUsuarios(List<Usuario> usuarios, String criterio) {
        switch (criterio) {
            case "nombre":
                return usuarios.stream()
                              .sorted((a, b) -> a.getNombreCompleto().compareToIgnoreCase(b.getNombreCompleto()))
                              .collect(Collectors.toList());
            case "email":
                return usuarios.stream()
                              .sorted((a, b) -> a.getEmail().compareToIgnoreCase(b.getEmail()))
                              .collect(Collectors.toList());
            case "tipo":
                return usuarios.stream()
                              .sorted((a, b) -> a.getTipoUsuario().compareToIgnoreCase(b.getTipoUsuario()))
                              .collect(Collectors.toList());
            case "fecha_registro":
                return usuarios.stream()
                              .sorted((a, b) -> {
                                  LocalDateTime fechaA = a.getFechaRegistro() != null ? a.getFechaRegistro() : LocalDateTime.MIN;
                                  LocalDateTime fechaB = b.getFechaRegistro() != null ? b.getFechaRegistro() : LocalDateTime.MIN;
                                  return fechaB.compareTo(fechaA);
                              })
                              .collect(Collectors.toList());
            default:
                return usuarios;
        }
    }
    
    /**
     * Ordena préstamos por criterio específico
     */
    public static List<Prestamo> ordenarPrestamos(List<Prestamo> prestamos, String criterio) {
        switch (criterio) {
            case "fecha_prestamo":
                return prestamos.stream()
                               .sorted((a, b) -> b.getFechaPrestamo().compareTo(a.getFechaPrestamo()))
                               .collect(Collectors.toList());
            case "fecha_vencimiento":
                return prestamos.stream()
                               .sorted((a, b) -> a.getFechaDevolucionProgramada().compareTo(b.getFechaDevolucionProgramada()))
                               .collect(Collectors.toList());
            case "usuario":
                return prestamos.stream()
                               .sorted((a, b) -> {
                                   String nombreA = a.getNombreUsuario() != null ? a.getNombreUsuario() : "";
                                   String nombreB = b.getNombreUsuario() != null ? b.getNombreUsuario() : "";
                                   return nombreA.compareToIgnoreCase(nombreB);
                               })
                               .collect(Collectors.toList());
            case "libro":
                return prestamos.stream()
                               .sorted((a, b) -> {
                                   String tituloA = a.getTituloLibro() != null ? a.getTituloLibro() : "";
                                   String tituloB = b.getTituloLibro() != null ? b.getTituloLibro() : "";
                                   return tituloA.compareToIgnoreCase(tituloB);
                               })
                               .collect(Collectors.toList());
            default:
                return prestamos;
        }
    }
}
