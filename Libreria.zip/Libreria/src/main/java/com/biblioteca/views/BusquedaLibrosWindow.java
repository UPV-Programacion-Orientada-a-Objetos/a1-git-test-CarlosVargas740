package com.biblioteca.views;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.biblioteca.database.LibroDAO;
import com.biblioteca.database.PrestamoDAO;
import com.biblioteca.database.UsuarioDAO;
import com.biblioteca.models.Libro;
import com.biblioteca.models.Usuario;

/**
 * Ventana para búsqueda avanzada de libros
 */
public class BusquedaLibrosWindow extends JFrame {
    
    private final Usuario usuarioActual;
    private final LibroDAO libroDAO;
    
    private JPanel contentPane;
    private JTextField buscarField;
    private JComboBox<String> categoriaCombo;
    private JComboBox<String> editorialCombo;
    private JCheckBox disponiblesCheck;
    private JTable librosTable;
    private DefaultTableModel tableModel;
    private JButton buscarButton;
    private JButton limpiarButton;
    private JButton prestamoButton;
    private JButton verDetallesButton;
    private JLabel statusLabel;
    private JLabel resultadosLabel;

    public BusquedaLibrosWindow(Usuario usuarioActual) {
        this.usuarioActual = usuarioActual;
        this.libroDAO = new LibroDAO();
        
        try {
            initializeComponents();
            setupLayout();
            setupEvents();
            cargarCombos();
            
            setTitle("Búsqueda de Libros - " + usuarioActual.getNombreCompleto());
            setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            pack();
            setLocationRelativeTo(null);
        } catch (Exception e) {
            System.err.println("Error al inicializar BusquedaLibrosWindow: " + e.getMessage());
            e.printStackTrace();
            // Asegurar ventana básica si hay error
            setTitle("Búsqueda de Libros - Error de Inicialización");
            setSize(800, 600);
            setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            setLocationRelativeTo(null);
        }
    }

    private void initializeComponents() {
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(15, 15, 15, 15));
        setContentPane(contentPane);

        // Campos de búsqueda
        buscarField = new JTextField(25);
        categoriaCombo = new JComboBox<>();
        categoriaCombo.addItem("Todas las categorías");
        editorialCombo = new JComboBox<>();
        editorialCombo.addItem("Todas las editoriales");
        disponiblesCheck = new JCheckBox("Solo libros disponibles", true);

        // Tabla de resultados
        String[] columnNames = {
            "ID", "Título", "Autor", "ISBN", "Editorial", 
            "Categoría", "Año", "Disponibles", "Total"
        };
        
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        librosTable = new JTable(tableModel);
        librosTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        librosTable.getTableHeader().setReorderingAllowed(false);
        
        // Ajustar ancho de columnas
        librosTable.getColumnModel().getColumn(0).setPreferredWidth(50);   // ID
        librosTable.getColumnModel().getColumn(1).setPreferredWidth(200);  // Título
        librosTable.getColumnModel().getColumn(2).setPreferredWidth(150);  // Autor
        librosTable.getColumnModel().getColumn(3).setPreferredWidth(120);  // ISBN
        librosTable.getColumnModel().getColumn(4).setPreferredWidth(120);  // Editorial
        librosTable.getColumnModel().getColumn(5).setPreferredWidth(100);  // Categoría
        librosTable.getColumnModel().getColumn(6).setPreferredWidth(60);   // Año
        librosTable.getColumnModel().getColumn(7).setPreferredWidth(80);   // Disponibles
        librosTable.getColumnModel().getColumn(8).setPreferredWidth(60);   // Total

        // Botones
        buscarButton = new JButton("Buscar");
        limpiarButton = new JButton("Limpiar");
        prestamoButton = new JButton("Solicitar Préstamo");
        verDetallesButton = new JButton("Ver Detalles");
        
        // Labels de estado
        resultadosLabel = new JLabel("0 libros encontrados");
        statusLabel = new JLabel("Ingrese criterios de búsqueda");
    }

    private void setupLayout() {
        contentPane.setLayout(new BorderLayout());

        // Panel superior - criterios de búsqueda
        JPanel searchPanel = new JPanel(new GridBagLayout());
        searchPanel.setBorder(BorderFactory.createTitledBorder("Criterios de Búsqueda"));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        
        gbc.gridx = 0; gbc.gridy = 0; gbc.anchor = GridBagConstraints.WEST;
        searchPanel.add(new JLabel("Buscar:"), gbc);
        
        gbc.gridx = 1; gbc.gridy = 0; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        searchPanel.add(buscarField, gbc);
        
        gbc.gridx = 2; gbc.gridy = 0; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        searchPanel.add(buscarButton, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1;
        searchPanel.add(new JLabel("Categoría:"), gbc);
        
        gbc.gridx = 1; gbc.gridy = 1; gbc.fill = GridBagConstraints.HORIZONTAL;
        searchPanel.add(categoriaCombo, gbc);
        
        gbc.gridx = 2; gbc.gridy = 1; gbc.fill = GridBagConstraints.NONE;
        searchPanel.add(limpiarButton, gbc);
        
        gbc.gridx = 0; gbc.gridy = 2;
        searchPanel.add(new JLabel("Editorial:"), gbc);
        
        gbc.gridx = 1; gbc.gridy = 2; gbc.fill = GridBagConstraints.HORIZONTAL;
        searchPanel.add(editorialCombo, gbc);
        
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        searchPanel.add(disponiblesCheck, gbc);

        // Panel central - tabla de resultados
        JScrollPane scrollPane = new JScrollPane(librosTable);
        scrollPane.setPreferredSize(new Dimension(900, 400));
        
        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.setBorder(BorderFactory.createTitledBorder("Resultados"));
        centerPanel.add(scrollPane, BorderLayout.CENTER);
        
        JPanel resultPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        resultPanel.add(resultadosLabel);
        centerPanel.add(resultPanel, BorderLayout.NORTH);

        // Panel inferior - botones de acción
        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.Y_AXIS));
        
        JPanel buttonsPanel = new JPanel(new FlowLayout());
        buttonsPanel.add(prestamoButton);
        buttonsPanel.add(verDetallesButton);
        
        JPanel statusPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        statusPanel.add(statusLabel);
        
        bottomPanel.add(buttonsPanel);
        bottomPanel.add(statusPanel);

        contentPane.add(searchPanel, BorderLayout.NORTH);
        contentPane.add(centerPanel, BorderLayout.CENTER);
        contentPane.add(bottomPanel, BorderLayout.SOUTH);
    }

    private void setupEvents() {
        buscarButton.addActionListener(e -> realizarBusqueda());
        
        buscarField.addActionListener(e -> realizarBusqueda());
        
        limpiarButton.addActionListener(e -> limpiarFormulario());
        
        prestamoButton.addActionListener(e -> solicitarPrestamo());
        
        verDetallesButton.addActionListener(e -> verDetallesLibro());
        
        librosTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                actualizarEstadoBotones();
            }
        });
    }

    private void cargarCombos() {
        try {
            // Por simplicidad, no cargaremos datos dinámicos de categorías y editoriales
            // En una implementación completa, se consultaría la base de datos
            categoriaCombo.addItem("Ficción");
            categoriaCombo.addItem("No Ficción");
            categoriaCombo.addItem("Ciencia");
            categoriaCombo.addItem("Historia");
            categoriaCombo.addItem("Arte");
            
            editorialCombo.addItem("Planeta");
            editorialCombo.addItem("Santillana");
            editorialCombo.addItem("Penguin");
            editorialCombo.addItem("McGraw-Hill");
        } catch (Exception e) {
            System.err.println("Error al cargar combos: " + e.getMessage());
        }
    }

    private void realizarBusqueda() {
        SwingUtilities.invokeLater(() -> {
            try {
                String criterio = buscarField.getText().trim();
                
                // Si no hay criterio y no hay filtros, mostrar todos los libros
                if (criterio.isEmpty() && categoriaCombo.getSelectedIndex() == 0 && 
                    editorialCombo.getSelectedIndex() == 0) {
                    criterio = ""; // Buscar todos
                }
                
                // Para este ejemplo, solo usar criterio de búsqueda de texto
                // En una implementación completa, se necesitarían mapas de ID reales
                Integer categoriaId = null; // Simplificado para evitar errores
                Integer editorialId = null; // Simplificado para evitar errores
                
                List<Libro> libros = libroDAO.buscarLibros(criterio, categoriaId, editorialId, null, null);
                
                // Filtrar por disponibilidad si está marcado
                if (disponiblesCheck.isSelected()) {
                    libros = libros.stream()
                        .filter(libro -> libro.getCantidadDisponible() > 0)
                        .collect(java.util.stream.Collectors.toList());
                }
                
                mostrarResultados(libros);
                
            } catch (Exception e) {
                statusLabel.setText("Error en la búsqueda: " + e.getMessage());
                JOptionPane.showMessageDialog(this,
                    "Error al realizar la búsqueda: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private void mostrarResultados(List<Libro> libros) {
        tableModel.setRowCount(0);
        
        for (Libro libro : libros) {
            Object[] row = {
                libro.getIdLibro(),
                libro.getTitulo(),
                libro.getAutoresString(),
                libro.getIsbn(),
                libro.getNombreEditorial() != null ? libro.getNombreEditorial() : "N/A",
                libro.getNombreCategoria() != null ? libro.getNombreCategoria() : "N/A",
                libro.getAnoPublicacion(),
                libro.getCantidadDisponible(),
                libro.getCantidadTotal()
            };
            tableModel.addRow(row);
        }
        
        resultadosLabel.setText(libros.size() + " libro(s) encontrado(s)");
        statusLabel.setText("Búsqueda completada");
        
        actualizarEstadoBotones();
    }

    private void limpiarFormulario() {
        buscarField.setText("");
        categoriaCombo.setSelectedIndex(0);
        editorialCombo.setSelectedIndex(0);
        disponiblesCheck.setSelected(true);
        tableModel.setRowCount(0);
        resultadosLabel.setText("0 libros encontrados");
        statusLabel.setText("Formulario limpiado");
    }

    private void solicitarPrestamo() {
        int selectedRow = librosTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this,
                "Por favor seleccione un libro para solicitar préstamo.",
                "Selección Requerida",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int libroId = (Integer) tableModel.getValueAt(selectedRow, 0);
        String titulo = (String) tableModel.getValueAt(selectedRow, 1);
        int disponibles = (Integer) tableModel.getValueAt(selectedRow, 7);
        
        if (disponibles <= 0) {
            JOptionPane.showMessageDialog(this,
                "Este libro no está disponible para préstamo.",
                "Libro No Disponible",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int confirmacion = JOptionPane.showConfirmDialog(this,
            "¿Desea solicitar préstamo del libro:\n\"" + titulo + "\"?",
            "Confirmar Préstamo",
            JOptionPane.YES_NO_OPTION);
        
        if (confirmacion == JOptionPane.YES_OPTION) {
            try {
                // Abrir diálogo de nuevo préstamo con el libro preseleccionado
                LibroDAO libroDAO = new LibroDAO();
                UsuarioDAO usuarioDAO = new UsuarioDAO();
                PrestamoDAO prestamoDAO = new PrestamoDAO();
                
                NuevoPrestamoDialog dialog = new NuevoPrestamoDialog(this, usuarioActual, libroDAO, usuarioDAO, prestamoDAO);
                dialog.setVisible(true);
                
                if (dialog.isPrestamoCreado()) {
                    // Actualizar la búsqueda para reflejar la nueva disponibilidad
                    realizarBusqueda();
                }
                
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this,
                    "Error al abrir solicitud de préstamo: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void verDetallesLibro() {
        int selectedRow = librosTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this,
                "Por favor seleccione un libro para ver los detalles.",
                "Selección Requerida",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int libroId = (Integer) tableModel.getValueAt(selectedRow, 0);
        
        try {
            Libro libro = libroDAO.buscarPorId(libroId);
            
            if (libro != null) {
                StringBuilder detalles = new StringBuilder();
                detalles.append("<html><body style='width: 400px'>");
                detalles.append("<h3>Detalles del Libro</h3>");
                detalles.append("<b>Título:</b> ").append(libro.getTitulo()).append("<br>");
                detalles.append("<b>Autor:</b> ").append(libro.getAutoresString()).append("<br>");
                detalles.append("<b>ISBN:</b> ").append(libro.getIsbn()).append("<br>");
                detalles.append("<b>Editorial:</b> ").append(libro.getNombreEditorial() != null ? libro.getNombreEditorial() : "N/A").append("<br>");
                detalles.append("<b>Categoría:</b> ").append(libro.getNombreCategoria() != null ? libro.getNombreCategoria() : "N/A").append("<br>");
                detalles.append("<b>Año de Publicación:</b> ").append(libro.getAnoPublicacion()).append("<br>");
                detalles.append("<b>Páginas:</b> ").append(libro.getNumeroPaginas()).append("<br>");
                detalles.append("<b>Idioma:</b> ").append(libro.getIdioma()).append("<br>");
                detalles.append("<b>Ubicación:</b> ").append(libro.getUbicacion()).append("<br>");
                detalles.append("<b>Cantidad Total:</b> ").append(libro.getCantidadTotal()).append("<br>");
                detalles.append("<b>Cantidad Disponible:</b> ").append(libro.getCantidadDisponible()).append("<br>");
                
                if (libro.getDescripcion() != null && !libro.getDescripcion().trim().isEmpty()) {
                    detalles.append("<br><b>Descripción:</b><br>").append(libro.getDescripcion()).append("<br>");
                }
                
                detalles.append("</body></html>");
                
                JOptionPane.showMessageDialog(this,
                    detalles.toString(),
                    "Detalles del Libro",
                    JOptionPane.INFORMATION_MESSAGE);
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Error al obtener detalles del libro: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void actualizarEstadoBotones() {
        int selectedRow = librosTable.getSelectedRow();
        boolean haySeleccion = selectedRow != -1;
        
        prestamoButton.setEnabled(haySeleccion);
        verDetallesButton.setEnabled(haySeleccion);
        
        if (haySeleccion) {
            int disponibles = (Integer) tableModel.getValueAt(selectedRow, 7);
            prestamoButton.setEnabled(disponibles > 0);
        }
    }
}
