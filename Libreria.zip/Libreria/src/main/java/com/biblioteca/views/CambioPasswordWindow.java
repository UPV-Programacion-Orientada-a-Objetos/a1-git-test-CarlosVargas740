package com.biblioteca.views;

import com.biblioteca.database.UsuarioDAO;
import com.biblioteca.models.Usuario;
import com.biblioteca.services.FaceAuthenticationService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Ventana para cambio de contraseña
 */
public class CambioPasswordWindow extends JDialog {
    
    private final Usuario usuarioActual;
    private final UsuarioDAO usuarioDAO;
    private final FaceAuthenticationService faceAuthService;
    
    private JPanel contentPane;
    private JPasswordField currentPasswordField;
    private JPasswordField newPasswordField;
    private JPasswordField confirmPasswordField;
    private JButton cambiarButton;
    private JButton cancelarButton;
    private JButton verificarFaceButton;
    private JLabel statusLabel;
    private boolean faceVerified = false;

    public CambioPasswordWindow(Frame parent, Usuario usuarioActual) {
        super(parent, "Cambio de Contraseña", true);
        this.usuarioActual = usuarioActual;
        this.usuarioDAO = new UsuarioDAO();
        this.faceAuthService = new FaceAuthenticationService();
        
        initializeComponents();
        setupLayout();
        setupEvents();
        
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(parent);
        pack();
    }

    private void initializeComponents() {
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(20, 20, 20, 20));
        setContentPane(contentPane);

        // Campos de contraseña
        currentPasswordField = new JPasswordField(20);
        newPasswordField = new JPasswordField(20);
        confirmPasswordField = new JPasswordField(20);
        
        // Botones
        cambiarButton = new JButton("Cambiar Contraseña");
        cancelarButton = new JButton("Cancelar");
        verificarFaceButton = new JButton("Verificar Rostro");
        
        statusLabel = new JLabel("Ingrese su contraseña actual para continuar");
        statusLabel.setHorizontalAlignment(SwingConstants.CENTER);
    }

    private void setupLayout() {
        contentPane.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        // Título
        JLabel titleLabel = new JLabel("Cambio de Contraseña");
        titleLabel.setFont(titleLabel.getFont().deriveFont(Font.BOLD, 16f));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2; gbc.fill = GridBagConstraints.HORIZONTAL;
        contentPane.add(titleLabel, gbc);
        
        // Usuario actual
        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 2;
        contentPane.add(new JLabel("Usuario: " + usuarioActual.getNombreCompleto()), gbc);
        
        // Separador
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2; gbc.fill = GridBagConstraints.HORIZONTAL;
        contentPane.add(new JSeparator(), gbc);
        
        // Verificación facial
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 1; gbc.fill = GridBagConstraints.NONE;
        contentPane.add(new JLabel("Verificación de seguridad:"), gbc);
        
        gbc.gridx = 1; gbc.gridy = 3; gbc.fill = GridBagConstraints.HORIZONTAL;
        contentPane.add(verificarFaceButton, gbc);
        
        // Contraseña actual
        gbc.gridx = 0; gbc.gridy = 4; gbc.anchor = GridBagConstraints.EAST;
        contentPane.add(new JLabel("Contraseña actual:"), gbc);
        
        gbc.gridx = 1; gbc.gridy = 4; gbc.fill = GridBagConstraints.HORIZONTAL;
        contentPane.add(currentPasswordField, gbc);
        
        // Nueva contraseña
        gbc.gridx = 0; gbc.gridy = 5;
        contentPane.add(new JLabel("Nueva contraseña:"), gbc);
        
        gbc.gridx = 1; gbc.gridy = 5;
        contentPane.add(newPasswordField, gbc);
        
        // Confirmar contraseña
        gbc.gridx = 0; gbc.gridy = 6;
        contentPane.add(new JLabel("Confirmar contraseña:"), gbc);
        
        gbc.gridx = 1; gbc.gridy = 6;
        contentPane.add(confirmPasswordField, gbc);
        
        // Panel de botones
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(cambiarButton);
        buttonPanel.add(cancelarButton);
        
        gbc.gridx = 0; gbc.gridy = 7; gbc.gridwidth = 2; gbc.fill = GridBagConstraints.HORIZONTAL;
        contentPane.add(buttonPanel, gbc);
        
        // Status
        gbc.gridx = 0; gbc.gridy = 8; gbc.gridwidth = 2;
        contentPane.add(statusLabel, gbc);
        
        // Inicialmente deshabilitar el botón de cambiar
        cambiarButton.setEnabled(false);
    }

    private void setupEvents() {
        verificarFaceButton.addActionListener(e -> verificarRostro());
        
        cambiarButton.addActionListener(e -> cambiarContrasena());
        
        cancelarButton.addActionListener(e -> dispose());
        
        // Habilitar botón cuando todos los campos estén llenos y face verificado
        ActionListener checkFields = e -> validarFormulario();
        
        currentPasswordField.addActionListener(checkFields);
        newPasswordField.addActionListener(checkFields);
        confirmPasswordField.addActionListener(checkFields);
    }

    private void verificarRostro() {
        statusLabel.setText("Iniciando verificación facial...");
        
        SwingUtilities.invokeLater(() -> {
            try {
                // Simulamos la captura y verificación facial
                int resultado = JOptionPane.showConfirmDialog(this,
                    "¿Desea proceder con la verificación facial?\n" +
                    "(Simulado - En producción usaría cámara web)",
                    "Verificación Facial",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE);
                
                if (resultado == JOptionPane.YES_OPTION) {
                    // Simular verificación exitosa
                    faceVerified = true;
                    verificarFaceButton.setText("✓ Verificado");
                    verificarFaceButton.setEnabled(false);
                    verificarFaceButton.setBackground(new Color(144, 238, 144));
                    statusLabel.setText("Verificación facial exitosa. Complete los campos.");
                } else {
                    faceVerified = false;
                    statusLabel.setText("Verificación facial cancelada.");
                }
                
                validarFormulario();
                
            } catch (Exception e) {
                statusLabel.setText("Error en verificación facial: " + e.getMessage());
                faceVerified = false;
            }
        });
    }

    private void validarFormulario() {
        boolean todosLosCamposLlenos = 
            currentPasswordField.getPassword().length > 0 &&
            newPasswordField.getPassword().length > 0 &&
            confirmPasswordField.getPassword().length > 0;
        
        cambiarButton.setEnabled(faceVerified && todosLosCamposLlenos);
    }

    private void cambiarContrasena() {
        String currentPassword = new String(currentPasswordField.getPassword());
        String newPassword = new String(newPasswordField.getPassword());
        String confirmPassword = new String(confirmPasswordField.getPassword());
        
        // Validaciones
        if (!newPassword.equals(confirmPassword)) {
            JOptionPane.showMessageDialog(this,
                "La nueva contraseña y la confirmación no coinciden.",
                "Error de Validación",
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (newPassword.length() < 6) {
            JOptionPane.showMessageDialog(this,
                "La nueva contraseña debe tener al menos 6 caracteres.",
                "Error de Validación",
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (newPassword.equals(currentPassword)) {
            JOptionPane.showMessageDialog(this,
                "La nueva contraseña debe ser diferente a la actual.",
                "Error de Validación",
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        statusLabel.setText("Procesando cambio de contraseña...");
        
        SwingUtilities.invokeLater(() -> {
            try {
                // Verificar contraseña actual
                String currentPasswordHash = hashPassword(currentPassword);
                Usuario usuarioVerificacion = usuarioDAO.autenticarUsuario(
                    usuarioActual.getUsername(), currentPassword);
                
                if (usuarioVerificacion == null) {
                    JOptionPane.showMessageDialog(this,
                        "La contraseña actual es incorrecta.",
                        "Error de Autenticación",
                        JOptionPane.ERROR_MESSAGE);
                    statusLabel.setText("Contraseña actual incorrecta.");
                    return;
                }
                
                // Cambiar contraseña
                String newPasswordHash = hashPassword(newPassword);
                boolean exito = usuarioDAO.cambiarContrasena(
                    usuarioActual.getIdUsuario(), newPasswordHash);
                
                if (exito) {
                    JOptionPane.showMessageDialog(this,
                        "Contraseña cambiada exitosamente.\n" +
                        "La nueva contraseña entrará en efecto en el próximo inicio de sesión.",
                        "Cambio Exitoso",
                        JOptionPane.INFORMATION_MESSAGE);
                    
                    statusLabel.setText("Contraseña cambiada exitosamente");
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(this,
                        "Error al cambiar la contraseña. Intente nuevamente.",
                        "Error del Sistema",
                        JOptionPane.ERROR_MESSAGE);
                    statusLabel.setText("Error al cambiar contraseña");
                }
                
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this,
                    "Error crítico: " + e.getMessage(),
                    "Error Fatal",
                    JOptionPane.ERROR_MESSAGE);
                statusLabel.setText("Error crítico: " + e.getMessage());
            } finally {
                // Limpiar campos por seguridad
                currentPasswordField.setText("");
                newPasswordField.setText("");
                confirmPasswordField.setText("");
            }
        });
    }

    /**
     * Genera hash SHA-256 de la contraseña
     */
    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(password.getBytes());
            
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Error generando hash de contraseña", e);
        }
    }
}
