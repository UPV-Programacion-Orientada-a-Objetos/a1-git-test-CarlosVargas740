package com.biblioteca.views;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.biblioteca.database.LibroDAO;
import com.biblioteca.database.PrestamoDAO;
import com.biblioteca.database.UsuarioDAO;
import com.biblioteca.models.Prestamo;
import com.biblioteca.models.Usuario;

/**
 * Ventana para gestión de préstamos
 */
public class GestionPrestamosWindow extends JFrame {
    
    private final Usuario usuarioActual;
    private final PrestamoDAO prestamoDAO;
    private final LibroDAO libroDAO;
    private final UsuarioDAO usuarioDAO;
    
    private JPanel contentPane;
    private JTextField buscarField;
    private JTable prestamosTable;
    private DefaultTableModel tableModel;
    private JButton buscarButton;
    private JButton nuevoPrestamoButton;
    private JButton devolverButton;
    private JButton renovarButton;
    private JButton verDetallesButton;
    private JButton actualizarButton;
    private JComboBox<String> filtroEstadoCombo;
    private JLabel statusLabel;

    public GestionPrestamosWindow(Usuario usuarioActual) {
        this.usuarioActual = usuarioActual;
        this.prestamoDAO = new PrestamoDAO();
        this.libroDAO = new LibroDAO();
        this.usuarioDAO = new UsuarioDAO();
        
        initializeComponents();
        setupLayout();
        setupEvents();
        cargarPrestamos();
        
        setTitle("Gestión de Préstamos - " + usuarioActual.getNombreCompleto());
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        pack();
        setLocationRelativeTo(null);
    }

    private void initializeComponents() {
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(contentPane);

        // Panel de búsqueda
        buscarField = new JTextField(20);
        buscarButton = new JButton("Buscar");
        
        filtroEstadoCombo = new JComboBox<>(new String[]{
            "Todos", "Activos", "Vencidos", "Devueltos"
        });

        // Tabla de préstamos
        String[] columnNames = {
            "ID", "Usuario", "Libro", "Fecha Préstamo", 
            "Fecha Límite", "Estado", "Días Restantes"
        };
        
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        prestamosTable = new JTable(tableModel);
        prestamosTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        prestamosTable.getTableHeader().setReorderingAllowed(false);
        
        // Ajustar ancho de columnas
        prestamosTable.getColumnModel().getColumn(0).setPreferredWidth(50);   // ID
        prestamosTable.getColumnModel().getColumn(1).setPreferredWidth(150);  // Usuario
        prestamosTable.getColumnModel().getColumn(2).setPreferredWidth(200);  // Libro
        prestamosTable.getColumnModel().getColumn(3).setPreferredWidth(120);  // Fecha Préstamo
        prestamosTable.getColumnModel().getColumn(4).setPreferredWidth(120);  // Fecha Límite
        prestamosTable.getColumnModel().getColumn(5).setPreferredWidth(100);  // Estado
        prestamosTable.getColumnModel().getColumn(6).setPreferredWidth(100);  // Días Restantes

        // Botones de acción
        nuevoPrestamoButton = new JButton("Nuevo Préstamo");
        devolverButton = new JButton("Devolver");
        renovarButton = new JButton("Renovar");
        verDetallesButton = new JButton("Ver Detalles");
        actualizarButton = new JButton("Actualizar");
        
        // Estado
        statusLabel = new JLabel("Préstamos cargados");
    }

    private void setupLayout() {
        contentPane.setLayout(new BorderLayout());

        // Panel superior - búsqueda y filtros
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.add(new JLabel("Buscar:"));
        topPanel.add(buscarField);
        topPanel.add(buscarButton);
        topPanel.add(Box.createHorizontalStrut(20));
        topPanel.add(new JLabel("Estado:"));
        topPanel.add(filtroEstadoCombo);
        topPanel.add(actualizarButton);

        // Panel central - tabla
        JScrollPane scrollPane = new JScrollPane(prestamosTable);
        scrollPane.setPreferredSize(new Dimension(900, 400));

        // Panel inferior - botones
        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.Y_AXIS));
        
        JPanel buttonsPanel = new JPanel(new FlowLayout());
        buttonsPanel.add(nuevoPrestamoButton);
        buttonsPanel.add(devolverButton);
        buttonsPanel.add(renovarButton);
        buttonsPanel.add(verDetallesButton);
        
        JPanel statusPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        statusPanel.add(statusLabel);
        
        bottomPanel.add(buttonsPanel);
        bottomPanel.add(statusPanel);

        contentPane.add(topPanel, BorderLayout.NORTH);
        contentPane.add(scrollPane, BorderLayout.CENTER);
        contentPane.add(bottomPanel, BorderLayout.SOUTH);
    }

    private void setupEvents() {
        buscarButton.addActionListener(e -> realizarBusqueda());
        
        buscarField.addActionListener(e -> realizarBusqueda());
        
        filtroEstadoCombo.addActionListener(e -> cargarPrestamos());
        
        actualizarButton.addActionListener(e -> cargarPrestamos());
        
        nuevoPrestamoButton.addActionListener(e -> abrirNuevoPrestamo());
        
        devolverButton.addActionListener(e -> devolverLibro());
        
        renovarButton.addActionListener(e -> renovarPrestamo());
        
        verDetallesButton.addActionListener(e -> verDetallesPrestamo());
        
        prestamosTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                actualizarEstadoBotones();
            }
        });
    }

    private void cargarPrestamos() {
        SwingUtilities.invokeLater(() -> {
            try {
                tableModel.setRowCount(0);
                List<Prestamo> prestamos = prestamoDAO.obtenerPrestamos();
                
                String filtro = (String) filtroEstadoCombo.getSelectedItem();
                LocalDate hoy = LocalDate.now();
                
                // Filtrar según el estado seleccionado
                List<Prestamo> prestamosFiltrados = new ArrayList<>();
                
                for (Prestamo prestamo : prestamos) {
                    switch (filtro) {
                        case "Activos":
                            if ("activo".equals(prestamo.getEstado())) {
                                prestamosFiltrados.add(prestamo);
                            }
                            break;
                        case "Vencidos":
                            if ("activo".equals(prestamo.getEstado()) && 
                                prestamo.getFechaDevolucionProgramada().isBefore(hoy)) {
                                prestamosFiltrados.add(prestamo);
                            }
                            break;
                        default:
                            if ("activo".equals(prestamo.getEstado())) {
                                prestamosFiltrados.add(prestamo);
                            }
                            break;
                    }
                }
                
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                
                for (Prestamo prestamo : prestamosFiltrados) {
                    // Calcular días para vencimiento o retraso
                    long diasDiferencia = ChronoUnit.DAYS.between(hoy, prestamo.getFechaDevolucionProgramada());
                    String estadoDetalle;
                    
                    if (diasDiferencia > 0) {
                        estadoDetalle = diasDiferencia + " días restantes";
                    } else if (diasDiferencia == 0) {
                        estadoDetalle = "Vence hoy";
                    } else {
                        estadoDetalle = "Vencido (" + Math.abs(diasDiferencia) + " días)";
                    }
                    
                    Object[] row = {
                        prestamo.getIdPrestamo(),
                        "Usuario " + prestamo.getIdUsuario(), // Simplificado
                        "Libro " + prestamo.getIdLibro(),     // Simplificado
                        prestamo.getFechaPrestamo().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")),
                        prestamo.getFechaDevolucionProgramada().format(formatter),
                        prestamo.getEstado(),
                        estadoDetalle
                    };
                    tableModel.addRow(row);
                }
                
                statusLabel.setText("Se encontraron " + prestamos.size() + " préstamos");
                
            } catch (Exception e) {
                statusLabel.setText("Error al cargar préstamos: " + e.getMessage());
                JOptionPane.showMessageDialog(this,
                    "Error al cargar los préstamos: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private void realizarBusqueda() {
        String termino = buscarField.getText().trim();
        
        if (termino.isEmpty()) {
            cargarPrestamos();
            return;
        }
        
        SwingUtilities.invokeLater(() -> {
            try {
                tableModel.setRowCount(0);
                List<Prestamo> prestamos = prestamoDAO.obtenerPrestamos();
                
                // Filtrar por término de búsqueda (ID de préstamo o ID de usuario)
                List<Prestamo> prestamosFiltrados = new ArrayList<>();
                for (Prestamo prestamo : prestamos) {
                    String idPrestamo = String.valueOf(prestamo.getIdPrestamo());
                    String idUsuario = String.valueOf(prestamo.getIdUsuario());
                    
                    if (idPrestamo.contains(termino) || idUsuario.contains(termino)) {
                        prestamosFiltrados.add(prestamo);
                    }
                }
                
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                LocalDate hoy = LocalDate.now();
                
                for (Prestamo prestamo : prestamosFiltrados) {
                    // Calcular días para vencimiento o retraso
                    long diasDiferencia = ChronoUnit.DAYS.between(hoy, prestamo.getFechaDevolucionProgramada());
                    String estadoDetalle;
                    
                    if (diasDiferencia > 0) {
                        estadoDetalle = diasDiferencia + " días restantes";
                    } else if (diasDiferencia == 0) {
                        estadoDetalle = "Vence hoy";
                    } else {
                        estadoDetalle = "Vencido (" + Math.abs(diasDiferencia) + " días)";
                    }
                    
                    Object[] row = {
                        prestamo.getIdPrestamo(),
                        "Usuario " + prestamo.getIdUsuario(),
                        prestamo.getTituloLibro(),
                        prestamo.getFechaPrestamo().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")),
                        prestamo.getFechaDevolucionProgramada().format(formatter),
                        prestamo.getEstadoDetallado(),
                        prestamo.getDiasParaVencer() > 0 ? prestamo.getDiasParaVencer() + " días" : 
                            (prestamo.estaVencido() ? "Vencido (" + prestamo.getDiasRetraso() + " días)" : "Hoy")
                    };
                    tableModel.addRow(row);
                }
                
                statusLabel.setText("Se encontraron " + prestamos.size() + " préstamos para: " + termino);
                
            } catch (Exception e) {
                statusLabel.setText("Error en la búsqueda: " + e.getMessage());
                JOptionPane.showMessageDialog(this,
                    "Error al realizar la búsqueda: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private void abrirNuevoPrestamo() {
        try {
            NuevoPrestamoDialog dialog = new NuevoPrestamoDialog(this, usuarioActual, libroDAO, usuarioDAO, prestamoDAO);
            dialog.setVisible(true);
            
            if (dialog.isPrestamoCreado()) {
                cargarPrestamos();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Error al abrir ventana de nuevo préstamo: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void devolverLibro() {
        int selectedRow = prestamosTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this,
                "Por favor seleccione un préstamo para devolver.",
                "Selección Requerida",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int prestamoId = (Integer) tableModel.getValueAt(selectedRow, 0);
        String usuario = (String) tableModel.getValueAt(selectedRow, 1);
        String libro = (String) tableModel.getValueAt(selectedRow, 2);
        
        int confirmacion = JOptionPane.showConfirmDialog(this,
            "¿Está seguro de que desea devolver el libro?\n\n" +
            "Usuario: " + usuario + "\n" +
            "Libro: " + libro,
            "Confirmar Devolución",
            JOptionPane.YES_NO_OPTION);
        
        if (confirmacion == JOptionPane.YES_OPTION) {
            String notas = JOptionPane.showInputDialog(this,
                "Observaciones de la devolución (opcional):",
                "Observaciones",
                JOptionPane.QUESTION_MESSAGE);
            
            if (prestamoDAO.devolverLibro(prestamoId)) {
                JOptionPane.showMessageDialog(this,
                    "Libro devuelto exitosamente.",
                    "Devolución Exitosa",
                    JOptionPane.INFORMATION_MESSAGE);
                cargarPrestamos();
            } else {
                JOptionPane.showMessageDialog(this,
                    "Error al devolver el libro.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void renovarPrestamo() {
        JOptionPane.showMessageDialog(this,
            "Función de renovación en desarrollo.",
            "Información",
            JOptionPane.INFORMATION_MESSAGE);
    }

    private void verDetallesPrestamo() {
        int selectedRow = prestamosTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this,
                "Por favor seleccione un préstamo para ver los detalles.",
                "Selección Requerida",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int prestamoId = (Integer) tableModel.getValueAt(selectedRow, 0);
        
        // Buscar el préstamo en la lista
        List<Prestamo> prestamos = prestamoDAO.obtenerPrestamos();
        Prestamo prestamo = null;
        
        for (Prestamo p : prestamos) {
            if (p.getIdPrestamo() == prestamoId) {
                prestamo = p;
                break;
            }
        }
        
        if (prestamo != null) {
            StringBuilder detalles = new StringBuilder();
            detalles.append("<html><body style='width: 300px'>");
            detalles.append("<h3>Detalles del Préstamo</h3>");
            detalles.append("<b>ID:</b> ").append(prestamo.getIdPrestamo()).append("<br>");
            detalles.append("<b>Usuario ID:</b> ").append(prestamo.getIdUsuario()).append("<br>");
            detalles.append("<b>Libro:</b> ").append(prestamo.getTituloLibro()).append("<br>");
            detalles.append("<b>ISBN:</b> ").append(prestamo.getIsbnLibro()).append("<br>");
            detalles.append("<b>Fecha de Préstamo:</b> ").append(
                prestamo.getFechaPrestamo().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"))).append("<br>");
            detalles.append("<b>Fecha Límite:</b> ").append(
                prestamo.getFechaDevolucionProgramada().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))).append("<br>");
            detalles.append("<b>Estado:</b> ").append(prestamo.getEstadoDetallado()).append("<br>");
            
            if (prestamo.getObservaciones() != null && !prestamo.getObservaciones().trim().isEmpty()) {
                detalles.append("<b>Observaciones:</b> ").append(prestamo.getObservaciones()).append("<br>");
            }
            
            if (prestamo.estaVencido()) {
                detalles.append("<b>Días de retraso:</b> ").append(prestamo.getDiasRetraso()).append("<br>");
            } else if (prestamo.estaActivo()) {
                detalles.append("<b>Días restantes:</b> ").append(prestamo.getDiasParaVencer()).append("<br>");
            }
            
            detalles.append("</body></html>");
            
            JOptionPane.showMessageDialog(this,
                detalles.toString(),
                "Detalles del Préstamo",
                JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void actualizarEstadoBotones() {
        int selectedRow = prestamosTable.getSelectedRow();
        boolean haySeleccion = selectedRow != -1;
        
        devolverButton.setEnabled(haySeleccion);
        renovarButton.setEnabled(haySeleccion);
        verDetallesButton.setEnabled(haySeleccion);
        
        if (haySeleccion) {
            String estado = (String) tableModel.getValueAt(selectedRow, 5);
            boolean esActivo = estado.contains("tiempo") || estado.contains("vencer") || estado.contains("Vencido");
            devolverButton.setEnabled(esActivo);
            renovarButton.setEnabled(esActivo);
        }
    }
}
