package com.biblioteca.views;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.ListSelectionModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.biblioteca.database.PrestamoDAO;
import com.biblioteca.database.UsuarioDAO;
import com.biblioteca.models.Prestamo;
import com.biblioteca.models.Usuario;
import com.biblioteca.services.AlertasService;

/**
 * Ventana para gestión de sanciones y alertas
 */
public class GestionSancionesWindow extends JFrame {
    
    private final Usuario usuarioActual;
    private final UsuarioDAO usuarioDAO;
    private final PrestamoDAO prestamoDAO;
    private final AlertasService alertasService;
    
    private JPanel contentPane;
    private JTabbedPane tabbedPane;
    
    // Panel de préstamos vencidos
    private JTable prestamosVencidosTable;
    private DefaultTableModel prestamosVencidosModel;
    private JButton renovarButton;
    private JButton aplicarSancionButton;
    private JButton contactarUsuarioButton;
    
    // Panel de sanciones activas
    private JTable sancionesTable;
    private DefaultTableModel sancionesModel;
    private JButton levantarSancionButton;
    private JButton modificarSancionButton;
    
    // Panel de configuración
    private JSpinner diasAdvertenciaSpinner;
    private JSpinner diasSuspension1Spinner;
    private JSpinner diasSuspension2Spinner;
    private JSpinner multaPorDiaSpinner;
    private JButton guardarConfigButton;
    
    private JLabel statusLabel;

    public GestionSancionesWindow(Usuario usuarioActual) {
        this.usuarioActual = usuarioActual;
        this.usuarioDAO = new UsuarioDAO();
        this.prestamoDAO = new PrestamoDAO();
        this.alertasService = new AlertasService();
        
        initializeComponents();
        setupLayout();
        setupEvents();
        cargarDatos();
        
        setTitle("Gestión de Sanciones - " + usuarioActual.getNombreCompleto());
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(900, 700);
        setLocationRelativeTo(null);
    }

    private void initializeComponents() {
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(15, 15, 15, 15));
        setContentPane(contentPane);

        tabbedPane = new JTabbedPane();
        
        // Tabla de préstamos vencidos
        String[] prestamosColumns = {
            "ID Préstamo", "Usuario", "Libro", "F. Vencimiento", "Días Atraso", "Multa Calculada", "Estado"
        };
        
        prestamosVencidosModel = new DefaultTableModel(prestamosColumns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        prestamosVencidosTable = new JTable(prestamosVencidosModel);
        prestamosVencidosTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        // Tabla de sanciones activas
        String[] sancionesColumns = {
            "Usuario", "Tipo Sanción", "F. Inicio", "F. Fin", "Motivo", "Estado"
        };
        
        sancionesModel = new DefaultTableModel(sancionesColumns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        sancionesTable = new JTable(sancionesModel);
        sancionesTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        // Botones
        renovarButton = new JButton("Renovar Préstamo");
        aplicarSancionButton = new JButton("Aplicar Sanción");
        contactarUsuarioButton = new JButton("Contactar Usuario");
        levantarSancionButton = new JButton("Levantar Sanción");
        modificarSancionButton = new JButton("Modificar Sanción");
        
        // Configuración
        diasAdvertenciaSpinner = new JSpinner(new SpinnerNumberModel(3, 1, 30, 1));
        diasSuspension1Spinner = new JSpinner(new SpinnerNumberModel(7, 1, 30, 1));
        diasSuspension2Spinner = new JSpinner(new SpinnerNumberModel(15, 1, 60, 1));
        multaPorDiaSpinner = new JSpinner(new SpinnerNumberModel(2.0, 0.5, 10.0, 0.5));
        guardarConfigButton = new JButton("Guardar Configuración");
        
        statusLabel = new JLabel("Gestión de sanciones iniciada");
    }

    private void setupLayout() {
        contentPane.setLayout(new BorderLayout());
        
        // Panel de préstamos vencidos
        JPanel prestamosPanel = new JPanel(new BorderLayout());
        prestamosPanel.add(new JScrollPane(prestamosVencidosTable), BorderLayout.CENTER);
        
        JPanel prestamosButtonPanel = new JPanel(new FlowLayout());
        prestamosButtonPanel.add(renovarButton);
        prestamosButtonPanel.add(aplicarSancionButton);
        prestamosButtonPanel.add(contactarUsuarioButton);
        prestamosPanel.add(prestamosButtonPanel, BorderLayout.SOUTH);
        
        // Panel de sanciones activas
        JPanel sancionesPanel = new JPanel(new BorderLayout());
        sancionesPanel.add(new JScrollPane(sancionesTable), BorderLayout.CENTER);
        
        JPanel sancionesButtonPanel = new JPanel(new FlowLayout());
        sancionesButtonPanel.add(levantarSancionButton);
        sancionesButtonPanel.add(modificarSancionButton);
        sancionesPanel.add(sancionesButtonPanel, BorderLayout.SOUTH);
        
        // Panel de configuración
        JPanel configPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        
        gbc.gridx = 0; gbc.gridy = 0; gbc.anchor = GridBagConstraints.WEST;
        configPanel.add(new JLabel("Días para advertencia:"), gbc);
        gbc.gridx = 1; gbc.gridy = 0;
        configPanel.add(diasAdvertenciaSpinner, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1;
        configPanel.add(new JLabel("Días suspensión nivel 1:"), gbc);
        gbc.gridx = 1; gbc.gridy = 1;
        configPanel.add(diasSuspension1Spinner, gbc);
        
        gbc.gridx = 0; gbc.gridy = 2;
        configPanel.add(new JLabel("Días suspensión nivel 2:"), gbc);
        gbc.gridx = 1; gbc.gridy = 2;
        configPanel.add(diasSuspension2Spinner, gbc);
        
        gbc.gridx = 0; gbc.gridy = 3;
        configPanel.add(new JLabel("Multa por día ($):"), gbc);
        gbc.gridx = 1; gbc.gridy = 3;
        configPanel.add(multaPorDiaSpinner, gbc);
        
        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2; gbc.fill = GridBagConstraints.HORIZONTAL;
        configPanel.add(guardarConfigButton, gbc);
        
        // Información de políticas
        JTextArea politicasArea = new JTextArea(
            "POLÍTICAS DE SANCIONES:\n\n" +
            "• 1-7 días de atraso: Advertencia por email\n" +
            "• 8-14 días de atraso: Suspensión temporal (3-7 días)\n" +
            "• 15-30 días de atraso: Suspensión extendida (7-15 días)\n" +
            "• Más de 30 días: Revisión manual del caso\n" +
            "• Multas se calculan automáticamente por día de atraso\n" +
            "• Usuario puede solicitar prórroga una vez por préstamo\n\n" +
            "Las sanciones se aplican automáticamente pero pueden ser\n" +
            "modificadas manualmente por el administrador."
        );
        politicasArea.setEditable(false);
        politicasArea.setBackground(configPanel.getBackground());
        
        gbc.gridx = 0; gbc.gridy = 5; gbc.gridwidth = 2; gbc.fill = GridBagConstraints.BOTH; gbc.weightx = 1.0; gbc.weighty = 1.0;
        configPanel.add(new JScrollPane(politicasArea), gbc);
        
        // Agregar tabs
        tabbedPane.addTab("Préstamos Vencidos", prestamosPanel);
        tabbedPane.addTab("Sanciones Activas", sancionesPanel);
        tabbedPane.addTab("Configuración", configPanel);
        
        contentPane.add(tabbedPane, BorderLayout.CENTER);
        contentPane.add(statusLabel, BorderLayout.SOUTH);
    }

    private void setupEvents() {
        renovarButton.addActionListener(e -> renovarPrestamo());
        aplicarSancionButton.addActionListener(e -> aplicarSancion());
        contactarUsuarioButton.addActionListener(e -> contactarUsuario());
        levantarSancionButton.addActionListener(e -> levantarSancion());
        modificarSancionButton.addActionListener(e -> modificarSancion());
        guardarConfigButton.addActionListener(e -> guardarConfiguracion());
        
        // Habilitar/deshabilitar botones según selección
        prestamosVencidosTable.getSelectionModel().addListSelectionListener(e -> {
            boolean haySeleccion = prestamosVencidosTable.getSelectedRow() != -1;
            renovarButton.setEnabled(haySeleccion);
            aplicarSancionButton.setEnabled(haySeleccion);
            contactarUsuarioButton.setEnabled(haySeleccion);
        });
        
        sancionesTable.getSelectionModel().addListSelectionListener(e -> {
            boolean haySeleccion = sancionesTable.getSelectedRow() != -1;
            levantarSancionButton.setEnabled(haySeleccion);
            modificarSancionButton.setEnabled(haySeleccion);
        });
    }

    private void cargarDatos() {
        SwingUtilities.invokeLater(() -> {
            try {
                cargarPrestamosVencidos();
                cargarSancionesActivas();
                statusLabel.setText("Datos cargados correctamente");
            } catch (Exception e) {
                statusLabel.setText("Error al cargar datos: " + e.getMessage());
            }
        });
    }

    private void cargarPrestamosVencidos() throws Exception {
        prestamosVencidosModel.setRowCount(0);
        
        // Obtener todos los préstamos y filtrar los vencidos
        List<Prestamo> todosPrestamos = prestamoDAO.obtenerPrestamos();
        LocalDate hoy = LocalDate.now();
        
        for (Prestamo prestamo : todosPrestamos) {
            // Solo procesar préstamos activos que están vencidos
            if ("activo".equals(prestamo.getEstado()) && 
                prestamo.getFechaDevolucionProgramada().isBefore(hoy)) {
            Usuario usuario = usuarioDAO.buscarPorId(prestamo.getIdUsuario());
            
            if (usuario != null) {
                long diasAtraso = ChronoUnit.DAYS.between(
                    prestamo.getFechaDevolucionProgramada(), 
                    LocalDate.now()
                );
                
                double multa = alertasService.calcularMulta((int) diasAtraso);
                
                Object[] row = {
                    prestamo.getIdPrestamo(),
                    usuario.getNombreCompleto(),
                    prestamo.getTituloLibro(),
                    prestamo.getFechaDevolucionProgramada(),
                    diasAtraso + " días",
                    "$" + String.format("%.2f", multa),
                    prestamo.getEstado()
                };
                
                prestamosVencidosModel.addRow(row);
                }
            }
        }
    }

    private void cargarSancionesActivas() {
        sancionesModel.setRowCount(0);
        
        // Por ahora datos simulados - en implementación real consultaría tabla de sanciones
        sancionesModel.addRow(new Object[]{
            "Juan Pérez", "Suspensión 3 días", "2024-01-15", "2024-01-18", "Préstamo vencido 10 días", "Activa"
        });
        
        sancionesModel.addRow(new Object[]{
            "María García", "Advertencia", "2024-01-20", "N/A", "Préstamo vencido 5 días", "Notificada"
        });
    }

    private void renovarPrestamo() {
        int selectedRow = prestamosVencidosTable.getSelectedRow();
        if (selectedRow == -1) return;
        
        int idPrestamo = (Integer) prestamosVencidosModel.getValueAt(selectedRow, 0);
        String usuario = (String) prestamosVencidosModel.getValueAt(selectedRow, 1);
        
        int confirmacion = JOptionPane.showConfirmDialog(this,
            "¿Desea renovar el préstamo para " + usuario + "?\n" +
            "Se extenderá por 7 días adicionales.",
            "Confirmar Renovación",
            JOptionPane.YES_NO_OPTION);
        
        if (confirmacion == JOptionPane.YES_OPTION) {
            try {
                // Aquí se implementaría la lógica de renovación en la base de datos
                JOptionPane.showMessageDialog(this,
                    "Préstamo renovado exitosamente.\n" +
                    "Nueva fecha de vencimiento: " + LocalDate.now().plusDays(7),
                    "Renovación Exitosa",
                    JOptionPane.INFORMATION_MESSAGE);
                
                cargarPrestamosVencidos();
                statusLabel.setText("Préstamo renovado para " + usuario);
                
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this,
                    "Error al renovar préstamo: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void aplicarSancion() {
        int selectedRow = prestamosVencidosTable.getSelectedRow();
        if (selectedRow == -1) return;
        
        String usuario = (String) prestamosVencidosModel.getValueAt(selectedRow, 1);
        String diasAtrasoStr = (String) prestamosVencidosModel.getValueAt(selectedRow, 4);
        int diasAtraso = Integer.parseInt(diasAtrasoStr.split(" ")[0]);
        
        String tipoSancion;
        if (diasAtraso <= 7) {
            tipoSancion = "Advertencia por email";
        } else if (diasAtraso <= 14) {
            tipoSancion = "Suspensión 3 días";
        } else if (diasAtraso <= 30) {
            tipoSancion = "Suspensión 7 días";
        } else {
            tipoSancion = "Suspensión 15 días";
        }
        
        int confirmacion = JOptionPane.showConfirmDialog(this,
            "¿Aplicar sanción a " + usuario + "?\n\n" +
            "Tipo de sanción: " + tipoSancion + "\n" +
            "Días de atraso: " + diasAtraso,
            "Confirmar Sanción",
            JOptionPane.YES_NO_OPTION);
        
        if (confirmacion == JOptionPane.YES_OPTION) {
            // Aquí se implementaría la lógica de aplicar sanción en la base de datos
            JOptionPane.showMessageDialog(this,
                "Sanción aplicada exitosamente.\n" +
                "Se ha notificado al usuario por email.",
                "Sanción Aplicada",
                JOptionPane.INFORMATION_MESSAGE);
            
            cargarSancionesActivas();
            statusLabel.setText("Sanción aplicada a " + usuario);
        }
    }

    private void contactarUsuario() {
        int selectedRow = prestamosVencidosTable.getSelectedRow();
        if (selectedRow == -1) return;
        
        String usuario = (String) prestamosVencidosModel.getValueAt(selectedRow, 1);
        
        JTextArea mensajeArea = new JTextArea(5, 40);
        mensajeArea.setText(
            "Estimado/a " + usuario + ",\n\n" +
            "Le recordamos que tiene un préstamo vencido en nuestra biblioteca.\n" +
            "Por favor, devuelva el libro lo antes posible para evitar sanciones adicionales.\n\n" +
            "Atentamente,\n" +
            "Sistema de Biblioteca"
        );
        mensajeArea.setLineWrap(true);
        mensajeArea.setWrapStyleWord(true);
        
        JScrollPane scrollPane = new JScrollPane(mensajeArea);
        
        int resultado = JOptionPane.showConfirmDialog(this,
            scrollPane,
            "Enviar Mensaje a " + usuario,
            JOptionPane.OK_CANCEL_OPTION);
        
        if (resultado == JOptionPane.OK_OPTION) {
            // Aquí se implementaría el envío real de email/SMS
            JOptionPane.showMessageDialog(this,
                "Mensaje enviado exitosamente a " + usuario,
                "Mensaje Enviado",
                JOptionPane.INFORMATION_MESSAGE);
            
            statusLabel.setText("Mensaje enviado a " + usuario);
        }
    }

    private void levantarSancion() {
        int selectedRow = sancionesTable.getSelectedRow();
        if (selectedRow == -1) return;
        
        String usuario = (String) sancionesModel.getValueAt(selectedRow, 0);
        String tipoSancion = (String) sancionesModel.getValueAt(selectedRow, 1);
        
        int confirmacion = JOptionPane.showConfirmDialog(this,
            "¿Levantar la sanción para " + usuario + "?\n\n" +
            "Tipo de sanción: " + tipoSancion,
            "Confirmar Levantamiento",
            JOptionPane.YES_NO_OPTION);
        
        if (confirmacion == JOptionPane.YES_OPTION) {
            // Aquí se implementaría la lógica de levantar sanción
            JOptionPane.showMessageDialog(this,
                "Sanción levantada exitosamente para " + usuario,
                "Sanción Levantada",
                JOptionPane.INFORMATION_MESSAGE);
            
            cargarSancionesActivas();
            statusLabel.setText("Sanción levantada para " + usuario);
        }
    }

    private void modificarSancion() {
        int selectedRow = sancionesTable.getSelectedRow();
        if (selectedRow == -1) return;
        
        String usuario = (String) sancionesModel.getValueAt(selectedRow, 0);
        
        // Diálogo para modificar sanción
        JComboBox<String> tipoSancionCombo = new JComboBox<>(new String[]{
            "Advertencia", "Suspensión 3 días", "Suspensión 7 días", "Suspensión 15 días"
        });
        
        JTextArea motivoArea = new JTextArea(3, 20);
        motivoArea.setText("Modificación manual por administrador");
        
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("Nuevo tipo de sanción:"), gbc);
        gbc.gridx = 1; gbc.gridy = 0;
        panel.add(tipoSancionCombo, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(new JLabel("Motivo:"), gbc);
        gbc.gridx = 1; gbc.gridy = 1;
        panel.add(new JScrollPane(motivoArea), gbc);
        
        int resultado = JOptionPane.showConfirmDialog(this,
            panel,
            "Modificar Sanción - " + usuario,
            JOptionPane.OK_CANCEL_OPTION);
        
        if (resultado == JOptionPane.OK_OPTION) {
            JOptionPane.showMessageDialog(this,
                "Sanción modificada exitosamente para " + usuario,
                "Sanción Modificada",
                JOptionPane.INFORMATION_MESSAGE);
            
            cargarSancionesActivas();
            statusLabel.setText("Sanción modificada para " + usuario);
        }
    }

    private void guardarConfiguracion() {
        // Aquí se guardarían las configuraciones en la base de datos o archivo de configuración
        JOptionPane.showMessageDialog(this,
            "Configuración guardada exitosamente.\n" +
            "Los nuevos parámetros se aplicarán a partir del próximo procesamiento.",
            "Configuración Guardada",
            JOptionPane.INFORMATION_MESSAGE);
        
        statusLabel.setText("Configuración de sanciones actualizada");
    }
}
