package com.biblioteca.views;

import com.biblioteca.database.UsuarioDAO;
import com.biblioteca.models.Usuario;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

/**
 * Ventana para gestión de usuarios
 */
public class GestionUsuariosWindow extends JFrame {
    
    private final Usuario usuarioActual;
    private final UsuarioDAO usuarioDAO;
    
    private JTable usuariosTable;
    private DefaultTableModel tableModel;
    private JTextField busquedaField;
    private JButton agregarButton;
    private JButton editarButton;
    private JButton eliminarButton;
    private JButton refrescarButton;

    public GestionUsuariosWindow(Usuario usuarioActual) {
        this.usuarioActual = usuarioActual;
        this.usuarioDAO = new UsuarioDAO();
        
        initializeComponents();
        setupLayout();
        setupEvents();
        loadUsuarios();
        
        setTitle("Gestión de Usuarios");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(900, 600);
        setLocationRelativeTo(null);
    }

    private void initializeComponents() {
        // Campo de búsqueda
        busquedaField = new JTextField(30);
        
        // Botones
        agregarButton = new JButton("Agregar Usuario");
        editarButton = new JButton("Editar Usuario");
        eliminarButton = new JButton("Eliminar Usuario");
        refrescarButton = new JButton("Refrescar");
        
        // Configurar estilos de botones
        agregarButton.setBackground(new Color(34, 139, 34));
        agregarButton.setForeground(Color.WHITE);
        
        editarButton.setBackground(new Color(255, 165, 0));
        editarButton.setForeground(Color.WHITE);
        
        eliminarButton.setBackground(new Color(220, 20, 60));
        eliminarButton.setForeground(Color.WHITE);
        
        refrescarButton.setBackground(new Color(70, 130, 180));
        refrescarButton.setForeground(Color.WHITE);
        
        // Tabla de usuarios
        String[] columnas = {"ID", "Nombre", "Apellido", "Email", "Username", "Rol", "Tipo", "Activo"};
        tableModel = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        usuariosTable = new JTable(tableModel);
        usuariosTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        usuariosTable.setRowHeight(25);
        
        // Habilitar/deshabilitar botones según permisos
        if (!esAdministradorOBibliotecario()) {
            agregarButton.setEnabled(false);
            editarButton.setEnabled(false);
            eliminarButton.setEnabled(false);
        }
    }

    private void setupLayout() {
        setLayout(new BorderLayout());
        
        // Panel superior con búsqueda
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.setBorder(new EmptyBorder(10, 10, 5, 10));
        
        topPanel.add(new JLabel("Buscar:"));
        topPanel.add(busquedaField);
        topPanel.add(refrescarButton);
        
        add(topPanel, BorderLayout.NORTH);
        
        // Panel central con tabla
        JScrollPane scrollPane = new JScrollPane(usuariosTable);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Lista de Usuarios"));
        add(scrollPane, BorderLayout.CENTER);
        
        // Panel inferior con botones
        JPanel bottomPanel = new JPanel(new FlowLayout());
        bottomPanel.setBorder(new EmptyBorder(5, 10, 10, 10));
        
        bottomPanel.add(agregarButton);
        bottomPanel.add(editarButton);
        bottomPanel.add(eliminarButton);
        
        add(bottomPanel, BorderLayout.SOUTH);
    }

    private void setupEvents() {
        // Búsqueda en tiempo real
        busquedaField.addActionListener(e -> buscarUsuarios());
        
        // Eventos de botones
        agregarButton.addActionListener(e -> agregarUsuario());
        editarButton.addActionListener(e -> editarUsuario());
        eliminarButton.addActionListener(e -> eliminarUsuario());
        refrescarButton.addActionListener(e -> loadUsuarios());
        
        // Doble clic para editar
        usuariosTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && esAdministradorOBibliotecario()) {
                    editarUsuario();
                }
            }
        });
        
        // Selección de tabla para habilitar botones
        usuariosTable.getSelectionModel().addListSelectionListener(e -> {
            boolean selected = usuariosTable.getSelectedRow() != -1;
            editarButton.setEnabled(selected && esAdministradorOBibliotecario());
            eliminarButton.setEnabled(selected && esAdministradorOBibliotecario());
        });
    }

    private void loadUsuarios() {
        SwingWorker<List<Usuario>, Void> worker = new SwingWorker<List<Usuario>, Void>() {
            @Override
            protected List<Usuario> doInBackground() throws Exception {
                return usuarioDAO.buscarTodos();
            }
            
            @Override
            protected void done() {
                try {
                    List<Usuario> usuarios = get();
                    actualizarTabla(usuarios);
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(GestionUsuariosWindow.this,
                        "Error al cargar usuarios: " + e.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                }
            }
        };
        
        worker.execute();
    }

    private void buscarUsuarios() {
        String termino = busquedaField.getText().trim();
        
        if (termino.isEmpty()) {
            loadUsuarios();
            return;
        }
        
        SwingWorker<List<Usuario>, Void> worker = new SwingWorker<List<Usuario>, Void>() {
            @Override
            protected List<Usuario> doInBackground() throws Exception {
                return usuarioDAO.buscarPorTermino(termino);
            }
            
            @Override
            protected void done() {
                try {
                    List<Usuario> usuarios = get();
                    actualizarTabla(usuarios);
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(GestionUsuariosWindow.this,
                        "Error al buscar usuarios: " + e.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                }
            }
        };
        
        worker.execute();
    }

    private void actualizarTabla(List<Usuario> usuarios) {
        tableModel.setRowCount(0);
        
        for (Usuario usuario : usuarios) {
            Object[] fila = {
                usuario.getIdUsuario(),
                usuario.getNombre(),
                usuario.getApellido(),
                usuario.getEmail(),
                usuario.getUsername(),
                usuario.getNombreRol(),
                usuario.getTipoUsuario(),
                usuario.isActivo() ? "Sí" : "No"
            };
            tableModel.addRow(fila);
        }
    }

    private void agregarUsuario() {
        RegistroUsuarioWindow registroWindow = new RegistroUsuarioWindow(this);
        registroWindow.setVisible(true);
        
        // Refrescar después de cerrar
        registroWindow.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosed(java.awt.event.WindowEvent e) {
                loadUsuarios();
            }
        });
    }

    private void editarUsuario() {
        int selectedRow = usuariosTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this,
                "Seleccione un usuario para editar",
                "Información",
                JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        
        int idUsuario = (Integer) tableModel.getValueAt(selectedRow, 0);
        
        // Aquí se abriría una ventana de edición de usuario
        JOptionPane.showMessageDialog(this,
            "Función de edición en desarrollo.\nID Usuario: " + idUsuario,
            "Información",
            JOptionPane.INFORMATION_MESSAGE);
    }

    private void eliminarUsuario() {
        int selectedRow = usuariosTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this,
                "Seleccione un usuario para eliminar",
                "Información",
                JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        
        int idUsuario = (Integer) tableModel.getValueAt(selectedRow, 0);
        String nombreUsuario = tableModel.getValueAt(selectedRow, 1) + " " + 
                              tableModel.getValueAt(selectedRow, 2);
        
        int option = JOptionPane.showConfirmDialog(this,
            "¿Está seguro de que desea eliminar al usuario:\n" + nombreUsuario + "?",
            "Confirmar Eliminación",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);
        
        if (option == JOptionPane.YES_OPTION) {
            SwingWorker<Boolean, Void> worker = new SwingWorker<Boolean, Void>() {
                @Override
                protected Boolean doInBackground() throws Exception {
                    return usuarioDAO.eliminarUsuario(idUsuario);
                }
                
                @Override
                protected void done() {
                    try {
                        boolean success = get();
                        if (success) {
                            JOptionPane.showMessageDialog(GestionUsuariosWindow.this,
                                "Usuario eliminado exitosamente",
                                "Éxito",
                                JOptionPane.INFORMATION_MESSAGE);
                            loadUsuarios();
                        } else {
                            JOptionPane.showMessageDialog(GestionUsuariosWindow.this,
                                "Error al eliminar usuario",
                                "Error",
                                JOptionPane.ERROR_MESSAGE);
                        }
                    } catch (Exception e) {
                        JOptionPane.showMessageDialog(GestionUsuariosWindow.this,
                            "Error: " + e.getMessage(),
                            "Error",
                            JOptionPane.ERROR_MESSAGE);
                    }
                }
            };
            
            worker.execute();
        }
    }

    private boolean esAdministradorOBibliotecario() {
        return usuarioActual.getIdRol() == 1 || usuarioActual.getIdRol() == 2;
    }
}
