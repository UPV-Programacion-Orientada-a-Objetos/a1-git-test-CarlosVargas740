package com.biblioteca.views;

import com.biblioteca.database.LibroDAO;
import com.biblioteca.models.Libro;
import com.biblioteca.models.Usuario;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Formulario para crear y editar libros
 */
public class LibroFormWindow extends JDialog {
    
    private final Libro libro;
    private final LibroDAO libroDAO;
    private final boolean isEditing;
    
    private JPanel contentPane;
    private JTextField tituloField;
    private JTextField isbnField;
    private JTextField codigoBarrasField;
    private JTextField autorField;
    private JComboBox<String> categoriaCombo;
    private JTextField editorialField;
    private JSpinner anoSpinner;
    private JSpinner paginasSpinner;
    private JTextField idiomaField;
    private JTextArea descripcionArea;
    private JTextField ubicacionField;
    private JSpinner cantidadTotalSpinner;
    private JSpinner cantidadDisponibleSpinner;
    private JTextField precioVentaField;
    private JCheckBox disponibleVentaCheck;
    private JButton guardarButton;
    private JButton cancelarButton;

    public LibroFormWindow(JFrame parent, Libro libro, Usuario usuario) {
        super(parent, true);
        this.libro = libro;
        this.libroDAO = new LibroDAO();
        this.isEditing = (libro != null);
        
        initializeComponents();
        setupLayout();
        setupEvents();
        
        if (isEditing && libro != null && libro.getTitulo() != null) {
            loadLibroData();
            setTitle("Editar Libro - " + libro.getTitulo());
        } else {
            setTitle("Nuevo Libro");
        }
        
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        setSize(600, 700);
        setLocationRelativeTo(parent);
    }

    private void initializeComponents() {
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(20, 20, 20, 20));
        contentPane.setLayout(new BorderLayout());
        setContentPane(contentPane);
        
        // Inicializar campos
        tituloField = new JTextField(30);
        isbnField = new JTextField(20);
        codigoBarrasField = new JTextField(20);
        autorField = new JTextField(30);
        
        // ComboBox de categorías
        String[] categorias = {
            "Seleccionar categoría...",
            "Ficción", "Ciencia", "Historia", "Tecnología", "Educación",
            "Arte", "Medicina", "Derecho", "Economía", "Literatura"
        };
        categoriaCombo = new JComboBox<>(categorias);
        
        editorialField = new JTextField(25);
        
        // Spinners
        anoSpinner = new JSpinner(new SpinnerNumberModel(2024, 1900, 2030, 1));
        paginasSpinner = new JSpinner(new SpinnerNumberModel(100, 1, 9999, 1));
        cantidadTotalSpinner = new JSpinner(new SpinnerNumberModel(1, 1, 999, 1));
        cantidadDisponibleSpinner = new JSpinner(new SpinnerNumberModel(1, 0, 999, 1));
        
        idiomaField = new JTextField("Español", 15);
        descripcionArea = new JTextArea(4, 30);
        descripcionArea.setLineWrap(true);
        descripcionArea.setWrapStyleWord(true);
        
        ubicacionField = new JTextField(20);
        precioVentaField = new JTextField("0.00", 10);
        disponibleVentaCheck = new JCheckBox("Disponible para venta");
        
        guardarButton = new JButton(isEditing ? "Actualizar" : "Guardar");
        cancelarButton = new JButton("Cancelar");
        
        // Configurar estilos
        guardarButton.setBackground(new Color(34, 139, 34));
        guardarButton.setForeground(Color.WHITE);
        guardarButton.setFocusPainted(false);
        
        cancelarButton.setBackground(new Color(220, 20, 60));
        cancelarButton.setForeground(Color.WHITE);
        cancelarButton.setFocusPainted(false);
    }

    private void setupLayout() {
        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        
        int row = 0;
        
        // Título
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(new JLabel("*Título:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        formPanel.add(tituloField, gbc);
        row++;
        
        // ISBN
        gbc.gridx = 0; gbc.gridy = row; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("*ISBN:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        formPanel.add(isbnField, gbc);
        row++;
        
        // Código de barras
        gbc.gridx = 0; gbc.gridy = row; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Código de Barras:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        formPanel.add(codigoBarrasField, gbc);
        row++;
        
        // Autor
        gbc.gridx = 0; gbc.gridy = row; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("*Autor:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        formPanel.add(autorField, gbc);
        row++;
        
        // Categoría
        gbc.gridx = 0; gbc.gridy = row; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("*Categoría:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        formPanel.add(categoriaCombo, gbc);
        row++;
        
        // Editorial
        gbc.gridx = 0; gbc.gridy = row; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Editorial:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        formPanel.add(editorialField, gbc);
        row++;
        
        // Año de publicación
        gbc.gridx = 0; gbc.gridy = row; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Año:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        formPanel.add(anoSpinner, gbc);
        row++;
        
        // Número de páginas
        gbc.gridx = 0; gbc.gridy = row; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Páginas:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        formPanel.add(paginasSpinner, gbc);
        row++;
        
        // Idioma
        gbc.gridx = 0; gbc.gridy = row; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Idioma:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        formPanel.add(idiomaField, gbc);
        row++;
        
        // Descripción
        gbc.gridx = 0; gbc.gridy = row; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        formPanel.add(new JLabel("Descripción:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.BOTH; gbc.weightx = 1.0; gbc.weighty = 1.0;
        formPanel.add(new JScrollPane(descripcionArea), gbc);
        row++;
        
        // Ubicación
        gbc.gridx = 0; gbc.gridy = row; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0; gbc.weighty = 0;
        gbc.anchor = GridBagConstraints.WEST;
        formPanel.add(new JLabel("Ubicación:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        formPanel.add(ubicacionField, gbc);
        row++;
        
        // Cantidad total
        gbc.gridx = 0; gbc.gridy = row; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("*Cantidad Total:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        formPanel.add(cantidadTotalSpinner, gbc);
        row++;
        
        // Cantidad disponible
        gbc.gridx = 0; gbc.gridy = row; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("*Cantidad Disponible:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        formPanel.add(cantidadDisponibleSpinner, gbc);
        row++;
        
        // Precio de venta
        gbc.gridx = 0; gbc.gridy = row; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Precio de Venta:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        formPanel.add(precioVentaField, gbc);
        row++;
        
        // Disponible para venta
        gbc.gridx = 1; gbc.gridy = row;
        formPanel.add(disponibleVentaCheck, gbc);
        
        contentPane.add(formPanel, BorderLayout.CENTER);
        
        // Panel de botones
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.add(guardarButton);
        buttonPanel.add(cancelarButton);
        contentPane.add(buttonPanel, BorderLayout.SOUTH);
        
        // Nota de campos obligatorios
        JLabel noteLabel = new JLabel("* Campos obligatorios");
        noteLabel.setFont(noteLabel.getFont().deriveFont(Font.ITALIC));
        noteLabel.setForeground(Color.GRAY);
        JPanel notePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        notePanel.add(noteLabel);
        contentPane.add(notePanel, BorderLayout.NORTH);
    }

    private void setupEvents() {
        guardarButton.addActionListener(e -> guardarLibro());
        cancelarButton.addActionListener(e -> dispose());
        
        // Validación en tiempo real
        tituloField.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent e) {
                validateForm();
            }
        });
        
        isbnField.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent e) {
                validateForm();
            }
        });
        
        // Sincronizar cantidad total con disponible
        cantidadTotalSpinner.addChangeListener(e -> {
            int total = (Integer) cantidadTotalSpinner.getValue();
            int disponible = (Integer) cantidadDisponibleSpinner.getValue();
            if (disponible > total) {
                cantidadDisponibleSpinner.setValue(total);
            }
        });
    }

    private void loadLibroData() {
        if (libro != null) {
            tituloField.setText(libro.getTitulo());
            isbnField.setText(libro.getIsbn());
            codigoBarrasField.setText(libro.getCodigoBarras());
            autorField.setText(libro.getAutoresString());
            
            if (libro.getNombreCategoria() != null) {
                categoriaCombo.setSelectedItem(libro.getNombreCategoria());
            }
            
            editorialField.setText(libro.getNombreEditorial());
            anoSpinner.setValue(libro.getAnoPublicacion());
            paginasSpinner.setValue(libro.getNumeroPaginas());
            idiomaField.setText(libro.getIdioma());
            descripcionArea.setText(libro.getDescripcion());
            ubicacionField.setText(libro.getUbicacion());
            cantidadTotalSpinner.setValue(libro.getCantidadTotal());
            cantidadDisponibleSpinner.setValue(libro.getCantidadDisponible());
            
            if (libro.getPrecioVenta() != null) {
                precioVentaField.setText(libro.getPrecioVenta().toString());
            }
            
            disponibleVentaCheck.setSelected(libro.isDisponibleVenta());
        }
    }

    private void validateForm() {
        boolean valid = !tituloField.getText().trim().isEmpty() && 
                       !isbnField.getText().trim().isEmpty() &&
                       !autorField.getText().trim().isEmpty() &&
                       categoriaCombo.getSelectedIndex() > 0;
        
        guardarButton.setEnabled(valid);
    }

    private void guardarLibro() {
        if (!validateFields()) {
            return;
        }
        
        // Crear o actualizar libro
        Libro libroToSave = isEditing ? libro : new Libro();
        
        libroToSave.setTitulo(tituloField.getText().trim());
        libroToSave.setIsbn(isbnField.getText().trim());
        libroToSave.setCodigoBarras(codigoBarrasField.getText().trim());
        
        // Para simplicidad, aquí se podría agregar lógica más compleja para autores
        // Por ahora, asumimos un autor por libro
        
        libroToSave.setIdCategoria(categoriaCombo.getSelectedIndex()); // Simplificado
        libroToSave.setIdEditorial(1); // Simplificado
        libroToSave.setAnoPublicacion((Integer) anoSpinner.getValue());
        libroToSave.setNumeroPaginas((Integer) paginasSpinner.getValue());
        libroToSave.setIdioma(idiomaField.getText().trim());
        libroToSave.setDescripcion(descripcionArea.getText().trim());
        libroToSave.setUbicacion(ubicacionField.getText().trim());
        libroToSave.setCantidadTotal((Integer) cantidadTotalSpinner.getValue());
        libroToSave.setCantidadDisponible((Integer) cantidadDisponibleSpinner.getValue());
        
        try {
            BigDecimal precio = new BigDecimal(precioVentaField.getText().trim());
            libroToSave.setPrecioVenta(precio);
        } catch (NumberFormatException e) {
            libroToSave.setPrecioVenta(BigDecimal.ZERO);
        }
        
        libroToSave.setDisponibleVenta(disponibleVentaCheck.isSelected());
        
        if (!isEditing) {
            libroToSave.setFechaIngreso(LocalDateTime.now());
            libroToSave.setActivo(true);
        }
        
        // Guardar en base de datos
        SwingWorker<Boolean, Void> worker = new SwingWorker<Boolean, Void>() {
            @Override
            protected Boolean doInBackground() throws Exception {
                if (isEditing) {
                    return libroDAO.actualizarLibro(libroToSave);
                } else {
                    return libroDAO.crearLibro(libroToSave);
                }
            }
            
            @Override
            protected void done() {
                try {
                    boolean success = get();
                    if (success) {
                        JOptionPane.showMessageDialog(LibroFormWindow.this,
                            isEditing ? "Libro actualizado exitosamente" : "Libro creado exitosamente",
                            "Éxito",
                            JOptionPane.INFORMATION_MESSAGE);
                        dispose();
                    } else {
                        JOptionPane.showMessageDialog(LibroFormWindow.this,
                            "Error al " + (isEditing ? "actualizar" : "crear") + " el libro",
                            "Error",
                            JOptionPane.ERROR_MESSAGE);
                    }
                } catch (InterruptedException | java.util.concurrent.ExecutionException e) {
                    JOptionPane.showMessageDialog(LibroFormWindow.this,
                        "Error: " + e.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                }
            }
        };
        
        worker.execute();
    }

    private boolean validateFields() {
        if (tituloField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "El título es obligatorio", "Validación", JOptionPane.WARNING_MESSAGE);
            tituloField.requestFocus();
            return false;
        }
        
        if (isbnField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "El ISBN es obligatorio", "Validación", JOptionPane.WARNING_MESSAGE);
            isbnField.requestFocus();
            return false;
        }
        
        if (autorField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "El autor es obligatorio", "Validación", JOptionPane.WARNING_MESSAGE);
            autorField.requestFocus();
            return false;
        }
        
        if (categoriaCombo.getSelectedIndex() == 0) {
            JOptionPane.showMessageDialog(this, "Debe seleccionar una categoría", "Validación", JOptionPane.WARNING_MESSAGE);
            categoriaCombo.requestFocus();
            return false;
        }
        
        return true;
    }
}
