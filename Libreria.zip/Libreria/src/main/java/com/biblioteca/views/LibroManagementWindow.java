package com.biblioteca.views;

import com.biblioteca.database.LibroDAO;
import com.biblioteca.models.Libro;
import com.biblioteca.models.Usuario;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * Ventana para gestión completa de libros
 */
public class LibroManagementWindow extends JFrame {
    
    private Usuario usuarioActual;
    private LibroDAO libroDAO;
    
    private JPanel contentPane;
    private JTable librosTable;
    private DefaultTableModel tableModel;
    private JTextField busquedaField;
    private JComboBox<String> filtroCombo;
    private JButton buscarButton;
    private JButton nuevoButton;
    private JButton editarButton;
    private JButton eliminarButton;
    private JButton actualizarButton;
    
    private static final String[] COLUMNAS = {
        "ID", "Título", "ISBN", "Autores", "Categoría", 
        "Editorial", "Año", "Disponible", "Total", "Estado"
    };

    public LibroManagementWindow(Usuario usuario) {
        this.usuarioActual = usuario;
        this.libroDAO = new LibroDAO();
        
        initializeComponents();
        setupLayout();
        setupEvents();
        cargarLibros();
        
        setTitle("Gestión de Libros - Sistema de Biblioteca");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1200, 700);
        setLocationRelativeTo(null);
    }

    private void initializeComponents() {
        contentPane = new JPanel(new BorderLayout());
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(contentPane);
        
        // Inicializar componentes
        busquedaField = new JTextField(20);
        filtroCombo = new JComboBox<>(new String[]{
            "Todos", "Título", "Autor", "ISBN", "Categoría", "Editorial"
        });
        
        buscarButton = new JButton("🔍 Buscar");
        nuevoButton = new JButton("➕ Nuevo Libro");
        editarButton = new JButton("✏️ Editar");
        eliminarButton = new JButton("🗑️ Eliminar");
        actualizarButton = new JButton("🔄 Actualizar");
        
        // Configurar tabla
        tableModel = new DefaultTableModel(COLUMNAS, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Solo lectura
            }
        };
        
        librosTable = new JTable(tableModel);
        librosTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        librosTable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        
        // Configurar anchos de columnas
        librosTable.getColumnModel().getColumn(0).setPreferredWidth(50);   // ID
        librosTable.getColumnModel().getColumn(1).setPreferredWidth(200);  // Título
        librosTable.getColumnModel().getColumn(2).setPreferredWidth(100);  // ISBN
        librosTable.getColumnModel().getColumn(3).setPreferredWidth(150);  // Autores
        librosTable.getColumnModel().getColumn(4).setPreferredWidth(100);  // Categoría
        librosTable.getColumnModel().getColumn(5).setPreferredWidth(120);  // Editorial
        librosTable.getColumnModel().getColumn(6).setPreferredWidth(60);   // Año
        librosTable.getColumnModel().getColumn(7).setPreferredWidth(80);   // Disponible
        librosTable.getColumnModel().getColumn(8).setPreferredWidth(60);   // Total
        librosTable.getColumnModel().getColumn(9).setPreferredWidth(100);  // Estado
    }

    private void setupLayout() {
        // Panel superior - Búsqueda y filtros
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.setBorder(BorderFactory.createTitledBorder("Búsqueda y Filtros"));
        
        topPanel.add(new JLabel("Buscar:"));
        topPanel.add(busquedaField);
        topPanel.add(new JLabel("En:"));
        topPanel.add(filtroCombo);
        topPanel.add(buscarButton);
        
        contentPane.add(topPanel, BorderLayout.NORTH);
        
        // Panel central - Tabla
        JScrollPane scrollPane = new JScrollPane(librosTable);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Lista de Libros"));
        contentPane.add(scrollPane, BorderLayout.CENTER);
        
        // Panel inferior - Botones de acción
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottomPanel.setBorder(BorderFactory.createTitledBorder("Acciones"));
        
        if (usuarioActual.puedeGestionarLibros()) {
            bottomPanel.add(nuevoButton);
            bottomPanel.add(editarButton);
            bottomPanel.add(eliminarButton);
        }
        bottomPanel.add(actualizarButton);
        
        contentPane.add(bottomPanel, BorderLayout.SOUTH);
        
        // Panel lateral - Información detallada
        JPanel sidePanel = createInfoPanel();
        contentPane.add(sidePanel, BorderLayout.EAST);
    }

    private JPanel createInfoPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createTitledBorder("Información del Libro"));
        panel.setPreferredSize(new Dimension(250, 0));
        
        // Aquí se puede agregar información detallada del libro seleccionado
        JLabel infoLabel = new JLabel("<html><center>Seleccione un libro<br>para ver detalles</center></html>");
        infoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(Box.createVerticalGlue());
        panel.add(infoLabel);
        panel.add(Box.createVerticalGlue());
        
        return panel;
    }

    private void setupEvents() {
        // Evento de búsqueda
        buscarButton.addActionListener(e -> buscarLibros());
        
        // Buscar al presionar Enter
        busquedaField.addActionListener(e -> buscarLibros());
        
        // Eventos de botones
        if (usuarioActual.puedeGestionarLibros()) {
            nuevoButton.addActionListener(e -> abrirFormularioNuevoLibro());
            editarButton.addActionListener(e -> editarLibroSeleccionado());
            eliminarButton.addActionListener(e -> eliminarLibroSeleccionado());
        }
        
        actualizarButton.addActionListener(e -> cargarLibros());
        
        // Evento de selección en tabla
        librosTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                actualizarInfoLibro();
            }
        });
    }

    private void cargarLibros() {
        SwingWorker<List<Libro>, Void> worker = new SwingWorker<List<Libro>, Void>() {
            @Override
            protected List<Libro> doInBackground() throws Exception {
                return libroDAO.obtenerTodos();
            }
            
            @Override
            protected void done() {
                try {
                    List<Libro> libros = get();
                    actualizarTabla(libros);
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(LibroManagementWindow.this,
                        "Error al cargar libros: " + e.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                }
            }
        };
        
        worker.execute();
    }

    private void buscarLibros() {
        String criterio = busquedaField.getText().trim();
        String filtro = (String) filtroCombo.getSelectedItem();
        
        SwingWorker<List<Libro>, Void> worker = new SwingWorker<List<Libro>, Void>() {
            @Override
            protected List<Libro> doInBackground() throws Exception {
                if (criterio.isEmpty()) {
                    return libroDAO.obtenerTodos();
                } else {
                    // Implementar búsqueda específica según el filtro
                    return libroDAO.buscarLibros(criterio, null, null, null, null);
                }
            }
            
            @Override
            protected void done() {
                try {
                    List<Libro> libros = get();
                    actualizarTabla(libros);
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(LibroManagementWindow.this,
                        "Error en la búsqueda: " + e.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                }
            }
        };
        
        worker.execute();
    }

    private void actualizarTabla(List<Libro> libros) {
        tableModel.setRowCount(0); // Limpiar tabla
        
        for (Libro libro : libros) {
            Object[] fila = {
                libro.getIdLibro(),
                libro.getTitulo(),
                libro.getIsbn(),
                libro.getAutoresString(),
                libro.getNombreCategoria(),
                libro.getNombreEditorial(),
                libro.getAnoPublicacion(),
                libro.getCantidadDisponible(),
                libro.getCantidadTotal(),
                libro.getEstadoDisponibilidad()
            };
            tableModel.addRow(fila);
        }
        
        // Actualizar título con cantidad
        setTitle("Gestión de Libros - " + libros.size() + " libros encontrados");
    }

    private void abrirFormularioNuevoLibro() {
        LibroFormWindow formulario = new LibroFormWindow(this, null, usuarioActual);
        formulario.setVisible(true);
        
        // Actualizar tabla después de cerrar formulario
        formulario.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosed(java.awt.event.WindowEvent windowEvent) {
                cargarLibros();
            }
        });
    }

    private void editarLibroSeleccionado() {
        int selectedRow = librosTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this,
                "Por favor, seleccione un libro para editar.",
                "Selección Requerida",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int idLibro = (Integer) tableModel.getValueAt(selectedRow, 0);
        
        SwingWorker<Libro, Void> worker = new SwingWorker<Libro, Void>() {
            @Override
            protected Libro doInBackground() throws Exception {
                return libroDAO.buscarPorId(idLibro);
            }
            
            @Override
            protected void done() {
                try {
                    Libro libro = get();
                    if (libro != null) {
                        LibroFormWindow formulario = new LibroFormWindow(LibroManagementWindow.this, libro, usuarioActual);
                        formulario.setVisible(true);
                        
                        formulario.addWindowListener(new java.awt.event.WindowAdapter() {
                            @Override
                            public void windowClosed(java.awt.event.WindowEvent windowEvent) {
                                cargarLibros();
                            }
                        });
                    }
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(LibroManagementWindow.this,
                        "Error al cargar el libro: " + e.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                }
            }
        };
        
        worker.execute();
    }

    private void eliminarLibroSeleccionado() {
        int selectedRow = librosTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this,
                "Por favor, seleccione un libro para eliminar.",
                "Selección Requerida",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        String titulo = (String) tableModel.getValueAt(selectedRow, 1);
        int idLibro = (Integer) tableModel.getValueAt(selectedRow, 0);
        
        int confirm = JOptionPane.showConfirmDialog(this,
            "¿Está seguro de que desea eliminar el libro:\n" + titulo + "?",
            "Confirmar Eliminación",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            SwingWorker<Boolean, Void> worker = new SwingWorker<Boolean, Void>() {
                @Override
                protected Boolean doInBackground() throws Exception {
                    return libroDAO.eliminarLibro(idLibro);
                }
                
                @Override
                protected void done() {
                    try {
                        boolean success = get();
                        if (success) {
                            JOptionPane.showMessageDialog(LibroManagementWindow.this,
                                "Libro eliminado exitosamente.",
                                "Éxito",
                                JOptionPane.INFORMATION_MESSAGE);
                            cargarLibros();
                        } else {
                            JOptionPane.showMessageDialog(LibroManagementWindow.this,
                                "Error al eliminar el libro.",
                                "Error",
                                JOptionPane.ERROR_MESSAGE);
                        }
                    } catch (Exception e) {
                        JOptionPane.showMessageDialog(LibroManagementWindow.this,
                            "Error al eliminar el libro: " + e.getMessage(),
                            "Error",
                            JOptionPane.ERROR_MESSAGE);
                    }
                }
            };
            
            worker.execute();
        }
    }

    private void actualizarInfoLibro() {
        // Implementar actualización del panel de información
        // cuando se seleccione un libro en la tabla
    }
}
