package com.biblioteca.views;

import com.biblioteca.database.UsuarioDAO;
import com.biblioteca.models.Usuario;
import com.biblioteca.services.FaceAuthenticationService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 * Ventana de inicio de sesión del sistema
 */
public class LoginWindow extends JFrame {
    
    private JPanel contentPane;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton faceAuthButton;
    private JButton registroButton;
    private JLabel statusLabel;
    
    private UsuarioDAO usuarioDAO;
    private FaceAuthenticationService faceAuthService;

    public LoginWindow() {
        this.usuarioDAO = new UsuarioDAO();
        this.faceAuthService = new FaceAuthenticationService();
        
        initializeComponents();
        setupLayout();
        
        setTitle("Sistema de Gestión de Biblioteca - Iniciar Sesión");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(450, 350);
        setLocationRelativeTo(null);
        setResizable(false);
        
        // Configurar look and feel
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception e) {
            // Si no se puede cargar Nimbus, usar el look and feel por defecto
        }
    }

    private void initializeComponents() {
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(20, 20, 20, 20));
        contentPane.setLayout(new BorderLayout());
        contentPane.setBackground(new Color(240, 248, 255));
        setContentPane(contentPane);
        
        usernameField = new JTextField();
        passwordField = new JPasswordField();
        loginButton = new JButton("Iniciar Sesión");
        faceAuthButton = new JButton("Autenticación Facial");
        statusLabel = new JLabel(" ");
        
        registroButton = new JButton("Registrar Nuevo Usuario");
        
        // Configurar campos
        usernameField.setFont(new Font("Arial", Font.PLAIN, 14));
        passwordField.setFont(new Font("Arial", Font.PLAIN, 14));
        
        // Configurar botones
        loginButton.setFont(new Font("Arial", Font.BOLD, 14));
        loginButton.setBackground(new Color(25, 25, 112));
        loginButton.setForeground(Color.WHITE);
        loginButton.setFocusPainted(false);
        
        faceAuthButton.setFont(new Font("Arial", Font.PLAIN, 12));
        faceAuthButton.setBackground(new Color(70, 130, 180));
        faceAuthButton.setForeground(Color.WHITE);
        faceAuthButton.setFocusPainted(false);
        
        registroButton.setFont(new Font("Arial", Font.PLAIN, 12));
        registroButton.setBackground(new Color(70, 130, 180));
        registroButton.setForeground(Color.WHITE);
        registroButton.setFocusPainted(false);
        
        statusLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        statusLabel.setForeground(Color.RED);
    }

    private void setupLayout() {
        // Panel principal
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBackground(new Color(240, 248, 255));
        
        // Título
        JLabel titleLabel = new JLabel("Sistema de Gestión de Biblioteca");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(new Color(25, 25, 112));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel subtitleLabel = new JLabel("Iniciar Sesión");
        subtitleLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        subtitleLabel.setForeground(Color.GRAY);
        subtitleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // Espaciadores
        mainPanel.add(Box.createVerticalStrut(20));
        mainPanel.add(titleLabel);
        mainPanel.add(Box.createVerticalStrut(5));
        mainPanel.add(subtitleLabel);
        mainPanel.add(Box.createVerticalStrut(30));
        
        // Panel de formulario
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        formPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createRaisedBevelBorder(),
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;
        
        // Usuario
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(new JLabel("Usuario:"), gbc);
        
        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        usernameField.setPreferredSize(new Dimension(200, 30));
        formPanel.add(usernameField, gbc);
        
        // Contraseña
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.fill = GridBagConstraints.NONE;
        gbc.weightx = 0;
        formPanel.add(new JLabel("Contraseña:"), gbc);
        
        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        passwordField.setPreferredSize(new Dimension(200, 30));
        formPanel.add(passwordField, gbc);
        
        // Botón de login
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        loginButton.setPreferredSize(new Dimension(200, 35));
        formPanel.add(loginButton, gbc);
        
        // Botón de autenticación facial
        gbc.gridy = 3;
        faceAuthButton.setPreferredSize(new Dimension(200, 30));
        formPanel.add(faceAuthButton, gbc);
        
        // Botón de registro
        gbc.gridy = 4;
        registroButton.setPreferredSize(new Dimension(200, 25));
        formPanel.add(registroButton, gbc);
        
        // Label de estado
        gbc.gridy = 5;
        gbc.anchor = GridBagConstraints.CENTER;
        formPanel.add(statusLabel, gbc);
        
        mainPanel.add(formPanel);
        mainPanel.add(Box.createVerticalStrut(20));
        
        // Panel de información
        JPanel infoPanel = new JPanel();
        infoPanel.setBackground(new Color(240, 248, 255));
        infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
        
        JLabel infoLabel = new JLabel("Usuarios por defecto:");
        infoLabel.setFont(new Font("Arial", Font.BOLD, 12));
        infoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel adminLabel = new JLabel("Administrador: admin / admin123");
        adminLabel.setFont(new Font("Arial", Font.PLAIN, 11));
        adminLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel biblioLabel = new JLabel("Bibliotecario: mgarcia / 123456");
        biblioLabel.setFont(new Font("Arial", Font.PLAIN, 11));
        biblioLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel userLabel = new JLabel("Lector: jperez / 123456");
        userLabel.setFont(new Font("Arial", Font.PLAIN, 11));
        userLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        infoPanel.add(infoLabel);
        infoPanel.add(Box.createVerticalStrut(5));
        infoPanel.add(adminLabel);
        infoPanel.add(biblioLabel);
        infoPanel.add(userLabel);
        
        mainPanel.add(infoPanel);
        
        contentPane.add(mainPanel, BorderLayout.CENTER);
        
        // Configurar eventos
        setupEvents();
    }

    private void setupEvents() {
        // Evento del botón login
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                login();
            }
        });
        
        // Evento del botón de autenticación facial
        faceAuthButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                faceAuthentication();
            }
        });
        
        // Evento del botón de registro
        registroButton.addActionListener(e -> {
            new RegistroUsuarioWindow(this).setVisible(true);
        });
        
        // Eventos de teclado
        KeyListener enterKeyListener = new KeyListener() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    login();
                }
            }
            
            @Override
            public void keyTyped(KeyEvent e) {}
            
            @Override
            public void keyReleased(KeyEvent e) {}
        };
        
        usernameField.addKeyListener(enterKeyListener);
        passwordField.addKeyListener(enterKeyListener);
    }

    private void login() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());
        
        if (username.isEmpty() || password.isEmpty()) {
            showStatus("Por favor, ingrese usuario y contraseña", true);
            return;
        }
        
        // Verificar si el usuario está bloqueado antes de intentar autenticar
        if (usuarioDAO.usuarioBloqueado(username)) {
            showStatus("Usuario bloqueado por múltiples intentos fallidos. Contacte al administrador.", true);
            return;
        }
        
        // Mostrar progreso
        showStatus("Autenticando...", false);
        loginButton.setEnabled(false);
        
        // Ejecutar autenticación en un hilo separado
        SwingWorker<Usuario, Void> worker = new SwingWorker<Usuario, Void>() {
            @Override
            protected Usuario doInBackground() throws Exception {
                return usuarioDAO.autenticarUsuario(username, password);
            }
            
            @Override
            protected void done() {
                try {
                    Usuario usuario = get();
                    loginButton.setEnabled(true);
                    
                    if (usuario != null) {
                        if (usuario.isActivo() && !usuario.isBloqueado()) {
                            // Resetear intentos fallidos en login exitoso
                            usuarioDAO.resetearIntentosFallidos(username);
                            showStatus("Acceso concedido. Bienvenido " + usuario.getNombreCompleto(), false);
                            abrirSistemaPrincipal(usuario);
                        } else {
                            showStatus("Usuario inactivo o bloqueado por el administrador", true);
                        }
                    } else {
                        // Incrementar intentos fallidos
                        usuarioDAO.incrementarIntentosFallidos(username);
                        
                        // Verificar si ahora está bloqueado
                        if (usuarioDAO.usuarioBloqueado(username)) {
                            showStatus("Demasiados intentos fallidos. Usuario bloqueado.", true);
                        } else {
                            showStatus("Usuario o contraseña incorrectos", true);
                        }
                        
                        passwordField.setText("");
                        usernameField.requestFocus();
                    }
                } catch (Exception e) {
                    loginButton.setEnabled(true);
                    showStatus("Error en la autenticación: " + e.getMessage(), true);
                    e.printStackTrace();
                }
            }
        };
        
        worker.execute();
    }

    private void faceAuthentication() {
        if (!faceAuthService.isInitialized()) {
            showStatus("Servicio de autenticación facial no disponible", true);
            return;
        }
        
        String username = usernameField.getText().trim();
        if (username.isEmpty()) {
            showStatus("Ingrese el nombre de usuario para autenticación facial", true);
            return;
        }
        
        // Buscar usuario
        Usuario usuario = usuarioDAO.buscarPorUsername(username);
        if (usuario == null) {
            showStatus("Usuario no encontrado", true);
            return;
        }
        
        showStatus("Iniciando autenticación facial...", false);
        faceAuthButton.setEnabled(false);
        
        // Ejecutar autenticación facial en un hilo separado
        SwingWorker<FaceAuthenticationService.FaceAuthenticationResult, Void> worker = 
            new SwingWorker<FaceAuthenticationService.FaceAuthenticationResult, Void>() {
            @Override
            protected FaceAuthenticationService.FaceAuthenticationResult doInBackground() throws Exception {
                return faceAuthService.captureAndAuthenticate(usuario.getIdUsuario());
            }
            
            @Override
            protected void done() {
                try {
                    FaceAuthenticationService.FaceAuthenticationResult result = get();
                    faceAuthButton.setEnabled(true);
                    
                    if (result.isSuccess()) {
                        showStatus("Autenticación facial exitosa", false);
                        abrirSistemaPrincipal(usuario);
                    } else {
                        showStatus("Autenticación facial fallida: " + result.getMessage(), true);
                    }
                } catch (Exception e) {
                    faceAuthButton.setEnabled(true);
                    showStatus("Error en autenticación facial: " + e.getMessage(), true);
                    e.printStackTrace();
                }
            }
        };
        
        worker.execute();
    }

    private void showStatus(String message, boolean isError) {
        statusLabel.setText(message);
        statusLabel.setForeground(isError ? Color.RED : new Color(0, 128, 0));
    }

    private void abrirSistemaPrincipal(Usuario usuario) {
        SwingUtilities.invokeLater(() -> {
            dispose();
            
            try {
                MainWindow mainWindow = new MainWindow(usuario);
                mainWindow.setVisible(true);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null,
                    "Error al abrir el sistema principal: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
                
                // Volver a mostrar la ventana de login
                setVisible(true);
            }
        });
    }

    /**
     * Método principal para ejecutar la aplicación
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                new LoginWindow().setVisible(true);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null,
                    "Error al iniciar la aplicación: " + e.getMessage(),
                    "Error Fatal",
                    JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
                System.exit(1);
            }
        });
    }
}
