package com.biblioteca.views;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JToolBar;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.EmptyBorder;

import com.biblioteca.database.DatabaseConnection;
import com.biblioteca.database.LibroDAO;
import com.biblioteca.database.PrestamoDAO;
import com.biblioteca.database.UsuarioDAO;
import com.biblioteca.models.Usuario;
import com.biblioteca.services.AlertasService;
import com.biblioteca.services.FaceAuthenticationService;

/**
 * Ventana principal del sistema de gestión de biblioteca
 */
public class MainWindow extends JFrame {
    
    private Usuario usuarioActual;
    private FaceAuthenticationService faceAuthService;
    private AlertasService alertasService;
    private JPanel contentPane;
    private JMenuBar menuBar;
    private JToolBar toolBar;
    private JLabel statusLabel;
    private JLabel userLabel;

    public MainWindow(Usuario usuario) {
        this.usuarioActual = usuario;
        this.faceAuthService = new FaceAuthenticationService();
        this.alertasService = new AlertasService();
        
        initializeComponents();
        setupLayout();
        setupMenus();
        setupToolbar();
        setupStatusBar();
        
        setTitle("Sistema de Gestión de Biblioteca - " + usuario.getNombreCompleto());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocationRelativeTo(null);
        
        // Verificar conexión a base de datos y mostrar alertas
        verificarConexionDB();
        mostrarAlertasIniciales();
    }

    private void initializeComponents() {
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(new BorderLayout());
        setContentPane(contentPane);

        // Configurar look and feel
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException e) {
            // Si no se puede cargar Nimbus, usar el look and feel por defecto
        }
    }

    private void setupLayout() {
        // Panel principal con diseño de tarjetas
        JPanel mainPanel = new JPanel(new BorderLayout());
        
        // Panel de bienvenida
        JPanel welcomePanel = createWelcomePanel();
        mainPanel.add(welcomePanel, BorderLayout.CENTER);
        
        contentPane.add(mainPanel, BorderLayout.CENTER);
    }

    private JPanel createWelcomePanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        panel.setBackground(new Color(240, 248, 255));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(20, 20, 20, 20);
        
        // Título de bienvenida
        JLabel titleLabel = new JLabel("Bienvenido al Sistema de Gestión de Biblioteca");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(new Color(25, 25, 112));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 3;
        panel.add(titleLabel, gbc);
        
        // Información del usuario
        JLabel userInfoLabel = new JLabel(
            "<html><center>Usuario: " + usuarioActual.getNombreCompleto() + 
            "<br>Rol: " + usuarioActual.getNombreRol() + 
            "<br>Email: " + usuarioActual.getEmail() + "</center></html>"
        );
        userInfoLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridy = 1;
        panel.add(userInfoLabel, gbc);
        
        // Panel de acciones rápidas
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        
        // Gestión de Libros
        if (usuarioActual.puedeGestionarLibros()) {
            gbc.gridx = 0;
            panel.add(createQuickActionCard("Gestión de Libros", 
                "Agregar, modificar y buscar libros", 
                "📚", 
                e -> abrirGestionLibros()), gbc);
        }
        
        // Gestión de Usuarios
        if (usuarioActual.puedeGestionarUsuarios()) {
            gbc.gridx = 1;
            panel.add(createQuickActionCard("Gestión de Usuarios", 
                "Administrar usuarios del sistema", 
                "👥", 
                e -> abrirGestionUsuarios()), gbc);
        }
        
        // Préstamos
        gbc.gridx = usuarioActual.puedeGestionarLibros() ? 2 : 1;
        panel.add(createQuickActionCard("Préstamos", 
            "Gestionar préstamos y devoluciones", 
            "📖", 
            e -> abrirGestionPrestamos()), gbc);
        
        // Segunda fila de tarjetas
        gbc.gridy = 3;
        
        // Reportes
        if (usuarioActual.puedeVerReportes()) {
            gbc.gridx = 0;
            panel.add(createQuickActionCard("Reportes", 
                "Generar reportes del sistema", 
                "📊", 
                e -> abrirReportes()), gbc);
        }
        
        // Búsqueda Avanzada
        gbc.gridx = usuarioActual.puedeVerReportes() ? 1 : 0;
        panel.add(createQuickActionCard("Búsqueda Avanzada", 
            "Buscar libros con filtros", 
            "🔍", 
            e -> abrirBusquedaAvanzada()), gbc);
        
        // Ventas (si está habilitado)
        gbc.gridx = usuarioActual.puedeVerReportes() ? 2 : 1;
        panel.add(createQuickActionCard("Ventas", 
            "Sistema de ventas con código de barras", 
            "💰", 
            e -> abrirVentas()), gbc);
        
        return panel;
    }

    private JPanel createQuickActionCard(String title, String description, String icon, ActionListener action) {
        JPanel card = new JPanel();
        card.setLayout(new BorderLayout());
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createRaisedBevelBorder(),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        card.setBackground(Color.WHITE);
        card.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Icono
        JLabel iconLabel = new JLabel(icon, SwingConstants.CENTER);
        iconLabel.setFont(new Font("Arial", Font.PLAIN, 48));
        card.add(iconLabel, BorderLayout.NORTH);
        
        // Título
        JLabel titleLabel = new JLabel(title, SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        titleLabel.setForeground(new Color(25, 25, 112));
        card.add(titleLabel, BorderLayout.CENTER);
        
        // Descripción
        JLabel descLabel = new JLabel("<html><center>" + description + "</center></html>", SwingConstants.CENTER);
        descLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        descLabel.setForeground(Color.GRAY);
        card.add(descLabel, BorderLayout.SOUTH);
        
        // Hacer clickeable toda la tarjeta
        card.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                action.actionPerformed(new ActionEvent(card, ActionEvent.ACTION_PERFORMED, ""));
            }
            
            @Override
            public void mouseEntered(java.awt.event.MouseEvent e) {
                card.setBackground(new Color(245, 245, 245));
            }
            
            @Override
            public void mouseExited(java.awt.event.MouseEvent e) {
                card.setBackground(Color.WHITE);
            }
        });
        
        return card;
    }

    private void setupMenus() {
        menuBar = new JMenuBar();
        
        // Menú Archivo
        JMenu fileMenu = new JMenu("Archivo");
        fileMenu.add(createMenuItem("Nuevo Usuario", e -> abrirRegistroUsuario()));
        fileMenu.add(createMenuItem("Cambiar Contraseña", e -> cambiarPassword()));
        fileMenu.addSeparator();
        fileMenu.add(createMenuItem("Cerrar Sesión", e -> cerrarSesion()));
        fileMenu.add(createMenuItem("Salir", e -> System.exit(0)));
        
        // Menú Libros
        JMenu booksMenu = new JMenu("Libros");
        if (usuarioActual.puedeGestionarLibros()) {
            booksMenu.add(createMenuItem("Nuevo Libro", e -> abrirNuevoLibro()));
            booksMenu.add(createMenuItem("Gestionar Libros", e -> abrirGestionLibros()));
            booksMenu.addSeparator();
        }
        booksMenu.add(createMenuItem("Buscar Libros", e -> abrirBusquedaLibros()));
        booksMenu.add(createMenuItem("Catálogo Completo", e -> abrirCatalogo()));
        
        // Menú Préstamos
        JMenu loansMenu = new JMenu("Préstamos");
        loansMenu.add(createMenuItem("Nuevo Préstamo", e -> abrirNuevoPrestamo()));
        loansMenu.add(createMenuItem("Gestionar Préstamos", e -> abrirGestionPrestamos()));
        loansMenu.add(createMenuItem("Devoluciones", e -> abrirDevoluciones()));
        if (usuarioActual.puedeGestionarLibros()) {
            loansMenu.addSeparator();
            loansMenu.add(createMenuItem("Préstamos Vencidos", e -> abrirPrestamosVencidos()));
        }
        
        // Menú Usuarios (solo para administradores)
        if (usuarioActual.puedeGestionarUsuarios()) {
            JMenu usersMenu = new JMenu("Usuarios");
            usersMenu.add(createMenuItem("Gestionar Usuarios", e -> abrirGestionUsuarios()));
            usersMenu.add(createMenuItem("Roles y Permisos", e -> abrirGestionRoles()));
            usersMenu.add(createMenuItem("Sanciones", e -> abrirGestionSanciones()));
            menuBar.add(usersMenu);
        }
        
        // Menú Ventas
        JMenu salesMenu = new JMenu("Ventas");
        salesMenu.add(createMenuItem("Nueva Venta", e -> abrirVentas()));
        salesMenu.add(createMenuItem("Historial de Ventas", e -> abrirHistorialVentas()));
        salesMenu.add(createMenuItem("Configurar Precios", e -> abrirConfiguracionPrecios()));
        
        // Menú Reportes
        if (usuarioActual.puedeVerReportes()) {
            JMenu reportsMenu = new JMenu("Reportes");
            reportsMenu.add(createMenuItem("Libros Más Prestados", e -> generarReporteLibros()));
            reportsMenu.add(createMenuItem("Usuarios Más Activos", e -> generarReporteUsuarios()));
            reportsMenu.add(createMenuItem("Estadísticas Generales", e -> abrirEstadisticas()));
            reportsMenu.add(createMenuItem("Reportes Personalizados", e -> abrirReportes()));
            menuBar.add(reportsMenu);
        }
        
        // Menú Ayuda
        JMenu helpMenu = new JMenu("Ayuda");
        helpMenu.add(createMenuItem("Manual de Usuario", e -> abrirManual()));
        helpMenu.add(createMenuItem("Acerca del Sistema", e -> mostrarAcercaDe()));
        
        menuBar.add(fileMenu);
        menuBar.add(booksMenu);
        menuBar.add(loansMenu);
        menuBar.add(salesMenu);
        menuBar.add(helpMenu);
        
        setJMenuBar(menuBar);
    }

    private JMenuItem createMenuItem(String text, ActionListener action) {
        JMenuItem item = new JMenuItem(text);
        item.addActionListener(action);
        return item;
    }

    private void setupToolbar() {
        toolBar = new JToolBar();
        toolBar.setFloatable(false);
        
        toolBar.add(createToolbarButton("Nuevo Libro", "📚", e -> abrirNuevoLibro()));
        toolBar.add(createToolbarButton("Nuevo Préstamo", "📖", e -> abrirNuevoPrestamo()));
        toolBar.add(createToolbarButton("Buscar", "🔍", e -> abrirBusquedaLibros()));
        toolBar.addSeparator();
        toolBar.add(createToolbarButton("Ventas", "💰", e -> abrirVentas()));
        if (usuarioActual.puedeVerReportes()) {
            toolBar.add(createToolbarButton("Reportes", "📊", e -> abrirReportes()));
        }
        toolBar.addSeparator();
        toolBar.add(createToolbarButton("Configuración", "⚙️", e -> abrirConfiguracion()));
        
        contentPane.add(toolBar, BorderLayout.NORTH);
    }

    private JButton createToolbarButton(String text, String icon, ActionListener action) {
        JButton button = new JButton(icon + " " + text);
        button.addActionListener(action);
        button.setFocusable(false);
        return button;
    }

    private void setupStatusBar() {
        JPanel statusPanel = new JPanel(new BorderLayout());
        statusPanel.setBorder(BorderFactory.createLoweredBevelBorder());
        
        statusLabel = new JLabel("Sistema listo");
        statusLabel.setBorder(new EmptyBorder(2, 5, 2, 5));
        
        userLabel = new JLabel("Usuario: " + usuarioActual.getNombreCompleto() + " (" + usuarioActual.getNombreRol() + ")");
        userLabel.setBorder(new EmptyBorder(2, 5, 2, 5));
        
        statusPanel.add(statusLabel, BorderLayout.WEST);
        statusPanel.add(userLabel, BorderLayout.EAST);
        
        contentPane.add(statusPanel, BorderLayout.SOUTH);
    }

    private void verificarConexionDB() {
        SwingUtilities.invokeLater(() -> {
            DatabaseConnection dbConnection = DatabaseConnection.getInstance();
            if (dbConnection.testConnection()) {
                statusLabel.setText("Conectado a la base de datos");
                statusLabel.setForeground(new Color(0, 128, 0));
            } else {
                statusLabel.setText("Error de conexión a la base de datos");
                statusLabel.setForeground(Color.RED);
                
                JOptionPane.showMessageDialog(this,
                    "No se pudo conectar a la base de datos.\nVerifique que XAMPP esté ejecutándose.",
                    "Error de Conexión",
                    JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    // Métodos para abrir ventanas específicas
    private void abrirGestionLibros() {
        statusLabel.setText("Abriendo gestión de libros...");
        SwingUtilities.invokeLater(() -> {
            try {
                LibroManagementWindow libroWindow = new LibroManagementWindow(usuarioActual);
                libroWindow.setVisible(true);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this,
                    "Error al abrir gestión de libros: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private void abrirGestionUsuarios() {
        statusLabel.setText("Abriendo gestión de usuarios...");
        SwingUtilities.invokeLater(() -> {
            try {
                GestionUsuariosWindow gestionWindow = new GestionUsuariosWindow(usuarioActual);
                gestionWindow.setVisible(true);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this,
                    "Error al abrir gestión de usuarios: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private void abrirGestionPrestamos() {
        statusLabel.setText("Abriendo gestión de préstamos...");
        SwingUtilities.invokeLater(() -> {
            try {
                GestionPrestamosWindow gestionWindow = new GestionPrestamosWindow(usuarioActual);
                gestionWindow.setVisible(true);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this,
                    "Error al abrir gestión de préstamos: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private void abrirReportes() {
        statusLabel.setText("Abriendo reportes y estadísticas...");
        SwingUtilities.invokeLater(() -> {
            try {
                ReportesWindow reportesWindow = new ReportesWindow(usuarioActual);
                reportesWindow.setVisible(true);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this,
                    "Error al abrir reportes: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private void abrirBusquedaAvanzada() {
        statusLabel.setText("Abriendo búsqueda avanzada...");
        SwingUtilities.invokeLater(() -> {
            try {
                System.out.println("Intentando abrir BusquedaLibrosWindow desde búsqueda avanzada...");
                BusquedaLibrosWindow busquedaWindow = new BusquedaLibrosWindow(usuarioActual);
                busquedaWindow.setVisible(true);
                statusLabel.setText("Ventana de búsqueda avanzada abierta");
            } catch (Exception e) {
                System.err.println("Error detallado al abrir búsqueda avanzada: " + e.getMessage());
                e.printStackTrace();
                statusLabel.setText("Error al abrir búsqueda avanzada");
                JOptionPane.showMessageDialog(this,
                    "Error al abrir búsqueda avanzada:\n" + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private void abrirVentas() {
        statusLabel.setText("Abriendo sistema de ventas...");
        SwingUtilities.invokeLater(() -> {
            try {
                VentasWindow ventasWindow = new VentasWindow(usuarioActual);
                ventasWindow.setVisible(true);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this,
                    "Error al abrir sistema de ventas: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private void abrirRegistroUsuario() {
        statusLabel.setText("Abriendo registro de usuario...");
        SwingUtilities.invokeLater(() -> {
            try {
                RegistroUsuarioWindow registroWindow = new RegistroUsuarioWindow(this);
                registroWindow.setVisible(true);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this,
                    "Error al abrir registro de usuario: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private void cambiarPassword() {
        statusLabel.setText("Abriendo cambio de contraseña...");
        
        SwingUtilities.invokeLater(() -> {
            try {
                CambioPasswordWindow cambioWindow = new CambioPasswordWindow(this, usuarioActual);
                cambioWindow.setVisible(true);
                statusLabel.setText("Ventana de cambio de contraseña abierta");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this,
                    "Error al abrir cambio de contraseña: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
                statusLabel.setText("Error al abrir cambio de contraseña");
            }
        });
    }

    private void cerrarSesion() {
        int option = JOptionPane.showConfirmDialog(this,
            "¿Está seguro de que desea cerrar sesión?",
            "Cerrar Sesión",
            JOptionPane.YES_NO_OPTION);
        
        if (option == JOptionPane.YES_OPTION) {
            dispose();
            // Volver a la ventana de login
            SwingUtilities.invokeLater(() -> {
                new LoginWindow().setVisible(true);
            });
        }
    }

    private void abrirNuevoLibro() {
        statusLabel.setText("Abriendo formulario de nuevo libro...");
        SwingUtilities.invokeLater(() -> {
            try {
                LibroFormWindow libroForm = new LibroFormWindow(this, null, usuarioActual);
                libroForm.setVisible(true);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this,
                    "Error al abrir formulario de libro: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private void abrirBusquedaLibros() {
        statusLabel.setText("Abriendo búsqueda de libros...");
        SwingUtilities.invokeLater(() -> {
            try {
                System.out.println("Intentando abrir BusquedaLibrosWindow...");
                BusquedaLibrosWindow busquedaWindow = new BusquedaLibrosWindow(usuarioActual);
                busquedaWindow.setVisible(true);
                statusLabel.setText("Ventana de búsqueda abierta");
            } catch (Exception e) {
                System.err.println("Error detallado al abrir búsqueda: " + e.getMessage());
                e.printStackTrace();
                statusLabel.setText("Error al abrir búsqueda de libros");
                JOptionPane.showMessageDialog(this,
                    "Error al abrir búsqueda de libros:\n" + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private void abrirCatalogo() {
        statusLabel.setText("Abriendo catálogo completo...");
    }

    private void abrirNuevoPrestamo() {
        statusLabel.setText("Abriendo nuevo préstamo...");
        SwingUtilities.invokeLater(() -> {
            try {
                LibroDAO libroDAO = new LibroDAO();
                UsuarioDAO usuarioDAO = new UsuarioDAO();
                PrestamoDAO prestamoDAO = new PrestamoDAO();
                
                NuevoPrestamoDialog dialog = new NuevoPrestamoDialog(this, usuarioActual, libroDAO, usuarioDAO, prestamoDAO);
                dialog.setVisible(true);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this,
                    "Error al abrir nuevo préstamo: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private void abrirDevoluciones() {
        statusLabel.setText("Abriendo devoluciones...");
    }

    private void abrirPrestamosVencidos() {
        statusLabel.setText("Abriendo préstamos vencidos...");
    }

    private void abrirGestionRoles() {
        statusLabel.setText("Abriendo gestión de roles...");
    }

    private void abrirGestionSanciones() {
        statusLabel.setText("Abriendo gestión de sanciones...");
        SwingUtilities.invokeLater(() -> {
            try {
                GestionSancionesWindow sancionesWindow = new GestionSancionesWindow(usuarioActual);
                sancionesWindow.setVisible(true);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this,
                    "Error al abrir gestión de sanciones: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private void abrirHistorialVentas() {
        statusLabel.setText("Abriendo historial de ventas...");
    }

    private void abrirConfiguracionPrecios() {
        statusLabel.setText("Abriendo configuración de precios...");
    }

    private void generarReporteLibros() {
        statusLabel.setText("Abriendo reportes de libros...");
        SwingUtilities.invokeLater(() -> {
            try {
                ReportesWindow reportesWindow = new ReportesWindow(usuarioActual);
                reportesWindow.setVisible(true);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this,
                    "Error al abrir reportes: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private void generarReporteUsuarios() {
        statusLabel.setText("Abriendo reportes de usuarios...");
        SwingUtilities.invokeLater(() -> {
            try {
                ReportesWindow reportesWindow = new ReportesWindow(usuarioActual);
                reportesWindow.setVisible(true);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this,
                    "Error al abrir reportes: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private void abrirEstadisticas() {
        statusLabel.setText("Abriendo estadísticas...");
        SwingUtilities.invokeLater(() -> {
            try {
                ReportesWindow reportesWindow = new ReportesWindow(usuarioActual);
                reportesWindow.setVisible(true);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this,
                    "Error al abrir estadísticas: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private void abrirManual() {
        statusLabel.setText("Abriendo manual de usuario...");
    }

    private void mostrarAcercaDe() {
        JOptionPane.showMessageDialog(this,
            "<html><center>" +
            "<h2>Sistema de Gestión de Biblioteca</h2>" +
            "<p>Versión 1.0</p>" +
            "<p>Desarrollado con Java Swing y MySQL</p>" +
            "<p>Características:</p>" +
            "<ul>" +
            "<li>Gestión completa de libros y usuarios</li>" +
            "<li>Sistema de préstamos y devoluciones</li>" +
            "<li>Autenticación facial</li>" +
            "<li>Sistema de ventas con código de barras</li>" +
            "<li>Reportes y estadísticas</li>" +
            "</ul>" +
            "</center></html>",
            "Acerca del Sistema",
            JOptionPane.INFORMATION_MESSAGE);
    }

    private void abrirConfiguracion() {
        statusLabel.setText("Abriendo configuración del sistema...");
        // Aquí se abriría una ventana de configuración
        JOptionPane.showMessageDialog(this,
            "Funcionalidad de configuración disponible en próxima versión.",
            "Configuración",
            JOptionPane.INFORMATION_MESSAGE);
    }
    
    /**
     * Muestra alertas del sistema al iniciar la aplicación
     */
    private void mostrarAlertasIniciales() {
        SwingUtilities.invokeLater(() -> {
            // Esperar un momento para que la ventana se cargue completamente
            Timer timer = new Timer(2000, e -> {
                if (alertasService != null) {
                    alertasService.mostrarAlertasEmergentes();
                }
            });
            timer.setRepeats(false);
            timer.start();
        });
    }
}
