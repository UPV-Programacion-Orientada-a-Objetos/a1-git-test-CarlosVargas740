package com.biblioteca.views;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.time.LocalDate;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;

import com.biblioteca.database.LibroDAO;
import com.biblioteca.database.PrestamoDAO;
import com.biblioteca.database.UsuarioDAO;
import com.biblioteca.models.Libro;
import com.biblioteca.models.Prestamo;
import com.biblioteca.models.Usuario;

/**
 * Diálogo para crear un nuevo préstamo
 */
public class NuevoPrestamoDialog extends JDialog {
    
    private final Usuario usuarioActual;
    private final LibroDAO libroDAO;
    private final UsuarioDAO usuarioDAO;
    private final PrestamoDAO prestamoDAO;
    private boolean prestamoCreado = false;
    
    private JPanel contentPane;
    private JTextField buscarUsuarioField;
    private JComboBox<Usuario> usuarioCombo;
    private JTextField buscarLibroField;
    private JComboBox<Libro> libroCombo;
    private JSpinner diasPrestamoSpinner;
    private JTextArea notasArea;
    private JButton buscarUsuarioButton;
    private JButton buscarLibroButton;
    private JButton crearPrestamoButton;
    private JButton cancelarButton;
    private JLabel statusLabel;

    public NuevoPrestamoDialog(Frame parent, Usuario usuarioActual, LibroDAO libroDAO, 
                              UsuarioDAO usuarioDAO, PrestamoDAO prestamoDAO) {
        super(parent, "Nuevo Préstamo", true);
        this.usuarioActual = usuarioActual;
        this.libroDAO = libroDAO;
        this.usuarioDAO = usuarioDAO;
        this.prestamoDAO = prestamoDAO;
        
        initializeComponents();
        setupLayout();
        setupEvents();
        
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(parent);
        pack();
    }

    private void initializeComponents() {
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(20, 20, 20, 20));
        setContentPane(contentPane);

        // Búsqueda de usuario
        buscarUsuarioField = new JTextField(20);
        buscarUsuarioButton = new JButton("Buscar Usuario");
        usuarioCombo = new JComboBox<>();
        usuarioCombo.setPreferredSize(new Dimension(300, 25));

        // Búsqueda de libro
        buscarLibroField = new JTextField(20);
        buscarLibroButton = new JButton("Buscar Libro");
        libroCombo = new JComboBox<>();
        libroCombo.setPreferredSize(new Dimension(300, 25));

        // Días de préstamo
        diasPrestamoSpinner = new JSpinner(new SpinnerNumberModel(15, 1, 30, 1));

        // Notas
        notasArea = new JTextArea(3, 20);
        notasArea.setLineWrap(true);
        notasArea.setWrapStyleWord(true);

        // Botones
        crearPrestamoButton = new JButton("Crear Préstamo");
        cancelarButton = new JButton("Cancelar");
        
        // Estado
        statusLabel = new JLabel("Complete los datos del préstamo");
    }

    private void setupLayout() {
        contentPane.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        // Título
        gbc.gridx = 0; gbc.gridy = 0;
        gbc.gridwidth = 3;
        gbc.anchor = GridBagConstraints.CENTER;
        JLabel titleLabel = new JLabel("Nuevo Préstamo");
        titleLabel.setFont(titleLabel.getFont().deriveFont(Font.BOLD, 16f));
        contentPane.add(titleLabel, gbc);

        // Usuario
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.WEST;
        
        gbc.gridx = 0; gbc.gridy = 1;
        contentPane.add(new JLabel("Buscar Usuario:"), gbc);
        
        gbc.gridx = 1; gbc.gridy = 1;
        contentPane.add(buscarUsuarioField, gbc);
        
        gbc.gridx = 2; gbc.gridy = 1;
        contentPane.add(buscarUsuarioButton, gbc);
        
        gbc.gridx = 0; gbc.gridy = 2;
        contentPane.add(new JLabel("Usuario:"), gbc);
        
        gbc.gridx = 1; gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        contentPane.add(usuarioCombo, gbc);

        // Libro
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.NONE;
        
        gbc.gridx = 0; gbc.gridy = 3;
        contentPane.add(new JLabel("Buscar Libro:"), gbc);
        
        gbc.gridx = 1; gbc.gridy = 3;
        contentPane.add(buscarLibroField, gbc);
        
        gbc.gridx = 2; gbc.gridy = 3;
        contentPane.add(buscarLibroButton, gbc);
        
        gbc.gridx = 0; gbc.gridy = 4;
        contentPane.add(new JLabel("Libro:"), gbc);
        
        gbc.gridx = 1; gbc.gridy = 4;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        contentPane.add(libroCombo, gbc);

        // Días de préstamo
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.NONE;
        
        gbc.gridx = 0; gbc.gridy = 5;
        contentPane.add(new JLabel("Días de Préstamo:"), gbc);
        
        gbc.gridx = 1; gbc.gridy = 5;
        contentPane.add(diasPrestamoSpinner, gbc);

        // Notas
        gbc.gridx = 0; gbc.gridy = 6;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        contentPane.add(new JLabel("Notas:"), gbc);
        
        gbc.gridx = 1; gbc.gridy = 6;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        contentPane.add(new JScrollPane(notasArea), gbc);

        // Botones
        gbc.gridx = 0; gbc.gridy = 7;
        gbc.gridwidth = 3;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.CENTER;
        
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(crearPrestamoButton);
        buttonPanel.add(cancelarButton);
        contentPane.add(buttonPanel, gbc);

        // Estado
        gbc.gridx = 0; gbc.gridy = 8;
        gbc.gridwidth = 3;
        gbc.anchor = GridBagConstraints.WEST;
        contentPane.add(statusLabel, gbc);
    }

    private void setupEvents() {
        buscarUsuarioButton.addActionListener(e -> buscarUsuarios());
        
        buscarLibroButton.addActionListener(e -> buscarLibros());
        
        crearPrestamoButton.addActionListener(e -> crearPrestamo());
        
        cancelarButton.addActionListener(e -> dispose());
        
        usuarioCombo.addActionListener(e -> validarFormulario());
        
        libroCombo.addActionListener(e -> validarFormulario());
    }

    private void buscarUsuarios() {
        String termino = buscarUsuarioField.getText().trim();
        
        if (termino.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Ingrese un término de búsqueda para el usuario.",
                "Término Requerido",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        SwingUtilities.invokeLater(() -> {
            try {
                List<Usuario> usuarios = usuarioDAO.buscarPorTermino(termino);
                
                usuarioCombo.removeAllItems();
                for (Usuario usuario : usuarios) {
                    usuarioCombo.addItem(usuario);
                }
                
                if (usuarios.isEmpty()) {
                    statusLabel.setText("No se encontraron usuarios con el término: " + termino);
                } else {
                    statusLabel.setText("Se encontraron " + usuarios.size() + " usuarios");
                }
                
            } catch (Exception ex) {
                statusLabel.setText("Error al buscar usuarios: " + ex.getMessage());
                JOptionPane.showMessageDialog(this,
                    "Error al buscar usuarios: " + ex.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private void buscarLibros() {
        String termino = buscarLibroField.getText().trim();
        
        if (termino.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Ingrese un término de búsqueda para el libro.",
                "Término Requerido",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        SwingUtilities.invokeLater(() -> {
            try {
                List<Libro> libros = libroDAO.buscarLibros(termino, null, null, null, true);
                
                // Filtrar solo libros disponibles
                libroCombo.removeAllItems();
                int librosDisponibles = 0;
                
                for (Libro libro : libros) {
                    if (libro.getCantidadDisponible() > 0) {
                        libroCombo.addItem(libro);
                        librosDisponibles++;
                    }
                }
                
                if (librosDisponibles == 0) {
                    statusLabel.setText("No se encontraron libros disponibles con el término: " + termino);
                } else {
                    statusLabel.setText("Se encontraron " + librosDisponibles + " libros disponibles");
                }
                
            } catch (Exception ex) {
                statusLabel.setText("Error al buscar libros: " + ex.getMessage());
                JOptionPane.showMessageDialog(this,
                    "Error al buscar libros: " + ex.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private void crearPrestamo() {
        if (!validarDatos()) {
            return;
        }
        
        Usuario usuario = (Usuario) usuarioCombo.getSelectedItem();
        Libro libro = (Libro) libroCombo.getSelectedItem();
        int diasPrestamo = (Integer) diasPrestamoSpinner.getValue();
        String notas = notasArea.getText().trim();
        
        // Verificar disponibilidad del libro
        if (libro.getCantidadDisponible() <= 0) {
            JOptionPane.showMessageDialog(this,
                "El libro seleccionado no está disponible para préstamo.",
                "Libro No Disponible",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        // Crear el préstamo
        Prestamo prestamo = new Prestamo();
        prestamo.setIdUsuario(usuario.getIdUsuario());
        prestamo.setIdLibro(libro.getIdLibro());
        prestamo.setFechaDevolucionProgramada(LocalDate.now().plusDays(diasPrestamo));
        prestamo.setObservaciones(notas.isEmpty() ? null : notas);
        
        if (prestamoDAO.crearPrestamo(prestamo)) {
            JOptionPane.showMessageDialog(this,
                "Préstamo creado exitosamente.\n\n" +
                "Usuario: " + usuario.getNombreCompleto() + "\n" +
                "Libro: " + libro.getTitulo() + "\n" +
                "Fecha de devolución: " + prestamo.getFechaDevolucionProgramada(),
                "Préstamo Creado",
                JOptionPane.INFORMATION_MESSAGE);
            
            prestamoCreado = true;
            dispose();
        } else {
            JOptionPane.showMessageDialog(this,
                "Error al crear el préstamo.",
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private boolean validarDatos() {
        if (usuarioCombo.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this,
                "Debe seleccionar un usuario.",
                "Usuario Requerido",
                JOptionPane.WARNING_MESSAGE);
            return false;
        }
        
        if (libroCombo.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this,
                "Debe seleccionar un libro.",
                "Libro Requerido",
                JOptionPane.WARNING_MESSAGE);
            return false;
        }
        
        return true;
    }

    private void validarFormulario() {
        boolean datosCompletos = usuarioCombo.getSelectedItem() != null && 
                                libroCombo.getSelectedItem() != null;
        
        crearPrestamoButton.setEnabled(datosCompletos);
        
        if (datosCompletos) {
            statusLabel.setText("Datos completos - Listo para crear préstamo");
        }
    }

    public boolean isPrestamoCreado() {
        return prestamoCreado;
    }
}
