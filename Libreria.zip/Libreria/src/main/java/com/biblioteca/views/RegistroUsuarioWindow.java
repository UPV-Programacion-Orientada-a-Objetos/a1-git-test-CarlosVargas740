package com.biblioteca.views;

import com.biblioteca.database.UsuarioDAO;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Ventana para registro de nuevos usuarios
 */
public class RegistroUsuarioWindow extends JDialog {
    
    private JTextField nombreField;
    private JTextField apellidoField;
    private JTextField emailField;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JPasswordField confirmPasswordField;
    private JComboBox<String> rolCombo;
    private JComboBox<String> tipoUsuarioCombo;
    private JButton registrarButton;
    private JButton cancelarButton;
    
    private UsuarioDAO usuarioDAO;

    public RegistroUsuarioWindow(JFrame parent) {
        super(parent, "Registro de Usuario", true);
        this.usuarioDAO = new UsuarioDAO();
        
        initializeComponents();
        setupLayout();
        setupEvents();
        
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        setSize(400, 450);
        setLocationRelativeTo(parent);
        setResizable(false);
    }

    private void initializeComponents() {
        nombreField = new JTextField(20);
        apellidoField = new JTextField(20);
        emailField = new JTextField(20);
        usernameField = new JTextField(20);
        passwordField = new JPasswordField(20);
        confirmPasswordField = new JPasswordField(20);
        
        // ComboBox para roles
        String[] roles = {"Lector", "Bibliotecario", "Administrador"};
        rolCombo = new JComboBox<>(roles);
        
        // ComboBox para tipo de usuario
        String[] tiposUsuario = {"estudiante", "docente", "otro"};
        tipoUsuarioCombo = new JComboBox<>(tiposUsuario);
        
        registrarButton = new JButton("Registrar");
        cancelarButton = new JButton("Cancelar");
        
        // Estilos
        registrarButton.setBackground(new Color(34, 139, 34));
        registrarButton.setForeground(Color.WHITE);
        registrarButton.setFocusPainted(false);
        
        cancelarButton.setBackground(new Color(220, 20, 60));
        cancelarButton.setForeground(Color.WHITE);
        cancelarButton.setFocusPainted(false);
    }

    private void setupLayout() {
        JPanel contentPane = new JPanel(new BorderLayout());
        contentPane.setBorder(new EmptyBorder(20, 20, 20, 20));
        setContentPane(contentPane);
        
        // Panel principal con formulario
        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        
        int row = 0;
        
        // Nombre
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(new JLabel("Nombre:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        formPanel.add(nombreField, gbc);
        row++;
        
        // Apellido
        gbc.gridx = 0; gbc.gridy = row; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Apellido:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        formPanel.add(apellidoField, gbc);
        row++;
        
        // Email
        gbc.gridx = 0; gbc.gridy = row; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Email:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        formPanel.add(emailField, gbc);
        row++;
        
        // Username
        gbc.gridx = 0; gbc.gridy = row; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Usuario:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        formPanel.add(usernameField, gbc);
        row++;
        
        // Password
        gbc.gridx = 0; gbc.gridy = row; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Contraseña:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        formPanel.add(passwordField, gbc);
        row++;
        
        // Confirm Password
        gbc.gridx = 0; gbc.gridy = row; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Confirmar:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        formPanel.add(confirmPasswordField, gbc);
        row++;
        
        // Tipo de usuario
        gbc.gridx = 0; gbc.gridy = row; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Tipo:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        formPanel.add(tipoUsuarioCombo, gbc);
        row++;
        
        // Rol
        gbc.gridx = 0; gbc.gridy = row; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Rol:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        formPanel.add(rolCombo, gbc);
        
        contentPane.add(formPanel, BorderLayout.CENTER);
        
        // Panel de botones
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(registrarButton);
        buttonPanel.add(cancelarButton);
        contentPane.add(buttonPanel, BorderLayout.SOUTH);
        
        // Título
        JLabel titleLabel = new JLabel("Registro de Nuevo Usuario", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        titleLabel.setBorder(new EmptyBorder(0, 0, 20, 0));
        contentPane.add(titleLabel, BorderLayout.NORTH);
    }

    private void setupEvents() {
        registrarButton.addActionListener(e -> registrarUsuario());
        cancelarButton.addActionListener(e -> dispose());
    }

    private void registrarUsuario() {
        // Validar campos
        if (!validarCampos()) {
            return;
        }
        
        final String nombre = nombreField.getText().trim();
        final String apellido = apellidoField.getText().trim();
        final String email = emailField.getText().trim();
        final String username = usernameField.getText().trim();
        final String password = new String(passwordField.getPassword());
        
        // Determinar rol
        final int idRol;
        switch (rolCombo.getSelectedIndex()) {
            case 0: idRol = 3; break; // Lector
            case 1: idRol = 2; break; // Bibliotecario
            case 2: idRol = 1; break; // Administrador
            default: idRol = 3; break; // Por defecto Lector
        }
        
        // Crear usuario
        SwingWorker<Boolean, Void> worker = new SwingWorker<Boolean, Void>() {
            @Override
            protected Boolean doInBackground() throws Exception {
                return usuarioDAO.crearUsuarioConPassword(nombre, apellido, email, username, password, idRol);
            }
            
            @Override
            protected void done() {
                try {
                    boolean success = get();
                    if (success) {
                        JOptionPane.showMessageDialog(RegistroUsuarioWindow.this,
                            "Usuario registrado exitosamente",
                            "Éxito",
                            JOptionPane.INFORMATION_MESSAGE);
                        dispose();
                    } else {
                        JOptionPane.showMessageDialog(RegistroUsuarioWindow.this,
                            "Error al registrar usuario. Verifique que el email y username no estén en uso.",
                            "Error",
                            JOptionPane.ERROR_MESSAGE);
                    }
                } catch (InterruptedException | java.util.concurrent.ExecutionException e) {
                    JOptionPane.showMessageDialog(RegistroUsuarioWindow.this,
                        "Error: " + e.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                }
            }
        };
        
        worker.execute();
    }

    private boolean validarCampos() {
        if (nombreField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "El nombre es obligatorio", "Validación", JOptionPane.WARNING_MESSAGE);
            nombreField.requestFocus();
            return false;
        }
        
        if (apellidoField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "El apellido es obligatorio", "Validación", JOptionPane.WARNING_MESSAGE);
            apellidoField.requestFocus();
            return false;
        }
        
        if (emailField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "El email es obligatorio", "Validación", JOptionPane.WARNING_MESSAGE);
            emailField.requestFocus();
            return false;
        }
        
        if (usernameField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "El usuario es obligatorio", "Validación", JOptionPane.WARNING_MESSAGE);
            usernameField.requestFocus();
            return false;
        }
        
        String password = new String(passwordField.getPassword());
        String confirmPassword = new String(confirmPasswordField.getPassword());
        
        if (password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "La contraseña es obligatoria", "Validación", JOptionPane.WARNING_MESSAGE);
            passwordField.requestFocus();
            return false;
        }
        
        if (password.length() < 4) {
            JOptionPane.showMessageDialog(this, "La contraseña debe tener al menos 4 caracteres", "Validación", JOptionPane.WARNING_MESSAGE);
            passwordField.requestFocus();
            return false;
        }
        
        if (!password.equals(confirmPassword)) {
            JOptionPane.showMessageDialog(this, "Las contraseñas no coinciden", "Validación", JOptionPane.WARNING_MESSAGE);
            confirmPasswordField.requestFocus();
            return false;
        }
        
        return true;
    }
}
