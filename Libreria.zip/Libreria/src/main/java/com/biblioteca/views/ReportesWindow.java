package com.biblioteca.views;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.biblioteca.database.LibroDAO;
import com.biblioteca.database.PrestamoDAO;
import com.biblioteca.database.UsuarioDAO;
import com.biblioteca.models.Libro;
import com.biblioteca.models.Prestamo;
import com.biblioteca.models.Usuario;

/**
 * Ventana para generar reportes y estadísticas del sistema
 */
public class ReportesWindow extends JFrame {
    
    private final Usuario usuarioActual;
    private final LibroDAO libroDAO;
    private final UsuarioDAO usuarioDAO;
    private final PrestamoDAO prestamoDAO;
    
    private JPanel contentPane;
    private JTabbedPane tabbedPane;
    private JTextArea reporteArea;
    private JTable estadisticasTable;
    private DefaultTableModel estadisticasModel;
    private JLabel statusLabel;
    
    // Controles de reportes
    private JComboBox<String> tipoReporteCombo;
    private JButton generarReporteButton;
    private JButton exportarButton;
    private JButton imprimirButton;
    
    // Controles de estadísticas
    private JButton actualizarEstadisticasButton;
    private JLabel totalLibrosLabel;
    private JLabel totalUsuariosLabel;
    private JLabel prestamosActivosLabel;
    private JLabel prestamosVencidosLabel;

    public ReportesWindow(Usuario usuarioActual) {
        this.usuarioActual = usuarioActual;
        this.libroDAO = new LibroDAO();
        this.usuarioDAO = new UsuarioDAO();
        this.prestamoDAO = new PrestamoDAO();
        
        initializeComponents();
        setupLayout();
        setupEvents();
        cargarEstadisticasIniciales();
        
        setTitle("Reportes y Estadísticas - " + usuarioActual.getNombreCompleto());
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);
    }

    private void initializeComponents() {
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(15, 15, 15, 15));
        setContentPane(contentPane);

        tabbedPane = new JTabbedPane();
        
        // Área de reportes
        reporteArea = new JTextArea();
        reporteArea.setEditable(false);
        reporteArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        
        // Controles de reportes
        String[] tiposReporte = {
            "Inventario de Libros",
            "Lista de Usuarios",
            "Préstamos Activos",
            "Préstamos Vencidos",
            "Historial de Préstamos",
            "Libros Más Prestados",
            "Usuarios Más Activos"
        };
        
        tipoReporteCombo = new JComboBox<>(tiposReporte);
        generarReporteButton = new JButton("Generar Reporte");
        exportarButton = new JButton("Exportar CSV");
        imprimirButton = new JButton("Imprimir");
        
        // Tabla de estadísticas
        String[] estadisticasColumnNames = {
            "Métrica", "Valor", "Descripción"
        };
        
        estadisticasModel = new DefaultTableModel(estadisticasColumnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        estadisticasTable = new JTable(estadisticasModel);
        
        // Labels de estadísticas rápidas
        totalLibrosLabel = new JLabel("Total Libros: 0");
        totalUsuariosLabel = new JLabel("Total Usuarios: 0");
        prestamosActivosLabel = new JLabel("Préstamos Activos: 0");
        prestamosVencidosLabel = new JLabel("Préstamos Vencidos: 0");
        
        actualizarEstadisticasButton = new JButton("Actualizar Estadísticas");
        
        statusLabel = new JLabel("Listo para generar reportes");
    }

    private void setupLayout() {
        contentPane.setLayout(new BorderLayout());
        
        // Panel de reportes
        JPanel reportesPanel = new JPanel(new BorderLayout());
        
        // Panel superior de controles
        JPanel controlesPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        controlesPanel.add(new JLabel("Tipo de Reporte:"));
        controlesPanel.add(tipoReporteCombo);
        controlesPanel.add(generarReporteButton);
        controlesPanel.add(exportarButton);
        controlesPanel.add(imprimirButton);
        
        reportesPanel.add(controlesPanel, BorderLayout.NORTH);
        reportesPanel.add(new JScrollPane(reporteArea), BorderLayout.CENTER);
        
        // Panel de estadísticas
        JPanel estadisticasPanel = new JPanel(new BorderLayout());
        
        // Panel de estadísticas rápidas
        JPanel statsPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        statsPanel.setBorder(BorderFactory.createTitledBorder("Estadísticas Rápidas"));
        statsPanel.add(totalLibrosLabel);
        statsPanel.add(totalUsuariosLabel);
        statsPanel.add(prestamosActivosLabel);
        statsPanel.add(prestamosVencidosLabel);
        
        JPanel statsControlPanel = new JPanel(new BorderLayout());
        statsControlPanel.add(statsPanel, BorderLayout.CENTER);
        statsControlPanel.add(actualizarEstadisticasButton, BorderLayout.SOUTH);
        
        estadisticasPanel.add(statsControlPanel, BorderLayout.NORTH);
        estadisticasPanel.add(new JScrollPane(estadisticasTable), BorderLayout.CENTER);
        
        // Agregar tabs
        tabbedPane.addTab("Reportes", reportesPanel);
        tabbedPane.addTab("Estadísticas", estadisticasPanel);
        
        contentPane.add(tabbedPane, BorderLayout.CENTER);
        contentPane.add(statusLabel, BorderLayout.SOUTH);
    }

    private void setupEvents() {
        generarReporteButton.addActionListener(e -> generarReporte());
        
        exportarButton.addActionListener(e -> exportarReporte());
        
        imprimirButton.addActionListener(e -> imprimirReporte());
        
        actualizarEstadisticasButton.addActionListener(e -> cargarEstadisticasIniciales());
        
        tipoReporteCombo.addActionListener(e -> {
            exportarButton.setEnabled(false);
            imprimirButton.setEnabled(false);
        });
    }

    private void generarReporte() {
        String tipoReporte = (String) tipoReporteCombo.getSelectedItem();
        statusLabel.setText("Generando reporte...");
        
        SwingUtilities.invokeLater(() -> {
            try {
                String reporte = "";
                
                switch (tipoReporte) {
                    case "Inventario de Libros":
                        reporte = generarReporteInventario();
                        break;
                    case "Lista de Usuarios":
                        reporte = generarReporteUsuarios();
                        break;
                    case "Préstamos Activos":
                        reporte = generarReportePrestamosActivos();
                        break;
                    case "Préstamos Vencidos":
                        reporte = generarReportePrestamosVencidos();
                        break;
                    case "Historial de Préstamos":
                        reporte = generarReporteHistorialPrestamos();
                        break;
                    case "Libros Más Prestados":
                        reporte = generarReporteLibrosMasPrestados();
                        break;
                    case "Usuarios Más Activos":
                        reporte = generarReporteUsuariosMasActivos();
                        break;
                }
                
                reporteArea.setText(reporte);
                exportarButton.setEnabled(true);
                imprimirButton.setEnabled(true);
                statusLabel.setText("Reporte generado exitosamente");
                
            } catch (Exception e) {
                statusLabel.setText("Error al generar reporte: " + e.getMessage());
                JOptionPane.showMessageDialog(this,
                    "Error al generar reporte: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private String generarReporteInventario() throws Exception {
        List<Libro> libros = libroDAO.obtenerTodos();
        
        StringBuilder sb = new StringBuilder();
        sb.append("REPORTE DE INVENTARIO DE LIBROS\n");
        sb.append("================================\n\n");
        sb.append("Fecha: ").append(LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))).append("\n");
        sb.append("Generado por: ").append(usuarioActual.getNombreCompleto()).append("\n\n");
        
        sb.append(String.format("%-5s %-30s %-20s %-15s %-10s %-10s\n",
            "ID", "Título", "Autor", "ISBN", "Total", "Disponible"));
        sb.append("================================================================================\n");
        
        for (Libro libro : libros) {
            sb.append(String.format("%-5d %-30s %-20s %-15s %-10d %-10d\n",
                libro.getIdLibro(),
                truncarTexto(libro.getTitulo(), 30),
                truncarTexto(libro.getAutoresString(), 20),
                libro.getIsbn() != null ? libro.getIsbn() : "N/A",
                libro.getCantidadTotal(),
                libro.getCantidadDisponible()));
        }
        
        sb.append("\n\nTotal de libros: ").append(libros.size());
        
        return sb.toString();
    }

    private String generarReporteUsuarios() throws Exception {
        List<Usuario> usuarios = usuarioDAO.obtenerTodos();
        
        StringBuilder sb = new StringBuilder();
        sb.append("REPORTE DE USUARIOS\n");
        sb.append("===================\n\n");
        sb.append("Fecha: ").append(LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))).append("\n");
        sb.append("Generado por: ").append(usuarioActual.getNombreCompleto()).append("\n\n");
        
        sb.append(String.format("%-5s %-25s %-20s %-15s %-10s\n",
            "ID", "Nombre", "Email", "Teléfono", "Rol"));
        sb.append("=======================================================================\n");
        
        for (Usuario usuario : usuarios) {
            sb.append(String.format("%-5d %-25s %-20s %-15s %-10s\n",
                usuario.getIdUsuario(),
                truncarTexto(usuario.getNombreCompleto(), 25),
                truncarTexto(usuario.getEmail(), 20),
                usuario.getTelefono() != null ? usuario.getTelefono() : "N/A",
                usuario.getNombreRol() != null ? usuario.getNombreRol() : "N/A"));
        }
        
        sb.append("\n\nTotal de usuarios: ").append(usuarios.size());
        
        return sb.toString();
    }

    private String generarReportePrestamosActivos() throws Exception {
        List<Prestamo> todosPrestamos = prestamoDAO.obtenerPrestamos();
        
        // Filtrar solo préstamos activos
        List<Prestamo> prestamos = new ArrayList<>();
        for (Prestamo prestamo : todosPrestamos) {
            if ("activo".equals(prestamo.getEstado())) {
                prestamos.add(prestamo);
            }
        }
        
        StringBuilder sb = new StringBuilder();
        sb.append("REPORTE DE PRÉSTAMOS ACTIVOS\n");
        sb.append("============================\n\n");
        sb.append("Fecha: ").append(LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))).append("\n");
        sb.append("Generado por: ").append(usuarioActual.getNombreCompleto()).append("\n\n");
        
        sb.append(String.format("%-5s %-25s %-25s %-12s %-12s\n",
            "ID", "Usuario", "Libro", "F. Prestamo", "F. Vencimiento"));
        sb.append("================================================================================\n");
        
        for (Prestamo prestamo : prestamos) {
            Usuario usuario = usuarioDAO.buscarPorId(prestamo.getIdUsuario());
            Libro libro = libroDAO.buscarPorId(prestamo.getIdLibro());
            
            sb.append(String.format("%-5d %-25s %-25s %-12s %-12s\n",
                prestamo.getIdPrestamo(),
                usuario != null ? truncarTexto(usuario.getNombreCompleto(), 25) : "N/A",
                libro != null ? truncarTexto(libro.getTitulo(), 25) : "N/A",
                prestamo.getFechaPrestamo().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")),
                prestamo.getFechaDevolucionProgramada().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))));
        }
        
        sb.append("\n\nTotal de préstamos activos: ").append(prestamos.size());
        
        return sb.toString();
    }

    private String generarReportePrestamosVencidos() throws Exception {
        List<Prestamo> todosPrestamos = prestamoDAO.obtenerPrestamos();
        LocalDate hoy = LocalDate.now();
        
        // Filtrar solo préstamos vencidos
        List<Prestamo> prestamos = new ArrayList<>();
        for (Prestamo prestamo : todosPrestamos) {
            if ("activo".equals(prestamo.getEstado()) && 
                prestamo.getFechaDevolucionProgramada().isBefore(hoy)) {
                prestamos.add(prestamo);
            }
        }
        
        StringBuilder sb = new StringBuilder();
        sb.append("REPORTE DE PRÉSTAMOS VENCIDOS\n");
        sb.append("=============================\n\n");
        sb.append("Fecha: ").append(LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))).append("\n");
        sb.append("Generado por: ").append(usuarioActual.getNombreCompleto()).append("\n\n");
        
        sb.append(String.format("%-5s %-25s %-25s %-12s %-12s %-8s\n",
            "ID", "Usuario", "Libro", "F. Prestamo", "F. Vencimiento", "Días Atraso"));
        sb.append("====================================================================================\n");
        
        for (Prestamo prestamo : prestamos) {
            Usuario usuario = usuarioDAO.buscarPorId(prestamo.getIdUsuario());
            Libro libro = libroDAO.buscarPorId(prestamo.getIdLibro());
            long diasAtraso = java.time.temporal.ChronoUnit.DAYS.between(prestamo.getFechaDevolucionProgramada(), LocalDate.now());
            
            sb.append(String.format("%-5d %-25s %-25s %-12s %-12s %-8d\n",
                prestamo.getIdPrestamo(),
                usuario != null ? truncarTexto(usuario.getNombreCompleto(), 25) : "N/A",
                libro != null ? truncarTexto(libro.getTitulo(), 25) : "N/A",
                prestamo.getFechaPrestamo().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")),
                prestamo.getFechaDevolucionProgramada().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")),
                diasAtraso));
        }
        
        sb.append("\n\nTotal de préstamos vencidos: ").append(prestamos.size());
        
        return sb.toString();
    }

    private String generarReporteHistorialPrestamos() throws Exception {
        List<Prestamo> todosPrestamos = prestamoDAO.obtenerPrestamos();
        LocalDate hoy = LocalDate.now();
        
        // Filtrar préstamos activos
        List<Prestamo> prestamos = new ArrayList<>();
        for (Prestamo prestamo : todosPrestamos) {
            if ("activo".equals(prestamo.getEstado())) {
                prestamos.add(prestamo);
            }
        }
        
        // Filtrar préstamos vencidos
        List<Prestamo> prestamosVencidos = new ArrayList<>();
        for (Prestamo prestamo : todosPrestamos) {
            if ("activo".equals(prestamo.getEstado()) && 
                prestamo.getFechaDevolucionProgramada().isBefore(hoy)) {
                prestamosVencidos.add(prestamo);
            }
        }
        
        // Combinar listas
        List<Prestamo> todosLosPrestamos = new ArrayList<>(prestamos);
        todosLosPrestamos.addAll(prestamosVencidos);
        
        StringBuilder sb = new StringBuilder();
        sb.append("HISTORIAL DE PRÉSTAMOS\n");
        sb.append("======================\n\n");
        sb.append("Fecha: ").append(LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))).append("\n");
        sb.append("Generado por: ").append(usuarioActual.getNombreCompleto()).append("\n\n");
        
        sb.append(String.format("%-5s %-25s %-25s %-12s %-12s %-10s\n",
            "ID", "Usuario", "Libro", "F. Prestamo", "F. Devolución", "Estado"));
        sb.append("===================================================================================\n");
        
        for (Prestamo prestamo : todosLosPrestamos) {
            Usuario usuario = usuarioDAO.buscarPorId(prestamo.getIdUsuario());
            Libro libro = libroDAO.buscarPorId(prestamo.getIdLibro());
            
            sb.append(String.format("%-5d %-25s %-25s %-12s %-12s %-10s\n",
                prestamo.getIdPrestamo(),
                usuario != null ? truncarTexto(usuario.getNombreCompleto(), 25) : "N/A",
                libro != null ? truncarTexto(libro.getTitulo(), 25) : "N/A",
                prestamo.getFechaPrestamo().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")),
                prestamo.getFechaDevolucionReal() != null ? 
                    prestamo.getFechaDevolucionReal().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) : "Pendiente",
                prestamo.getEstado()));
        }
        
        sb.append("\n\nTotal de préstamos registrados: ").append(todosLosPrestamos.size());
        
        return sb.toString();
    }

    private String generarReporteLibrosMasPrestados() throws Exception {
        // Implementación básica - en una versión completa se haría con consulta SQL optimizada
        StringBuilder sb = new StringBuilder();
        sb.append("LIBROS MÁS PRESTADOS\n");
        sb.append("====================\n\n");
        sb.append("Fecha: ").append(LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))).append("\n");
        sb.append("Generado por: ").append(usuarioActual.getNombreCompleto()).append("\n\n");
        
        sb.append("Funcionalidad disponible en próxima versión con análisis estadístico avanzado.\n");
        
        return sb.toString();
    }

    private String generarReporteUsuariosMasActivos() throws Exception {
        // Implementación básica - en una versión completa se haría con consulta SQL optimizada
        StringBuilder sb = new StringBuilder();
        sb.append("USUARIOS MÁS ACTIVOS\n");
        sb.append("====================\n\n");
        sb.append("Fecha: ").append(LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))).append("\n");
        sb.append("Generado por: ").append(usuarioActual.getNombreCompleto()).append("\n\n");
        
        sb.append("Funcionalidad disponible en próxima versión con análisis estadístico avanzado.\n");
        
        return sb.toString();
    }

    private void cargarEstadisticasIniciales() {
        SwingUtilities.invokeLater(() -> {
            try {
                // Estadísticas rápidas
                List<Libro> libros = libroDAO.obtenerTodos();
                List<Usuario> usuarios = usuarioDAO.obtenerTodos();
                
                List<Prestamo> todosPrestamos = prestamoDAO.obtenerPrestamos();
                LocalDate hoy = LocalDate.now();
                
                // Filtrar préstamos activos
                List<Prestamo> prestamosActivos = new ArrayList<>();
                for (Prestamo prestamo : todosPrestamos) {
                    if ("activo".equals(prestamo.getEstado())) {
                        prestamosActivos.add(prestamo);
                    }
                }
                
                // Filtrar préstamos vencidos
                List<Prestamo> prestamosVencidos = new ArrayList<>();
                for (Prestamo prestamo : todosPrestamos) {
                    if ("activo".equals(prestamo.getEstado()) && 
                        prestamo.getFechaDevolucionProgramada().isBefore(hoy)) {
                        prestamosVencidos.add(prestamo);
                    }
                }
                
                totalLibrosLabel.setText("Total Libros: " + libros.size());
                totalUsuariosLabel.setText("Total Usuarios: " + usuarios.size());
                prestamosActivosLabel.setText("Préstamos Activos: " + prestamosActivos.size());
                prestamosVencidosLabel.setText("Préstamos Vencidos: " + prestamosVencidos.size());
                
                // Estadísticas detalladas
                estadisticasModel.setRowCount(0);
                
                estadisticasModel.addRow(new Object[]{"Total de Libros", libros.size(), "Libros registrados en el sistema"});
                estadisticasModel.addRow(new Object[]{"Total de Usuarios", usuarios.size(), "Usuarios registrados en el sistema"});
                estadisticasModel.addRow(new Object[]{"Préstamos Activos", prestamosActivos.size(), "Préstamos pendientes de devolución"});
                estadisticasModel.addRow(new Object[]{"Préstamos Vencidos", prestamosVencidos.size(), "Préstamos que excedieron la fecha límite"});
                
                // Calcular libros disponibles
                int librosDisponibles = 0;
                int totalInventario = 0;
                for (Libro libro : libros) {
                    librosDisponibles += libro.getCantidadDisponible();
                    totalInventario += libro.getCantidadTotal();
                }
                
                estadisticasModel.addRow(new Object[]{"Libros Disponibles", librosDisponibles, "Ejemplares disponibles para préstamo"});
                estadisticasModel.addRow(new Object[]{"Total Inventario", totalInventario, "Total de ejemplares en inventario"});
                
                double porcentajeOcupacion = totalInventario > 0 ? 
                    ((double)(totalInventario - librosDisponibles) / totalInventario) * 100 : 0;
                estadisticasModel.addRow(new Object[]{"% Ocupación", String.format("%.1f%%", porcentajeOcupacion), "Porcentaje de libros prestados"});
                
                statusLabel.setText("Estadísticas actualizadas exitosamente");
                
            } catch (Exception e) {
                statusLabel.setText("Error al cargar estadísticas: " + e.getMessage());
                JOptionPane.showMessageDialog(this,
                    "Error al cargar estadísticas: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private void exportarReporte() {
        String contenido = reporteArea.getText();
        if (contenido.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "No hay reporte para exportar. Genere un reporte primero.",
                "Sin Contenido",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Guardar Reporte");
        fileChooser.setSelectedFile(new File("reporte_" + 
            LocalDate.now().format(DateTimeFormatter.ofPattern("ddMMyyyy")) + ".txt"));
        
        int userSelection = fileChooser.showSaveDialog(this);
        
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File archivoDestino = fileChooser.getSelectedFile();
            
            try (FileWriter writer = new FileWriter(archivoDestino)) {
                writer.write(contenido);
                JOptionPane.showMessageDialog(this,
                    "Reporte exportado exitosamente a:\n" + archivoDestino.getAbsolutePath(),
                    "Exportación Exitosa",
                    JOptionPane.INFORMATION_MESSAGE);
                statusLabel.setText("Reporte exportado: " + archivoDestino.getName());
                
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this,
                    "Error al exportar reporte: " + e.getMessage(),
                    "Error de Exportación",
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void imprimirReporte() {
        String contenido = reporteArea.getText();
        if (contenido.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "No hay reporte para imprimir. Genere un reporte primero.",
                "Sin Contenido",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        try {
            boolean complete = reporteArea.print();
            if (complete) {
                statusLabel.setText("Reporte enviado a impresora");
            } else {
                statusLabel.setText("Impresión cancelada por el usuario");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Error al imprimir: " + e.getMessage(),
                "Error de Impresión",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private String truncarTexto(String texto, int maxLength) {
        if (texto == null) return "N/A";
        if (texto.length() <= maxLength) return texto;
        return texto.substring(0, maxLength - 3) + "...";
    }
}
