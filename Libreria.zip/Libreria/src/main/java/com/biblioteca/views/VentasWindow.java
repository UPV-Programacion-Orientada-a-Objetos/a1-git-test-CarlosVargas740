package com.biblioteca.views;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.biblioteca.database.LibroDAO;
import com.biblioteca.models.Libro;
import com.biblioteca.models.Usuario;

/**
 * Ventana para sistema de ventas
 */
public class VentasWindow extends JFrame {
    
    private final Usuario usuarioActual;
    private final LibroDAO libroDAO;
    private List<ItemVenta> carrito;
    private BigDecimal totalVenta;
    
    private JPanel contentPane;
    private JTextField buscarLibroField;
    private JTextField codigoBarrasField;
    private JButton buscarButton;
    private JButton agregarButton;
    private JTable carritoTable;
    private DefaultTableModel carritoModel;
    private JTable librosTable;
    private DefaultTableModel librosModel;
    private JLabel totalLabel;
    private JButton eliminarButton;
    private JButton limpiarButton;
    private JButton procesarVentaButton;
    private JTextField clienteField;
    private JTextArea notasArea;
    private JLabel statusLabel;

    public VentasWindow(Usuario usuarioActual) {
        this.usuarioActual = usuarioActual;
        this.libroDAO = new LibroDAO();
        this.carrito = new ArrayList<>();
        this.totalVenta = BigDecimal.ZERO;
        
        initializeComponents();
        setupLayout();
        setupEvents();
        
        setTitle("Sistema de Ventas - " + usuarioActual.getNombreCompleto());
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        pack();
        setLocationRelativeTo(null);
    }

    private void initializeComponents() {
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(15, 15, 15, 15));
        setContentPane(contentPane);

        // Campos de búsqueda
        buscarLibroField = new JTextField(20);
        codigoBarrasField = new JTextField(15);
        buscarButton = new JButton("Buscar");
        agregarButton = new JButton("Agregar al Carrito");

        // Tabla de libros disponibles
        String[] librosColumnNames = {
            "ID", "Título", "Autor", "ISBN", "Precio", "Disponibles"
        };
        
        librosModel = new DefaultTableModel(librosColumnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        librosTable = new JTable(librosModel);
        librosTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // Tabla del carrito
        String[] carritoColumnNames = {
            "Título", "Precio Unit.", "Cantidad", "Subtotal"
        };
        
        carritoModel = new DefaultTableModel(carritoColumnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 2; // Solo la cantidad es editable
            }
            
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                if (columnIndex == 2) return Integer.class;
                return String.class;
            }
        };
        
        carritoTable = new JTable(carritoModel);
        carritoTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // Campos de venta
        clienteField = new JTextField(20);
        notasArea = new JTextArea(3, 20);
        notasArea.setLineWrap(true);
        notasArea.setWrapStyleWord(true);

        // Botones y labels
        eliminarButton = new JButton("Eliminar Item");
        limpiarButton = new JButton("Limpiar Carrito");
        procesarVentaButton = new JButton("Procesar Venta");
        totalLabel = new JLabel("Total: $0.00");
        totalLabel.setFont(totalLabel.getFont().deriveFont(Font.BOLD, 16f));
        statusLabel = new JLabel("Listo para vender");
    }

    private void setupLayout() {
        contentPane.setLayout(new BorderLayout());

        // Panel superior - búsqueda
        JPanel searchPanel = new JPanel(new GridBagLayout());
        searchPanel.setBorder(BorderFactory.createTitledBorder("Buscar Libros"));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        
        gbc.gridx = 0; gbc.gridy = 0; gbc.anchor = GridBagConstraints.WEST;
        searchPanel.add(new JLabel("Buscar por título/autor:"), gbc);
        
        gbc.gridx = 1; gbc.gridy = 0; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        searchPanel.add(buscarLibroField, gbc);
        
        gbc.gridx = 2; gbc.gridy = 0; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        searchPanel.add(buscarButton, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1;
        searchPanel.add(new JLabel("Código de barras:"), gbc);
        
        gbc.gridx = 1; gbc.gridy = 1; gbc.fill = GridBagConstraints.HORIZONTAL;
        searchPanel.add(codigoBarrasField, gbc);
        
        gbc.gridx = 2; gbc.gridy = 1; gbc.fill = GridBagConstraints.NONE;
        searchPanel.add(agregarButton, gbc);

        // Panel central
        JPanel centerPanel = new JPanel(new GridLayout(1, 2, 10, 0));
        
        // Libros disponibles
        JPanel librosPanel = new JPanel(new BorderLayout());
        librosPanel.setBorder(BorderFactory.createTitledBorder("Libros Disponibles"));
        JScrollPane librosScrollPane = new JScrollPane(librosTable);
        librosScrollPane.setPreferredSize(new Dimension(400, 250));
        librosPanel.add(librosScrollPane, BorderLayout.CENTER);
        
        // Carrito
        JPanel carritoPanel = new JPanel(new BorderLayout());
        carritoPanel.setBorder(BorderFactory.createTitledBorder("Carrito de Compras"));
        JScrollPane carritoScrollPane = new JScrollPane(carritoTable);
        carritoScrollPane.setPreferredSize(new Dimension(400, 250));
        carritoPanel.add(carritoScrollPane, BorderLayout.CENTER);
        
        JPanel carritoButtonsPanel = new JPanel(new FlowLayout());
        carritoButtonsPanel.add(eliminarButton);
        carritoButtonsPanel.add(limpiarButton);
        carritoPanel.add(carritoButtonsPanel, BorderLayout.SOUTH);
        
        centerPanel.add(librosPanel);
        centerPanel.add(carritoPanel);

        // Panel inferior - datos de venta
        JPanel bottomPanel = new JPanel(new GridBagLayout());
        bottomPanel.setBorder(BorderFactory.createTitledBorder("Datos de Venta"));
        
        gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        
        gbc.gridx = 0; gbc.gridy = 0; gbc.anchor = GridBagConstraints.WEST;
        bottomPanel.add(new JLabel("Cliente:"), gbc);
        
        gbc.gridx = 1; gbc.gridy = 0; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        bottomPanel.add(clienteField, gbc);
        
        gbc.gridx = 2; gbc.gridy = 0; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        bottomPanel.add(totalLabel, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1;
        bottomPanel.add(new JLabel("Notas:"), gbc);
        
        gbc.gridx = 1; gbc.gridy = 1; gbc.fill = GridBagConstraints.BOTH;
        bottomPanel.add(new JScrollPane(notasArea), gbc);
        
        gbc.gridx = 2; gbc.gridy = 1; gbc.fill = GridBagConstraints.NONE;
        bottomPanel.add(procesarVentaButton, gbc);
        
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 3; gbc.anchor = GridBagConstraints.WEST;
        bottomPanel.add(statusLabel, gbc);

        contentPane.add(searchPanel, BorderLayout.NORTH);
        contentPane.add(centerPanel, BorderLayout.CENTER);
        contentPane.add(bottomPanel, BorderLayout.SOUTH);
    }

    private void setupEvents() {
        buscarButton.addActionListener(e -> buscarLibros());
        
        buscarLibroField.addActionListener(e -> buscarLibros());
        
        agregarButton.addActionListener(e -> agregarPorCodigoBarras());
        
        codigoBarrasField.addActionListener(e -> agregarPorCodigoBarras());
        
        librosTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int selectedRow = librosTable.getSelectedRow();
                agregarButton.setEnabled(selectedRow != -1);
            }
        });
        
        // Doble clic en tabla de libros para agregar
        librosTable.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                if (e.getClickCount() == 2) {
                    agregarLibroSeleccionado();
                }
            }
        });
        
        eliminarButton.addActionListener(e -> eliminarDelCarrito());
        
        limpiarButton.addActionListener(e -> limpiarCarrito());
        
        procesarVentaButton.addActionListener(e -> procesarVenta());
        
        // Actualizar cantidad en carrito
        carritoModel.addTableModelListener(e -> {
            if (e.getColumn() == 2) { // Columna cantidad
                actualizarCarrito();
            }
        });
    }

    private void buscarLibros() {
        String termino = buscarLibroField.getText().trim();
        
        if (termino.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Ingrese un término de búsqueda.",
                "Término Requerido",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        SwingUtilities.invokeLater(() -> {
            try {
                List<Libro> libros = libroDAO.buscarLibros(termino, null, null, null, true); // Solo disponibles para venta
                
                librosModel.setRowCount(0);
                
                for (Libro libro : libros) {
                    if (libro.getCantidadDisponible() > 0 && libro.getPrecioVenta() != null && 
                        libro.getPrecioVenta().compareTo(BigDecimal.ZERO) > 0) {
                        Object[] row = {
                            libro.getIdLibro(),
                            libro.getTitulo(),
                            libro.getAutoresString(),
                            libro.getIsbn(),
                            "$" + libro.getPrecioVenta(),
                            libro.getCantidadDisponible()
                        };
                        librosModel.addRow(row);
                    }
                }
                
                statusLabel.setText("Se encontraron " + librosModel.getRowCount() + " libros disponibles para venta");
                
            } catch (Exception e) {
                statusLabel.setText("Error en la búsqueda: " + e.getMessage());
                JOptionPane.showMessageDialog(this,
                    "Error al buscar libros: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private void agregarPorCodigoBarras() {
        String codigoBarras = codigoBarrasField.getText().trim();
        
        if (codigoBarras.isEmpty()) {
            agregarLibroSeleccionado();
            return;
        }
        
        try {
            Libro libro = libroDAO.buscarPorCodigoBarras(codigoBarras);
            
            if (libro == null) {
                JOptionPane.showMessageDialog(this,
                    "No se encontró ningún libro con el código de barras: " + codigoBarras,
                    "Libro No Encontrado",
                    JOptionPane.WARNING_MESSAGE);
                return;
            }
            
            if (libro.getCantidadDisponible() <= 0) {
                JOptionPane.showMessageDialog(this,
                    "El libro no está disponible en inventario.",
                    "Sin Inventario",
                    JOptionPane.WARNING_MESSAGE);
                return;
            }
            
            if (libro.getPrecioVenta() == null || libro.getPrecioVenta().compareTo(BigDecimal.ZERO) <= 0) {
                JOptionPane.showMessageDialog(this,
                    "El libro no tiene precio de venta configurado.",
                    "Sin Precio",
                    JOptionPane.WARNING_MESSAGE);
                return;
            }
            
            agregarAlCarrito(libro);
            codigoBarrasField.setText("");
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Error al buscar por código de barras: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void agregarLibroSeleccionado() {
        int selectedRow = librosTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this,
                "Seleccione un libro de la tabla.",
                "Selección Requerida",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        try {
            int libroId = (Integer) librosModel.getValueAt(selectedRow, 0);
            Libro libro = libroDAO.buscarPorId(libroId);
            
            if (libro != null) {
                agregarAlCarrito(libro);
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Error al agregar libro: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void agregarAlCarrito(Libro libro) {
        // Verificar si ya está en el carrito
        for (ItemVenta item : carrito) {
            if (item.getLibro().getIdLibro() == libro.getIdLibro()) {
                if (item.getCantidad() < libro.getCantidadDisponible()) {
                    item.setCantidad(item.getCantidad() + 1);
                    actualizarCarrito();
                    statusLabel.setText("Cantidad actualizada para: " + libro.getTitulo());
                } else {
                    JOptionPane.showMessageDialog(this,
                        "No hay más inventario disponible para este libro.",
                        "Inventario Insuficiente",
                        JOptionPane.WARNING_MESSAGE);
                }
                return;
            }
        }
        
        // Agregar nuevo item
        ItemVenta nuevoItem = new ItemVenta(libro, 1);
        carrito.add(nuevoItem);
        actualizarCarrito();
        statusLabel.setText("Agregado al carrito: " + libro.getTitulo());
    }

    private void actualizarCarrito() {
        carritoModel.setRowCount(0);
        totalVenta = BigDecimal.ZERO;
        
        for (ItemVenta item : carrito) {
            BigDecimal subtotal = item.getLibro().getPrecioVenta().multiply(BigDecimal.valueOf(item.getCantidad()));
            totalVenta = totalVenta.add(subtotal);
            
            Object[] row = {
                item.getLibro().getTitulo(),
                "$" + item.getLibro().getPrecioVenta(),
                item.getCantidad(),
                "$" + subtotal
            };
            carritoModel.addRow(row);
        }
        
        totalLabel.setText("Total: $" + totalVenta);
        procesarVentaButton.setEnabled(!carrito.isEmpty());
    }

    private void eliminarDelCarrito() {
        int selectedRow = carritoTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this,
                "Seleccione un item para eliminar.",
                "Selección Requerida",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        carrito.remove(selectedRow);
        actualizarCarrito();
        statusLabel.setText("Item eliminado del carrito");
    }

    private void limpiarCarrito() {
        if (!carrito.isEmpty()) {
            int confirmacion = JOptionPane.showConfirmDialog(this,
                "¿Está seguro de que desea limpiar el carrito?",
                "Confirmar Limpieza",
                JOptionPane.YES_NO_OPTION);
            
            if (confirmacion == JOptionPane.YES_OPTION) {
                carrito.clear();
                actualizarCarrito();
                statusLabel.setText("Carrito limpiado");
            }
        }
    }

    private void procesarVenta() {
        if (carrito.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "El carrito está vacío.",
                "Carrito Vacío",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        String cliente = clienteField.getText().trim();
        if (cliente.isEmpty()) {
            cliente = "Cliente General";
        }
        
        String notas = notasArea.getText().trim();
        
        // Crear resumen de venta
        StringBuilder resumen = new StringBuilder();
        resumen.append("RESUMEN DE VENTA\n");
        resumen.append("================\n\n");
        resumen.append("Cliente: ").append(cliente).append("\n");
        resumen.append("Fecha: ").append(LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"))).append("\n");
        resumen.append("Vendedor: ").append(usuarioActual.getNombreCompleto()).append("\n\n");
        
        resumen.append("PRODUCTOS:\n");
        for (ItemVenta item : carrito) {
            BigDecimal subtotal = item.getLibro().getPrecioVenta().multiply(BigDecimal.valueOf(item.getCantidad()));
            resumen.append(String.format("- %s x%d = $%.2f\n", 
                item.getLibro().getTitulo(), item.getCantidad(), subtotal));
        }
        
        resumen.append(String.format("\nTOTAL: $%.2f\n", totalVenta));
        
        if (!notas.isEmpty()) {
            resumen.append("\nNotas: ").append(notas);
        }
        
        int confirmacion = JOptionPane.showConfirmDialog(this,
            resumen.toString(),
            "Confirmar Venta",
            JOptionPane.YES_NO_OPTION);
        
        if (confirmacion == JOptionPane.YES_OPTION) {
            // En una implementación real, aquí se guardaría en la base de datos
            JOptionPane.showMessageDialog(this,
                "Venta procesada exitosamente.\n\n" +
                "Total: $" + totalVenta + "\n" +
                "Ticket impreso (simulado)",
                "Venta Exitosa",
                JOptionPane.INFORMATION_MESSAGE);
            
            // Limpiar formulario
            carrito.clear();
            actualizarCarrito();
            clienteField.setText("");
            notasArea.setText("");
            statusLabel.setText("Venta procesada - Lista para nueva venta");
        }
    }

    // Clase interna para items de venta
    private static class ItemVenta {
        private Libro libro;
        private int cantidad;
        
        public ItemVenta(Libro libro, int cantidad) {
            this.libro = libro;
            this.cantidad = cantidad;
        }
        
        public Libro getLibro() { return libro; }
        public int getCantidad() { return cantidad; }
        public void setCantidad(int cantidad) { this.cantidad = cantidad; }
    }
}
